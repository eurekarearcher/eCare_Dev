const webpack = require('webpack');
const path = require('path');

module.exports = {
  filenameHashing: true,
  transpileDependencies: [
    'vuetify'
  ],

  outputDir: path.resolve(__dirname, `dist/${process.env.NODE_ENV === 'prod' ? `Ecare ${process.env.npm_package_version}` : process.env.NODE_ENV}`),

  configureWebpack:{
    plugins: [
      new webpack.DefinePlugin({
        'process.env.VUE_APP_TMS_URL': JSON.stringify(getTmsUrl()),
        'process.env.VUE_APP_CMS_URL': JSON.stringify(getCmsUrl()),
        'process.env.VUE_APP_REQUEST_TOKEN': JSON.stringify(getRequestToken())
      })
    ]
  }
}

// Function to get the correct TMS URL based on build mode
function getTmsUrl() {
  if (process.env.NODE_ENV === 'qa') {
    return 'https://testqa-tms-backend.eurekare.net/';
  } else if (process.env.NODE_ENV === 'demo') {
    return 'https://testqav2-tms.eurekare.net/';
  } else if (process.env.NODE_ENV === 'prod') {
    return  'https://prod-local-tms.eurekare.net/';
  } else {
    return 'https://dev-tms.eurekare.net:61012/'; // Default token dev URL
  }
}

// Function to get the correct CMS URL based on build mode
function getCmsUrl() {
  if (process.env.NODE_ENV === 'qa') {
    return 'https://testqa-cms-backend.eurekare.net/';
  } else if (process.env.NODE_ENV === 'demo') {
    return 'https://testqav2-cms.eurekare.net/';
  } else if (process.env.NODE_ENV === 'prod') {
    return 'https://prod-local-cms.eurekare.net/';
  } else {
    return 'https://dev-cms.eurekare.net:61012/'; // Default token dev URL
  }
}

// Function to get the correct Request Token based on build mode
function getRequestToken() {
  if (process.env.NODE_ENV === 'qa') {
    return 'ZUNhcmVfU3lzX1Rva2VuX1Rlc3RxYQ==+TD%X';
  } else if (process.env.NODE_ENV === 'demo') {
    return 'ZUNhcmVfU3lzX1Rva2VuX0RlbW8==+TD%X';
  } else if (process.env.NODE_ENV === 'prod') {
    return '';
  } else {
    return 'ZUNhcmVfU3lzX1Rva2VuX0Rldg==+TD%X'; // Default token dev URL
  }
}
