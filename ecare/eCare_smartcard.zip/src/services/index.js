import axios from 'axios'
import qs from 'qs';
import mixin from '@/mixin'

let base_url = {
    tms:process.env.VUE_APP_TMS_URL,
    cms:process.env.VUE_APP_CMS_URL,
    request_token: process.env.VUE_APP_REQUEST_TOKEN
}

let handle_errors = { 
    display: true, 
    type: 'standard', 
    width: '450',   
    icon: 'mdi-alert-circle', 
    color: 'red', 
    title: 'Something went wrong', 
    body: 'Please try again', 
    btn_pry_txt: 'OK', 
    btn_pry_color: 'primary', 
    btn_pry_otl: false, 
    btn_pry_act: 'reloadPage' 
}

let cancel_token = ''

const logOutUser = async(payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/usr_update_log_status.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getUserCredential = async (username, password) => {
    return await axios.post(base_url.cms + 'resources/api/_get_user_credential.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            username: username,
            password: password,
            request_code: 'RGJ6JF4ATK7R' 
        }))
    }),{...(base_url.request_token ? {
            headers: mixin.methods.getToken()
        } : undefined),
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const prvValidateAdminAcctReg = async(payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/prv_validate_admin_acct_reg.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const prvValidateCoordinates = async(payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/prv_validate_coordinates.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const prvAddProvider = async(payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/prv_add_provider.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getPrvValidateCoordinatesResult = async(payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_prv_validate_coordinates_result.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const prvUpdProviderInfo = async(payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/prv_upd_provider_info.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}


const usrValidateUser  = async (payload) => {
    return await axios.post(base_url.cms + 'resources/controller/usr_validate_user.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    })).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    }) 
}

const usrUpdUserData = async (payload) => {
    return await axios.post(base_url.cms + 'resources/controller/usr_upd_user_data.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    })).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    }) 
}

const getUserRegisteredUserByProvider = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_registered_user_by_provider.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}


const getAuditTrailLogs = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_audit_trail_logs.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}


const usrCheckUsernameByPh = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/usr_check_username_by_ph.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const usrAddUser = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/usr_add_user.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getDoctorSpecialization = async () => {
    return await axios.post(base_url.cms + 'resources/api/_get_doctor_specialization.php')
    .then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

//CURRENTLY NOT TESTED IN UPLOADING PROVIDER LOGO
const admUpdProviderConfig = async (payload, formData) => {
    let cancel_token = axios.CancelToken.source(); 

    if (formData !== undefined) {
        return await axios.post(base_url.cms + 'resources/controller/adm_upd_provider_config.php', formData, {
            cancelToken: cancel_token.token
        }).then(response => {
            return response;
        }).catch(error => {
            return {
                error: error.message 
            };
        });
    } else {
        return await axios.post(base_url.cms + 'resources/controller/adm_upd_provider_config.php', qs.stringify({
            post_data: mixin.methods.wsDataEncryption(JSON.stringify({
                ...payload
            })),
        }), {
            cancelToken: cancel_token.token
        }).then(response => {
            return response;
        }).catch(error => {
            return {
                error: error.message 
            };
        });
    }
};

const getAnnualDisease = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_annual_disease.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getAnnualCosting = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_annual_costing.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getCptTransactionReports = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_cpt_transaction_reports.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTransactionAllPr = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_transaction_all_pr.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTransactionIcdBmi = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_transaction_icd_bmi.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getProviderListByFacility = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_provider_list_by_facility.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getProviderList = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_provider_list.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getM2MorbidityReportsByProvider = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_m2_morbidity_reports_by_provider.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getFacilityFilter = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_facility_filter.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddFacilityFilter = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/trn_add_facility_filter.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnUpdFacilityFilter = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/trn_upd_facility_filter.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTransactionReport = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_transaction_report.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getM1M2Report = async (api, payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/' + api, qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMedicineConsumptionReport = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_medicine_consumption_report.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTransactionIcdCpt = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_transaction_icd_cpt.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getEkonsultaAccreditionCredentials = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_ekonsulta_accredition_credentials.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const prvUpdProviderForToken = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/prv_upd_provider_for_token.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getProviderInfo = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_provider_info.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const uploadXmlMigration = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/upload_xml_migration.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getEkonsultaValidationReports = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_ekonsulta_validation_reports.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getSubmittedReports = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_submitted_reports.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getEkonsultaSubmitReports = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/get_ekonsulta_submit_reports.php', payload, { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getEkonsultaEligibilityList = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_ekonsulta_eligibility_list.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getAnnualMedicine = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_annual_medicine.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMedicineInventoryByProvider = async (payload) => {
    cancel_token = axios.CancelToken.source()
 
    return await axios.post(base_url.cms + 'resources/api/_get_medicine_inventory_by_provider.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTransactionIpRefData = async (payload) => {
    cancel_token = axios.CancelToken.source()
    
    return await axios.post(base_url.cms + 'resources/api/_get_transaction_ip_ref_data.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getEclaimsWebService = async (payload) => {
    cancel_token = axios.CancelToken.source()
    
    return await axios.post(base_url.tms + 'resources/api/_get_eclaims_webservice.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMedicineInfo = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_medicine_info.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMemberEligibility = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_member_eligibility.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMemberAccrHospital = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_member_accr_hospital.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnDelNameById = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_del_name_by_pid.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMemberEligibilityLGU = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_member_eligibility_lgu.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getElaimsPBEF = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_eclaims_pbef.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getProviderICD = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_provider_icd.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getProviderCPT = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_provider_cpt.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getProviderConfiguration = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_provider_config.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getHostConfigByHost = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_host_config_by_host.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getPvtFacilityTransaction = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_pvt_facility_transaction.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddPvtResults = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_add_pvt_results.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getDiagnosticExamResults = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_diagnostic_exam_results.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getCptPackages = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_cpt_packages.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}


const trnAddUpdateCptPackages = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/trn_add_upd_cpt_packages.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getPhicLibrary = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_phic_library.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMemberListQr = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_member_list_qr.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const medUpdateMedicineQuantity = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/med_upd_medicine_quantity.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const medUpdateMedicineInfo = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/med_update_medicine_info.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const medAddMedicine = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/med_add_medicine.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const medSaveStockLevel = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/med_save_stock_level.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMedicineAdjustmentHistory = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_medicine_adjustment_history.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMedicineForReceiving = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_medicine_for_receiving.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getRecievedUpdateMedicine = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/med_upd_medicine_receiving.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMedicineTransferredHistory = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_medicine_transferred_history.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getAvailableMedicineByProvider = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_available_medicine_by_provider.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const medTransferMedicineByFacility = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/med_transfer_medicine_by_facility.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddDelIcdCptFavorites = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_add_del_icd_cpt_favorites.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getDiagnosticExamResultList = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_diagnostic_exam_result_list.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddEkonsulta = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_add_ekonsulta.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTransactionClinicalAbstract = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_transaction_clinical_abstract.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMemberVaccinationRecord = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_member_vaccination_record.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getDoctorPatientListByPid = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_doctor_patient_list_by_pid.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnUpdateTranRecordStatus = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_update_tran_record_status.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getEkonsultaEligibilityChecker = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_ekonsulta_eligibility_checker.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getEkonsultaAtcChecker = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_ekonsulta_atc_checker.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const queueListCancellation = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/queue_list_cancellation.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getPatientRecordAndTransaction = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_patient_record_and_transaction.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getDoctorIssuedTranRecord = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_doctor_issued_tran_record.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getPatientMedicalHistory = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_patient_medical_history.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnUpdatePatientTranRecord = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_update_patient_tran_record.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTransactionEmrObGyne = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_transaction_emr_ob_gyne.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTransactionPreviousByType = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_transaction_previous_by_type.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTransactionEmrDoctorDiagnosis = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_transaction_emr_doctor_diagnosis.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getPatientMedicine = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_patient_medicine.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTeleConsultDoctorList = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_teleconsult_doctor_list.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getDoctorSchedule = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_doctor_schedule.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}


const trnUpdAcceptTeleconsult = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_upd_accept_teleconsult.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnUpdDocSchedule = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_upd_doc_schedule.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getEmrChildVaccinationRecord = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_emr_child_vaccination_record.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnUpdateOutpatientCpt = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_upd_outpatient_cpt.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnUpdatePreConsultation = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_upd_pre_consultation.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnUpdateTransactionReferral = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_upd_transaction_referral.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getIcdCategoryList = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_icd_category_list.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddConsultation = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_add_consultation.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAdjustMedicineQuantity = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/trn_adjust_medicine_quantity.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTransactionConsultationResult = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_transaction_consultation_result.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnUpdateConsultation = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_upd_consultation.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnUpdateLoaConsultation = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_upd_loa_consultation.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getComDiseaseTestCases = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_com_disease_test_cases.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnUpdateComDiseaseTestCase = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_upd_com_disease_test_case.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnPushNotificationUser = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/trn_push_notification_user.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnPushNotificationEstab = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/trn_push_notification_estab.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTransactionPrescribedMedicineByPid = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_transaction_prescribed_medicine_by_pid.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnUpdateTransactionMedicine = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_update_transaction_medicine.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const wsMemberWeb = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/web_service/ws_member_web.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getPatientReferralTransaction = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_patient_referral_transaction.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

// const getTransactionSobIcdCaseRates = async (payload) => {
//     cancel_token = axios.CancelToken.source()

//     return await axios.post(base_url.tms + 'resources/api/_get_transaction_sob_icd_case_rates.php', qs.stringify({
//         post_data : mixin.methods.wsDataEncryption(JSON.stringify({
//             ...payload
//         }))
//     }), { 
//         cancelToken: cancel_token.token
//     }).then(response => {
//         return response
//     }).catch(() => {
//         return {
//             error: handle_errors
//         }
//     })
// }

const getTransactionSobIcdCaseRates = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_transaction_icd_case_rates.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

// const getTransactionSobCptRvs = async (payload) => {
//     cancel_token = axios.CancelToken.source()

//     return await axios.post(base_url.tms + 'resources/api/_get_transaction_sob_cpt_rvs.php', qs.stringify({
//         post_data : mixin.methods.wsDataEncryption(JSON.stringify({
//             ...payload
//         }))
//     }), { 
//         cancelToken: cancel_token.token
//     }).then(response => {
//         return response
//     }).catch(() => {
//         return {
//             error: handle_errors
//         }
//     })
// }

const getTransactionSobCptRvs = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_transaction_cpt_rvs.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddInpatient = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_add_inpatient.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getM1DisplayList = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_m1_display_list.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddM1ChildCare = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_add_m1_child_care.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddM1EnvironmentalHealth = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_add_m1_envr_health.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddM1Mortality = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_add_m1_mortality.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddM1Natality = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_add_m1_natality.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddOutpatient = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_add_outpatient.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnUpdateOutpatientIcd = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_upd_outpatient_icd.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddMigration = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/trn_add_migration.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTeleConsultPatients = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_teleconsult_patients.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTeleConsultPatientTransactions = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_teleconsult_patient_transactions.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTeleConsultPatientTransactionRecords = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_teleconsult_patient_transaction_records.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getTransactionQueue = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_transaction_queue.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMemberCardKey = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_member_card_key.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getProviderListByType = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_provider_list_by_type.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMemberLoaConsultation = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_member_loa_consultation.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMemberEligibilityPhic = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_member_eligibility_phic.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMemberRequestType = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_member_request_type.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddEligibility = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_add_eligibility.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}


const trnAddTransferPatient = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_add_transfer_doctor.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const syncEkonsultaMasterList = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/sync_ekonsulta_master_list.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddDownloadMasterList = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/trn_add_download_masterlist.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const index = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/qrcode/index.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMemberQrStatus = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_member_qr_status.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const smsAddWebLog = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/sms_add_web_log.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getSmsCheckLogByAccessNo = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_sms_check_log_by_access_no.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const usrUpdateLogTime = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/usr_update_log_time.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getReferredTransactionBypId = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_referred_transaction_by_pid.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getPhicEkassEpressFormData = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_phic_ekas_epress_form_data.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMobileAccountInfo = async (payload) => {
    cancel_token = axios.CancelToken.source()
    
    return await axios.post(base_url.cms + 'resources/api/_get_mobile_account_info.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const usrUpdateSettings = async (payload) => {
    cancel_token = axios.CancelToken.source()
    
    return await axios.post(base_url.cms + 'resources/controller/usr_upd_settings.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getEkonsultaFirstPatientEncounter = async (payload) => {
    cancel_token = axios.CancelToken.source()
    
    return await axios.post(base_url.cms + 'resources/api/_get_ekonsulta_first_patient_encounter.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const mailSender = async (payload) => {
    cancel_token = axios.CancelToken.source()
    
    return await axios.post(base_url.cms + 'resources/controller/mail_sender.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getStatusReport = async (payload) => {
    cancel_token = axios.CancelToken.source()
    
    return await axios.post(base_url.cms + 'resources/api/_get_status_report.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const validationServices = async (payload) => {
    cancel_token = axios.CancelToken.source()
    
    return await axios.post(base_url.tms + 'resources/api/_validation_services.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const konsultaValidationReport = async (payload) => {
    cancel_token = axios.CancelToken.source()
    
    return await axios.post(base_url.tms + 'resources/api/_konsulta_validation_report.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddEclaims = async (payload) => {
    cancel_token = axios.CancelToken.source()
    
    return await axios.post(base_url.tms + 'resources/controller/trn_add_upd_eclaims.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getEclaims = async (payload) => {
    let con_url = payload.migrated_to_eclaim_table === '1' ? '_get_eclaims_from_eclaim_table.php' : '_get_eclaims_from_ecare.php'
    delete payload.migrated_to_eclaim_table
    // _get_eclaims_from_eclaim_table.php

    cancel_token = axios.CancelToken.source()
    
    return await axios.post(base_url.tms + 'resources/api/' + con_url, qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getEclaimsCF2Form = async (payload) => {
    cancel_token = axios.CancelToken.source()
    
    return await axios.post(base_url.tms + '/resources/api/_get_eclaims_cf2_form.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getHelpVideo= async (payload) => {
    cancel_token = axios.CancelToken.source()
    
    return await axios.post(base_url.cms + '/resources/api/_get_demo_video.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getNonKonsultaMembers = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_non_ekonsulta_mem.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const trnAddUnassistedRegMigration = async(payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/controller/trn_add_unassisted_reg_migration.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const testAPI = async(payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_AUTHENTICATION_TEST_API.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }),{
        headers: mixin.methods.getToken()
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getPostEncoddQueueList = async(payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_post_encoded_queue_list.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getEclaimsCaseRateInfo = async(payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_eclaims_caserate_info.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getClaimsTrailStatus = async(payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.tms + 'resources/api/_get_eclaims_trail_status.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const medReplenishment = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/controller/med_replenishment.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

const getMedicineInventoryHistory = async (payload) => {
    cancel_token = axios.CancelToken.source()

    return await axios.post(base_url.cms + 'resources/api/_get_medicine_restock_inventory.php', qs.stringify({
        post_data : mixin.methods.wsDataEncryption(JSON.stringify({
            ...payload
        }))
    }), { 
        cancelToken: cancel_token.token
    }).then(response => {
        return response
    }).catch(() => {
        return {
            error: handle_errors
        }
    })
}

export const services = {
    axios,
    base_url,
    testAPI,
    usrUpdateLogTime,
    logOutUser,
    getUserCredential,
    usrValidateUser,
    getUserRegisteredUserByProvider,
    getAuditTrailLogs,
    usrUpdUserData,
    usrCheckUsernameByPh,
    usrAddUser,
    getDoctorSpecialization,
    admUpdProviderConfig,
    getAnnualDisease,
    getAnnualCosting,
    getCptTransactionReports,
    getTransactionAllPr,
    getTransactionIcdBmi,
    getM2MorbidityReportsByProvider,
    getFacilityFilter,
    trnAddFacilityFilter,
    trnUpdFacilityFilter,
    getTransactionReport,
    getM1M2Report,
    getMedicineConsumptionReport,
    getEkonsultaAccreditionCredentials,
    getTransactionIcdCpt,
    prvUpdProviderForToken,
    getProviderInfo,
    uploadXmlMigration,
    getEkonsultaValidationReports,
    getAnnualMedicine,
    getMemberEligibility,
    getMemberAccrHospital,
    trnDelNameById,
    getMemberEligibilityLGU,
    getElaimsPBEF,
    getProviderICD,
    getProviderCPT,
    getProviderConfiguration,
    getHostConfigByHost,
    getPvtFacilityTransaction,
    trnAddPvtResults,
    getDiagnosticExamResults,
    getPhicLibrary,
    prvValidateAdminAcctReg,
    prvValidateCoordinates,
    getPrvValidateCoordinatesResult,
    prvUpdProviderInfo,
    prvAddProvider,
    medUpdateMedicineQuantity,
    medAddMedicine,
    medSaveStockLevel,
    medUpdateMedicineInfo,
    medTransferMedicineByFacility,
    getMemberListQr,
    getMedicineAdjustmentHistory,
    getMedicineForReceiving,
    getRecievedUpdateMedicine,
    getMedicineTransferredHistory,
    getAvailableMedicineByProvider,
    getTransactionIpRefData,
    getMedicineInfo,
    getMedicineInventoryByProvider,
    getEkonsultaSubmitReports,
    getEkonsultaEligibilityList,
    getSubmittedReports,
    getProviderListByFacility,
    getProviderList,
    trnAddDelIcdCptFavorites,
    getDiagnosticExamResultList,
    trnAddEkonsulta,
    getTransactionClinicalAbstract,
    getMemberVaccinationRecord,
    getDoctorPatientListByPid,
    trnUpdateTranRecordStatus,
    getEkonsultaEligibilityChecker,
    getEkonsultaAtcChecker,
    queueListCancellation,
    getPatientRecordAndTransaction,
    getDoctorIssuedTranRecord,
    getPatientMedicalHistory,
    trnUpdatePatientTranRecord,
    getTransactionPreviousByType,
    getTransactionEmrDoctorDiagnosis,
    getPatientMedicine,
    getTeleConsultDoctorList,
    getDoctorSchedule,
    trnUpdAcceptTeleconsult,
    trnUpdDocSchedule,
    getEmrChildVaccinationRecord,
    trnUpdateOutpatientCpt,
    trnUpdatePreConsultation,
    trnUpdateTransactionReferral,
    getIcdCategoryList,
    trnAddConsultation,
    trnAdjustMedicineQuantity,
    getTransactionConsultationResult,
    trnUpdateConsultation,
    trnUpdateLoaConsultation,
    getComDiseaseTestCases,
    trnUpdateComDiseaseTestCase,
    trnPushNotificationUser,
    trnPushNotificationEstab,
    getTransactionPrescribedMedicineByPid,
    trnUpdateTransactionMedicine,
    wsMemberWeb,
    getPatientReferralTransaction,
    getTransactionSobIcdCaseRates,
    getTransactionSobCptRvs,
    trnAddInpatient,
    getM1DisplayList,
    trnAddM1ChildCare,
    trnAddM1EnvironmentalHealth,
    getTransactionEmrObGyne,
    trnAddM1Mortality,
    trnAddM1Natality,
    trnAddOutpatient,
    trnUpdateOutpatientIcd,
    trnAddMigration,
    getTeleConsultPatients,
    getTeleConsultPatientTransactions,
    getTeleConsultPatientTransactionRecords,
    getTransactionQueue,
    getMemberCardKey,
    getProviderListByType,
    getMemberLoaConsultation,
    getMemberEligibilityPhic,
    getMemberRequestType,
    trnAddEligibility,
    syncEkonsultaMasterList,
    trnAddDownloadMasterList,
    index,
    getReferredTransactionBypId,
    getMemberQrStatus,
    smsAddWebLog,
    getSmsCheckLogByAccessNo,
    getPhicEkassEpressFormData,
    getMobileAccountInfo,
    usrUpdateSettings,
    getEkonsultaFirstPatientEncounter,
    mailSender,
    getStatusReport,
    validationServices,
    konsultaValidationReport,
    trnAddEclaims,
    getEclaims,
    getEclaimsCF2Form,
    trnAddTransferPatient,
    getHelpVideo,
    getNonKonsultaMembers,
    trnAddUnassistedRegMigration,
    getEclaimsWebService,
    getCptPackages,
    trnAddUpdateCptPackages,
    getPostEncoddQueueList,
    getEclaimsCaseRateInfo,
    getClaimsTrailStatus,
    medReplenishment,
    getMedicineInventoryHistory
}