import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import mixin from './mixin'
import vuetify from './plugins/vuetify'
import axios from 'axios'
import * as CryptoJS from 'crypto-js'
import * as qs from 'qs';
import VueCookie from 'vue-cookie'
import moment from 'moment'
import excel_file from 'write-excel-file'
import { services } from './services'
import package_json from '../package.json' 
// import Print from 'vue-print-nb'

// Vue.use(Print)
Vue.use(VueCookie)
Vue.config.productionTip = false
Vue.prototype.$crypto = CryptoJS;
Vue.prototype.$qs = qs;
Vue.prototype.$moment = moment;
Vue.prototype.$axios = axios;
Vue.prototype.$excel_file = excel_file;
Vue.prototype.$services = services
Vue.prototype.$tms_url = services.base_url.tms
Vue.prototype.$cms_url = services.base_url.cms

// Display version
Vue.prototype.$app_version = package_json.version

// GLOBAL FUNCTION
Vue.mixin({
  ...mixin
})

new Vue({
  router,
  store,
  vuetify,
  render: h => h(App)
}).$mount('#app')
