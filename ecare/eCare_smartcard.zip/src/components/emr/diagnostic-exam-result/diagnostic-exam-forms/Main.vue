<template>
    <v-dialog v-model="procedure_loader" width="800">
        <v-card>
            <div v-show="diagnostic_exam.length != 0"> 
                <v-card-title class="d-flex justify-space-between align-baseline light-blue darken-4 white--text py-2 d-print-none">
                    <div> <span class="body-2 font-weight-bold"> TRANSACTION NUMBER: </span> <span class="body-2"> {{ transaction_number }}</span> </div>
                    <div> <span class="body-2 font-weight-bold"> PRESCRIPTION DATE: </span> <span class="body-2"> {{ prescription_date }}</span> </div>
                </v-card-title>

                <v-card-text class="mt-3">
                    <Cbc v-if="diagnostic_exam.libDesc === 'Complete Blood Count' || diagnostic_exam.libDesc === 'COMPLETE BLOOD COUNT'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" @numberOnly="numberOnly"/>
                    <Urinalysis v-else-if="diagnostic_exam.libDesc === 'Urinalysis' || diagnostic_exam.libDesc === 'URINALYSIS'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" @numberOnly="numberOnly"/>
                    <ChestXRay v-else-if="diagnostic_exam.libDesc === 'Chest X-Ray' || diagnostic_exam.libDesc === 'CHEST X-RAY'"   :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" :findings_list_items="findings_list_items" :observation_list_items="observation_list_items" @numberOnly="numberOnly"/>
                    <Sputum v-else-if="diagnostic_exam.libDesc === 'Sputum Microscopy' || diagnostic_exam.libDesc === 'SPUTUM MICROSCOPY'"  :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" :findings_list_items="findings_list_items" :observation_list_items="observation_list_items" @numberOnly="numberOnly"/>
                    <LipidProfile v-else-if="diagnostic_exam.libDesc === 'Lipid Profile' || diagnostic_exam.libDesc === 'LIPID PROFILE'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" @numberOnly="numberOnly"/>
                    <Fbs v-else-if="diagnostic_exam.libDesc === 'Fasting Blood Sugar' || diagnostic_exam.libDesc === 'FASTING BLOOD SUGAR'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" @numberOnly="numberOnly"/>
                    <Ecg v-else-if="diagnostic_exam.libDesc === 'Electrocardiogram (ECG)' || diagnostic_exam.libDesc === 'ELECTROCARDIOGRAM (ECG)'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" :findings_list_items="findings_list_items" @numberOnly="numberOnly"/>
                    <Rbs v-else-if="diagnostic_exam.libDesc === 'Random Blood Sugar' || diagnostic_exam.libDesc === 'RANDOM BLOOD SUGAR'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" @numberOnly="numberOnly"/>
                    <Fecalysis v-else-if="diagnostic_exam.libDesc === 'Fecalysis' || diagnostic_exam.libDesc === 'FECALYSIS'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" :fecalysis_color="fecalysis_color" :fecalysis_blood="fecalysis_blood" :fecalysis_consistency="fecalysis_consistency" @numberOnly="numberOnly"/>
                    <Papsmear v-else-if="diagnostic_exam.libDesc === 'Paps Smear' || diagnostic_exam.libDesc === 'PAPS SMEAR'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" @numberOnly="numberOnly"/>
                    <Ogtt v-else-if="diagnostic_exam.libDesc === 'Oral Glucose Tolerance Test' || diagnostic_exam.libDesc === 'ORAL GLUCOSE TOLERANCE TEST'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" @numberOnly="numberOnly"/>
                    <Fotb v-else-if="diagnostic_exam.libDesc === 'Fecal Occult Blood' || diagnostic_exam.libDesc === 'FECAL OCCULT BLOOD'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" :findings_list_items="findings_list_items" @numberOnly="numberOnly"/>
                    <Creatinine v-else-if="diagnostic_exam.libDesc === 'Creatinine' || diagnostic_exam.libDesc === 'CREATININE'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" @numberOnly="numberOnly"/>
                    <PpdTest v-else-if="diagnostic_exam.libDesc === 'Ppd Test (Tuberculosis)' || diagnostic_exam.libDesc === 'PPD TEST (TUBERCULOSIS)'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" :findings_list_items="findings_list_items" @numberOnly="numberOnly"/>
                    <Hba1c v-else-if="diagnostic_exam.libDesc === 'HbA1c' || diagnostic_exam.libDesc === 'HBA1C'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" @numberOnly="numberOnly"/>         
                    <OtherDiagExam v-else-if="diagnostic_exam.libDesc === 'Others' || diagnostic_exam.libDesc === 'OTHERS'" :diagnostic_exam="diagnostic_exam" :emr_page="emr_page" @numberOnly="numberOnly"/>
                    <div v-else> 
                        <h1>  </h1>
                    </div>
                </v-card-text>
            </div>

            <div v-show="diagnostic_exam.length <= 0">
                <v-card-title class="d-flex justify-space-between align-baseline light-blue darken-4 white--text py-2 d-print-none" style="height: 50px;">
                </v-card-title>

                <div class="d-flex justify-center align-center" style="height: 320px;"> 
                    <v-progress-circular :size="50" color="primary" indeterminate> </v-progress-circular>
                </div> 
            </div>
           
            <v-card-actions v-if="!emr_page || (diagnostic_exam.libDesc === 'Chest X-Ray' || diagnostic_exam.libDesc === 'CHEST X-RAY') && diagnostic_exam.pStatus !== 'Done'" class="d-flex justify-center align-baseline pa-3">
                <v-btn @click="cancel_dialog()">Cancel</v-btn>
                <v-btn @click="saveDiagnosticExam()" color="primary">Save Changes</v-btn>
            </v-card-actions>
            <v-card-actions v-else class="d-flex justify-center align-baseline pa-3">
                <v-btn @click="cancel_dialog()">Close</v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>
<script>
import Cbc from './Cbc'
import Urinalysis from './Urinalysis'
import ChestXRay from './ChestXRay'
import Sputum from './Sputum'
import LipidProfile from './LipidProfile'
import Fbs from './Fbs'
import Ecg from './Ecg'
import Rbs from './Rbs'
import Fecalysis from './Fecalysis'
import Papsmear from './Papsmear'
import Ogtt from './Ogtt'
import Fotb from './Fobt'
import Creatinine from './Creatinine'
import PpdTest from './PpdTest'
import Hba1c from './Hba1c'
import OtherDiagExam from './OtherDiagExam'

export default {
    props: ['procedure_loader'],

    components: {
        Cbc,
        Urinalysis,
        ChestXRay,
        Sputum,
        LipidProfile,
        Fbs,
        Ecg,
        Rbs,
        Fecalysis,
        Papsmear,
        Ogtt,
        Fotb,
        Creatinine,
        PpdTest,
        Hba1c,
        OtherDiagExam
    },

    data() {
        return {
            diagnosis_exam_diaglog: false,
            disabled_btn_diagnostic: true,

            transaction_number: '',
            prescription_date: '',
            diagnostic_exam: [],
            result: [],
            emr_page: false,

            request_lib: {},
            findings_list_items: {},
            observation_list_items: {},
            fecalysis_color: {},
            fecalysis_blood: {},
            fecalysis_consistency: {},

            diagnostic_items: ['COMPLETE BLOOD COUNT', 'URINALYSIS', 'CHEST X-RAY', 'SPUTUM MICROSCOPY', 'LIPID PROFILE', 'ORAL GLUCOSE TOLERANCE TEST', 'FECALYSIS', 'PAPS SMEAR', 'FECAL OCCULT BLOOD', 'FASTING BLOOD SUGAR', 'ELECTROCARDIOGRAM (ECG)', 'RANDOM BLOOD SUGAR', 'CREATININE', 'PPD TEST (TUBERCULOSIS)', 'HBA1C', 'OTHERS']
        }
    },

    computed: {
        validate_diagnostic_exam() {
            let diagnostic = false
            this.result.map(data => {
                if(data.cpt_code === this.diagnostic_exam.cpt_code){
                    diagnostic = true
                } 
            })

            return diagnostic
        }
    },

    methods: {
        // PREVENT USER FROM TYPING LETTERS IN TEXT FIELD
        numberOnly(event){
            if ((event.which < 48 || event.which > 57) && event.which !== 45){
                event.preventDefault();
            }
        },

        openDiagnosticExam(item, transaction_number, prescription_date, emr_page){    
            this.diagnostic_exam = item
            this.diagnosis_exam_diaglog = this.procedure_loader
            this.emr_page = !emr_page
            this.transaction_number = transaction_number
            this.prescription_date = prescription_date

            if(this.diagnostic_exam.libDesc === 'Fecalysis' || this.diagnostic_exam.libDesc === 'FECALYSIS') {
                this.request_lib = [{lib: 'LIB_FECALYSIS_Color'}, {lib: 'LIB_FECALYSIS_Consistency'}, {lib: 'LIB_FECALYSIS_Blood'}]
            } else {
                this.request_lib = [{lib: this.diagnostic_exam.diagnostic.lib_findings}, {lib: this.diagnostic_exam.diagnostic.lib_observation }]
            }
            this.getDiagnosticLibrary()
        },

        async getDiagnosticLibrary() {
            let response = await this.$services.getPhicLibrary({
                request_lib: this.request_lib
            })

            if (response.status === 200) {
                response.data = this.responseDataDecryption(response.data)
                this.findings_list_items = [response.data.lib_chestxray_findings || response.data.lib_sputum_findings || response.data.lib_ecg_findings || response.data.lib_ppdtest || response.data.lib_fobt_findings]   
                this.observation_list_items = [response.data.lib_chestxray_observation || response.data.lib_sputum_datacollection]
                this.fecalysis_color = [response.data.lib_fecalysis_color]
                this.fecalysis_blood = [response.data.lib_fecalysis_blood]
                this.fecalysis_consistency = [response.data.lib_fecalysis_consistency]
            } else {
                this.alert = response.error
            }
        },

        saveDiagnosticExam(){
            this.$emit('update:procedure_loader', false)

            if(this.diagnostic_items.includes(this.diagnostic_exam.libDesc) || this.diagnostic_items.includes(this.diagnostic_exam.libDesc.toUpperCase())) {
                if(!this.validate_diagnostic_exam) {
                    this.diagnostic_exam.pStatus = 'Done'
                    this.diagnostic_exam.diagnostic.pDiagStatus = 'Done'
                    this.diagnostic_exam.diagnostic.cpt_code = this.diagnostic_exam.cpt_code
                    this.diagnostic_exam.diagnostic.pOtherDiagnosticExam = this.diagnostic_exam.libDesc === 'Others' ? this.diagnostic_exam.cpt_desc : ''
                    this.result.push(this.diagnostic_exam.diagnostic) 
                    this.$emit('getDiagnosticExam', this.result)

                    //REST THE FIELD OF DIAGNOSTIC EXAM RESULT
                    this.diagnostic_exam = []
                } 
            }
        },

        cancel_dialog(){
            this.diagnostic_exam = []
            this.$emit('update:procedure_loader', false)
        }
    }
}
</script>
