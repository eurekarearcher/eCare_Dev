<template>
    <v-card id="for-print-relative" class="px-2 pt-2" flat >
        <div class="pa-8" v-if="$route.name === 'EMRConsultationTypeA'">
            <v-sheet v-if="print_option === 'both' || print_option === 'pres_only'" :class="(data.selected_icd[0] && data.selected_icd[0].procedures.length >= 5) || this.selected_medicine.length >= 5 && (this.show_management_doctor_notes || this.follow_up_consultation_date) ? 'pagebreak' : ''"> 
                <Header :is_treatment_plan="true" />
                <v-row align="center" dense>
                    <v-col cols="12" xs="12" sm="12" md="12" lg="12">
                        <v-row v-if="$store.state.prv_data.municipality === 'PARAÑAQUE CITY'" class="d-flex justify-end" dense> 
                            <v-col class="d-flex align-baseline" cols="12" xs="4" sm="4" md="4" lg="4">
                                <label class="body-2 font-weight-medium">Date:</label>
                                <span class="body-2 print-pat-info">{{ data.date_admitted }}</span>
                            </v-col>
                        </v-row>
                        <v-row v-if="$store.state.prv_data.municipality === 'PARAÑAQUE CITY'" dense>
                            <v-col class="d-flex align-baseline" cols="12" xs="6" sm="6" md="6" lg="6">
                                <label class="body-2 font-weight-medium">Name:</label>
                                <span class="body-2 print-pat-info">{{ data.patient_name }}</span>
                            </v-col>
                            <v-col class="d-flex align-baseline" cols="12" xs="3" sm="3" md="3" lg="3"> 
                                <label class="body-2 font-weight-medium">Age:</label>
                                <span class="body-2 print-pat-info">{{ data.patient_age }}</span>
                            </v-col>
                            <v-col class="d-flex align-baseline" cols="12" xs="3" sm="3" md="3" lg="3"> 
                                <label class="body-2 font-weight-medium">Sex:</label>
                                <span class="body-2 print-pat-info">{{ data.patient_sex }}</span>
                            </v-col>
                        </v-row>
                        <v-row v-else class="mt-5" dense>
                            <v-col class="d-flex align-baseline" cols="12" xs="8" sm="8" md="8" lg="8">
                                <label class="body-2 font-weight-medium">Name:</label>
                                <span class="body-2 print-pat-info">{{ data.patient_name }}</span>
                            </v-col>
                            <v-col class="d-flex align-baseline" cols="12" xs="4" sm="4" md="4" lg="4">
                                <label class="body-2 font-weight-medium">Date:</label>
                                <span class="body-2 print-pat-info">{{ data.date_admitted }}</span>
                            </v-col>
                            <v-col class="d-flex align-baseline" cols="12" xs="8" sm="8" md="8" lg="8">
                                <label class="body-2 font-weight-medium">Address:</label>
                                <span class="body-2 print-pat-info">{{ data.patient_address }}</span>
                            </v-col>
                            <v-col class="d-flex align-baseline" cols="12" xs="4" sm="4" md="4" lg="4"> 
                                <label class="body-2 font-weight-medium">Age:</label>
                                <span class="body-2 print-pat-info">{{ data.patient_age }}</span>
                            </v-col>
                        </v-row>
                        <v-row dense> 
                            <v-col class="ml-n4" cols="12" xs="12" sm="12" md="12" lg="12">
                                <h4 class="font-weight-medium pt-6 pb-1"> PRESCRIPTION </h4>
                                <v-img src="@/assets/rx.png" class="mt-2" width="100%" max-width="60" contain></v-img>
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>

                <template v-if="show_management_doctor_notes"> 
                    <div v-if="select_management && select_management.management_description" class="font-weight-medium body-2">
                        <h6 class="font-weight-medium body-2 mt-4"> Management Type  </h6>
                        <span class="body-2 pl-4 pb-2"> {{ select_management.management_description }} </span> 
                    </div> 

                    <div v-if="doctor_notes" class="font-weight-medium body-2">
                        <h6 class="font-weight-medium body-2 mt-4">Doctor Notes </h6>
                        <span class="body-2 pl-4 pb-2"> {{ doctor_notes }} </span> 
                    </div>
                </template>
                    
                <div v-if="follow_up_consultation_date" class="font-weight-medium body-2">
                    <h6 class="font-weight-medium body-2 mt-4"> 
                        Follow up date:
                        <span class="font-weight-bold blue--text text--darken-4">{{ follow_up_date }}</span>
                    </h6>
                </div>

                <div v-if="this.selected_medicine.length > 0 && (print_option === 'both' || print_option === 'pres_only')" class="print-med-tbl-main">
                
                    <div class="d-flex d-row font-weight-medium text-center">
                        <div class="print-med-tbl-h" style="min-width: 300px;">Generic Name</div>
                        <div class="print-med-tbl-h">Dosage<br>Preparation</div>
                        <div class="print-med-tbl-h">Frequency<br>(per day)</div>
                        <div class="print-med-tbl-h">Duration #<br>of days</div>
                        <div class="print-med-tbl-h">Total # of<br>Medicine</div>
                        <div class="print-med-tbl-h">Remarks</div>
                    </div>

                    <div v-for="(med, i) in this.selected_medicine" :key="i" class="d-flex d-row align-start pt-2 body-1 font-weight-medium">
                        <div class="print-med-tbl-b text-wrap" style="min-width: 300px;">
                            <span>{{ med.generic_name }}</span>
                        </div>
                        <div class="print-med-tbl-b text-center">
                            <span>{{ med.dosage }} {{ med.sosage && med.preparation ? '/' : ''}} {{ med.preparation }}</span>
                        </div>
                        <div class="print-med-tbl-b text-center">
                            <span>{{ med.frequency_of_med }}</span>
                        </div>
                        <div class="print-med-tbl-b text-center">
                            <span>{{ med.duration }}</span>
                        </div>
                        <div class="print-med-tbl-b text-center">
                            <span># {{ med.total_num_of_med }}</span>
                        </div>
                        <div class="print-med-tbl-b text-center" >
                            <span>{{ med.notes }}</span>
                        </div>
                    </div>
                </div>

                <v-row :class="[print_option === 'pres_only' ? 'pt-16' : 'pt-6']" class="pt-4" dense>
                    <v-col cols="12" sm="9" md="9" lg="9" xl="9" class="">
                            <!-- Treatment Plan Certificate QR Code Section -->
                            <v-sheet id="treatmentplan-certificate" class="qr-code-med" style="box-shadow: none; border: none;">
                                <QrcodeVue :value="treatmentplan_qr_value" :size="120" level="L" renderAs="svg" />
                            </v-sheet>
                    </v-col>

                    <v-col cols="12" sm="3" lg="3" xl="3" align-self="end" class="text-center">
                        <v-sheet v-if="$store.state.prv_data.municipality === 'PARAÑAQUE CITY'"> 
                            <h4 class="font-weight-medium">{{ data.doctor_name }}</h4>
                            <h5 class="font-weight-medium">License No: {{ data.doctor_prc_license }}</h5>
                            <h5 class="font-weight-medium">{{ data.doctor_position }}</h5>
                            <h5 class="font-weight-medium">{{ data.doctor_specialization }}</h5>
                        </v-sheet>
                        <v-sheet v-else> 
                            <h4 class="font-weight-medium">{{ data.doctor_name }}</h4>
                            <h4 class="font-weight-medium border-bottom">Lic. #: {{ data.doctor_prc_license }}</h4>
                            <h5 class="font-weight-medium mt-1 mb-5">DOCTOR</h5>
                        </v-sheet>
                    </v-col>
                </v-row>
            </v-sheet>
        </div>

        <div v-else class="pa-8" >  
            <v-sheet> 
                <Header :is_treatment_plan="true" />
                <v-row align="center" dense>
                    <v-col cols="12" xs="12" sm="12" md="12" lg="12">
                        <v-row v-if="$store.state.prv_data.municipality === 'PARAÑAQUE CITY'" class="d-flex justify-end" dense> 
                            <v-col class="d-flex align-baseline" cols="12" xs="4" sm="4" md="4" lg="4">
                                <label class="body-2 font-weight-medium">Date:</label>
                                <span class="body-2 print-pat-info">{{ this.data.date_admitted }}</span>
                            </v-col>
                        </v-row>
                        <v-row v-if="$store.state.prv_data.municipality === 'PARAÑAQUE CITY'" dense>
                            <v-col class="d-flex align-baseline" cols="12" xs="6" sm="6" md="6" lg="6">
                                <label class="body-2 font-weight-medium">Name:</label>
                                <span class="body-2 print-pat-info">{{ this.data.patient_name }}</span>
                            </v-col>
                            <v-col class="d-flex align-baseline" cols="12" xs="3" sm="3" md="3" lg="3"> 
                                <label class="body-2 font-weight-medium">Age:</label>
                                <span class="body-2 print-pat-info">{{ this.data.patient_age }}</span>
                            </v-col>
                            <v-col class="d-flex align-baseline" cols="12" xs="3" sm="3" md="3" lg="3"> 
                                <label class="body-2 font-weight-medium">Sex:</label>
                                <span class="body-2 print-pat-info">{{ this.data.patient_sex }}</span>
                            </v-col>
                        </v-row>
                        <v-row v-else class="mt-5" dense> 
                            <v-col class="d-flex align-baseline" cols="12" xs="8" sm="8" md="8" lg="8">
                                <label class="body-2 font-weight-medium">Name:</label>
                                <span class="body-2 print-pat-info">{{ this.data.patient_name }}</span>
                            </v-col>
                            <v-col class="d-flex align-baseline" cols="12" xs="4" sm="4" md="4" lg="4">
                                <label class="body-2 font-weight-medium">Date:</label>
                                <span class="body-2 print-pat-info">{{ this.data.date_admitted }}</span>
                            </v-col>
                            <v-col class="d-flex align-baseline" cols="12" xs="8" sm="8" md="8" lg="8">
                                <label class="body-2 font-weight-medium">Address:</label>
                                <span class="body-2 print-pat-info">{{ this.data.patient_address }}</span>
                            </v-col>
                            <v-col class="d-flex align-baseline" cols="12" xs="4" sm="4" md="4" lg="4"> 
                                <label class="body-2 font-weight-medium">Age:</label>
                                <span class="body-2 print-pat-info">{{ this.data.patient_age }}</span>
                            </v-col>
                        </v-row>
                        <v-row dense> 
                            <v-col class="ml-n4" cols="12" xs="12" sm="12" md="12" lg="12">
                                <h4 class="font-weight-medium pt-6 pb-1"> PRESCRIPTION </h4>
                                <v-img src="@/assets/rx.png" class="mt-2" width="100%" max-width="60" contain></v-img>
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>

                <!--<template v-if="show_management_doctor_notes"> 
                    <div v-if="select_management && select_management.management_description" class="font-weight-medium body-2">
                        <h6 class="font-weight-medium body-2 mt-4"> Management Type  </h6>
                        <span class="body-2 pl-4 pb-2"> {{ select_management.management_description }} </span> 
                    </div> 

                    <div v-if="doctor_notes" class="font-weight-medium body-2">
                        <h6 class="font-weight-medium body-2 mt-4">Doctor Notes </h6>
                        <span class="body-2 pl-4 pb-2"> {{ doctor_notes }} </span> 
                    </div>
                </template>
                    
                <div v-if="follow_up_consultation_date" class="font-weight-medium body-2">
                    <h6 class="font-weight-medium body-2 mt-4"> 
                        Follow up date:
                        <span class="font-weight-bold blue--text text--darken-4">{{ follow_up_date }}</span>
                    </h6>
                </div>-->
                <div v-if="this.data.selected_medicine.length > 0 && (print_option === 'both' || print_option === 'pres_only')" class="print-med-tbl-main">
                
                    <div class="d-flex d-row font-weight-medium text-center">
                        <div class="print-med-tbl-h" style="min-width: 200px;">Generic Name</div>
                        <div class="print-med-tbl-h">Dosage<br>Preparation</div>
                        <div class="print-med-tbl-h">Frequency<br>(per day)</div>
                        <div class="print-med-tbl-h">Duration #<br>of days</div>
                        <div class="print-med-tbl-h">Total # of Medicine</div>
                        <div class="print-med-tbl-h">Total # of Dispensed Medicine</div>
                        <div class="print-med-tbl-h">Remarks</div>
                    </div>
                    
                    <div v-for="(med, i) in data.selected_medicine.filter(m => m.dispensed_medicine_status !== 'Fully Served')" :key="i" class="d-flex d-row align-start pt-2 body-1 font-weight-medium">
                        <div class="print-med-tbl-b text-wrap" style="min-width: 200px;">
                            <span>{{ med.medicine_name }}</span>
                        </div>
                        <div class="print-med-tbl-b text-center">
                            <span>{{ med.dosage }} {{ med.dosage && med.preparation ? '/' : ''}} {{ med.preparation }}</span>
                        </div>
                        <div class="print-med-tbl-b text-center">
                            <span>{{ med.frequency_of_med }}</span>
                        </div>
                        <div class="print-med-tbl-b text-center">
                            <span>{{ med.duration }}</span>
                        </div>
                        <div class="print-med-tbl-b text-center">
                            <span># {{ med.total_prescribed_medicine }}</span>
                        </div>
                        <div class="print-med-tbl-b text-center" >
                            <span>{{ med.total_dispensed_medicine }}</span>
                        </div>
                        <div class="print-med-tbl-b text-center">
                            <span>{{ med.notes }}</span>
                        </div>
                    </div>
                </div>

                <v-row :class="[print_option === 'pres_only' ? 'pt-16' : 'pt-6']" class="pt-4" dense>
                    <v-col cols="12" sm="9" md="9" lg="9" xl="9" class="">
                            <!-- Treatment Plan Certificate QR Code Section 
                            <v-sheet id="treatmentplan-certificate" class="qr-code-med" style="box-shadow: none; border: none;">
                                <QrcodeVue :value="treatmentplan_qr_value" :size="120" level="L" renderAs="svg" />
                            </v-sheet> -->
                    </v-col>

                    <v-col cols="12" sm="3" lg="3" xl="3" align-self="end" class="text-center mt-7">
                        <v-sheet v-if="$store.state.prv_data.municipality === 'PARAÑAQUE CITY'"> 
                            <h4 class="font-weight-medium">{{ this.data.doctor_name }}</h4>
                            <h5 class="font-weight-medium">License No: {{ this.data.doctor_prc_license }}</h5>
                            <h5 class="font-weight-medium">{{ this.data.doctor_position }}</h5>
                            <h5 class="font-weight-medium">{{ this.data.doctor_specialization }}</h5>
                        </v-sheet>
                        <v-sheet v-else> 
                            <h4 class="font-weight-medium">{{ this.data.doctor_name }}</h4>
                            <h4 class="font-weight-medium border-bottom">Lic. #: {{ this.data.doctor_prc_license }}</h4>
                            <h5 class="font-weight-medium mt-1 mb-5">DOCTOR</h5>
                        </v-sheet>
                    </v-col>
                </v-row>
            </v-sheet>
        </div>
    </v-card>
</template>

<script>
import Header from '@/components/emr/printable-form/Header.vue';
import QrcodeVue from 'qrcode.vue';

export default {
    props: ['selected_medicine', 'patient_name', 'data'],

    components: {
        Header,
        QrcodeVue,
    },
    
    data() {
        return {
            show_dialog: false,
            show_management_doctor_notes: false,
            print_option: 'both',
            treatmentplan_qr_value: '',
            is_treatment_plan: '',
            follow_up_consultation_date:''
        }
    },
}
</script>

<style scoped>
.print-pat-info{
    border-bottom: 1px solid grey; 
    margin: 14px 0 0 4px; 
    padding: 2px 0 0 0; 
    width: 100%;
}
.print-med-tbl-main{ overflow-x: auto; }
.print-med-tbl-main .d-flex{
    width: 100%;
    padding: 0;
    margin: 0; 
}
::v-deep .v-dialog {
    box-shadow: none;
}
.print-med-tbl-h{
    font-size: 14px;
    width: 250px;
}
.print-med-tbl-b{
    font-size: 14px;
    padding: 2px 0 0 2px;
    width: 100%;
    text-align: center;
}
@media print{
    ::v-deep #not-for-print {
        display: none !important;
    }
    ::v-deep .v-dialog {
        box-shadow: none;
    }
}
</style>