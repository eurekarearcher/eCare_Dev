<template>
   <v-dialog v-model="show_dialog" width="1400px" persistent>
   
        <template v-if="$store.state.usr_credentials.lgu_host_code === 'BT'">
            <Bataan :data="data" :select_management="select_management" :doctor_notes="doctor_notes" :jspdf="jspdf" @close="close" :emr_params="emr_params"/>
        </template>

        <template v-else-if="$store.state.usr_credentials.lgu_host_code === 'AT'">
            <Antipolo :data="data" :select_management="select_management" :doctor_notes="doctor_notes" :jspdf="jspdf" :input_undersigned="input_undersigned" :input_remarks="input_remarks" :medical_certificate_qr_value="medical_certificate_qr_value" @close="close" :emr_params="emr_params"/>
        </template>

        <template v-else-if="this.$store.state.usr_credentials.lgu_host_code === 'SR'"> 
            <SantaRosa :data="data" :select_management="select_management" :doctor_notes="doctor_notes" :jspdf="jspdf" :input_remarks="input_remarks"  :input_diagnose="input_diagnose" @close="close" :emr_params="emr_params"/>
        </template>

        <template v-else-if="$store.state.usr_credentials.lgu_host_code === 'LC'">
            <template v-if="$store.state.prv_data.municipality === 'PAGBILAO'"> 
                <PagBilao :data="data" :doctor_notes="doctor_notes" :jspdf="jspdf" @close="close" :emr_params="emr_params"/>
            </template>
            
            <template v-else-if="$store.state.prv_data.municipality === 'ATIMONAN'"> 
                <Atimonan :data="data" :input_remarks="input_remarks" :jspdf="jspdf" @close="close" :emr_params="emr_params"/>
            </template>

            <template v-else> 
                <Quezon :data="data" :input_remarks="input_remarks" :jspdf="jspdf" @close="close" :emr_params="emr_params"/>
            </template>
        </template>

        <template v-else-if="$store.state.usr_credentials.lgu_host_code === 'PQ'">
            <template>
                <Paranaque :data="data" :jspdf="jspdf" @close="close" :input_diagnose="input_diagnose" :input_due="input_due" :emr_params="emr_params"/>
            </template>
        </template>

        <template v-else>
            <Bataan :data="data" :select_management="select_management" :doctor_notes="doctor_notes" :jspdf="jspdf" @close="close" :emr_params="emr_params"/>
        </template>
   </v-dialog>
</template>


<script>
import Antipolo from '@/components/emr/printable-form/medical-certificate/Antipolo.vue'
import Bataan from '@/components/emr/printable-form/medical-certificate/Bataan.vue'
import Quezon from '@/components/emr/printable-form/medical-certificate/quezon/QMC.vue'
import PagBilao from '@/components/emr/printable-form/medical-certificate/quezon/PagBliao'
import Atimonan from '@/components/emr/printable-form/medical-certificate/quezon/Atimonan.vue'
import Paranaque from '@/components/emr/printable-form/medical-certificate/Paranaque.vue'
import SantaRosa from '@/components/emr/printable-form/medical-certificate/SantaRosa.vue'

export default {
    props: ['jspdf', 'doctor_notes', 'select_management', 'emr_params'],

    components: {
        Antipolo,
        Bataan,
        Quezon,
        PagBilao,
        Atimonan,
        Paranaque,
        SantaRosa
    },

    data() {
        return {
            show_dialog: false,
            include_lab_and_prescription: false,
            data: {
                date_admitted: '',
                patient_name: '',
                address: '',
                age: '',
                ek_lgu_id: '',
                impression_diagnosis: [],
                laboratory_request: [],
                selected_medicine: [],
                doctor_name: '',
                doctor_specialization: '',
                doctor_prc_license: '',
                input_undersigned_field: '',
                input_remarks_field: '',
                input_due_field: '',
                input_diagnose_field: ''
            },
            input_undersigned: false,
            input_remarks: false,
            input_diagnose: false,
            input_due: false,
            print_own: false,
            medical_certificate_qr_value: '',
        }
    },

    methods: {
        editForms() {
            this.input_undersigned = !this.input_undersigned
            this.input_remarks = !this.input_remarks
            this.input_diagnose = !this.input_diagnose
            this.input_due = !this.input_due
        },

        openMedicalCertificate(data) {
            this.data = data;
            
            // Fetch host code and host province from the mixin
            // const host_code = this.provider_type(this.$store.state.usr_credentials.lgu_host_code)[0].title;
            // const host_province = this.provider_type(this.$store.state.usr_credentials.lgu_host_code)[0].subtitle;

            this.medical_certificate_qr_value =`City: ${this.$store.state.prv_data.municipality}\nProvince: ${this.$store.state.prv_data.province}\nProvider Name: ${this.$store.state.prv_data.provider_name}\nMember Name: ${this.data.patient_name}\nMember ID: ${this.data.ek_lgu_id}\nCertificate Date Issued: ${this.formatDate(this.data.date_admitted)}`;
            this.show_dialog = true;
        },
        
        print() {
            window.scrollTo(0, 0);
            window.print();
        },

        close() {
            this.show_dialog = false;
        },
    }
}
</script>
