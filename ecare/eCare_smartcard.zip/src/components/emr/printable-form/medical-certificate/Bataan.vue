<template>
    <v-card id="for-print-absolute" width="1400"  class="elevation-0">
        <div id="for-print"  class="pa-8">
            <!-- MEDICAL CERTIFICATE FOR BATAAN -->
            <template>
                <Header />

                <v-row class="mt-4" align="center" justify="end" dense>
                    <v-col sm="4" md="4" lg="4">
                        <h6 class="font-weight-medium text-center body-1"> Medical Certificate </h6>
                    </v-col>

                    <v-col sm="1" md="1" lg="2"></v-col>

                    <v-col class="text-center" sm="3" md="3" lg="2">
                        <h6 class="border-bottom body-2">{{ data.date_admitted }}</h6>
                        <h6 class="font-weight-medium body-2 mt-1">Date</h6>
                    </v-col>
                </v-row>

                <v-row align="baseline" dense>
                    <v-col sm="4" md="2" lg="2">
                        <h6 class="font-weight-medium text-right body-2">This is to certify that</h6>
                    </v-col>

                    <v-col sm="8" md="10" lg="10">
                        <span class="border-bottom body-2 d-block">{{ data.patient_name }}</span>
                    </v-col>                
                </v-row>

                <div class="align-end d-flex">
                    <span class="font-weight-medium from-brgy body-2 mb-6">from Brgy.</span>

                    <div class="flex-grow-1">
                        <h6 class="border-bottom body-2">{{ data.address }}</h6>
                        <h6 class="font-weight-medium text-center body-2 mt-1">Address</h6>
                    </div>
                    
                    <span class="font-weight-medium text-no-wrap body-2 mb-6">, Bataan consulted the undersigned due to/for</span>
                </div>

                <span class="border-bottom body-2 d-block mt-n1"> {{ data.chief_complaint }}</span>   
                
                <v-divider class="darken-1 grey mt-7 mb-2"></v-divider>

                <div class="align-baseline d-flex mt-4">
                    <span class="font-weight-medium impression-diagnosis body-2">Impression / Diagnosis</span>

                    <div class="flex-grow-1">
                        <h6 v-if="data.impression_diagnosis.length === 0" class="white--text">.</h6>
                        <h6 v-else v-for="(value, index) in data.impression_diagnosis" :key="index" class="body-2">{{ value.icd_code + '/' + value.icd_description }}</h6>
                        <v-divider class="darken-1 grey"></v-divider>
                    </div>
                </div>

                <div class="font-weight-medium align-end d-flex body-2 mt-4">
                    This has been upon request of <v-divider class="darken-1 grey mx-2"></v-divider> for
                </div>

                <div class="font-weight-medium align-end d-flex body-2 mt-3">
                    <v-divider class="darken-1 grey mr-2"></v-divider> purposes.
                </div>
                
                <h6 class="font-weight-medium body-2 text-center mr-16 mt-1">(Not for medico-legal purposes)</h6>

                <h6 class="font-weight-medium body-2 mt-4">Recommendations:</h6>

                <div v-if="select_management.length >= 1" class="font-weight-medium body-2">
                    <h6 class="font-weight-medium body-2 mt-4">Management Type </h6>
                    <div v-for="(management, key) in select_management" :key="key"> 
                        <span class="body-2 pl-4 pb-2"> {{ management.management_description }} </span> 
                    </div>
                </div>
                <div v-if="doctor_notes" class="font-weight-medium body-2">
                    <h6 class="font-weight-medium body-2 mt-4">{{ $store.state.usr_credentials.department + " Notes: "}} </h6>
                    <span class="body-2 pl-4 pb-2"> {{ doctor_notes }} </span> 
                </div>

                <div v-if="include_lab_and_prescription" class="font-weight-medium body-2">
                    <div v-if="data.laboratory_request.length > 0">
                        <span class="d-block mt-2">LABORATORY REQUEST</span>
                        <span v-for="(value, index) in data.laboratory_request" :key="index" class="d-block mt-2 pl-4">{{ value }}</span>
                    </div>

                    <div v-if="data.selected_medicine.length > 0">
                        <div class="text-center d-flex mt-4">
                            <span class="medicine-item">Generic Name</span>
                            <span class="medicine-item">Dosage/Preparation</span>
                            <span class="medicine-item">Frequency (per day)</span>
                            <span class="medicine-item">Duration # of days</span>
                            <span class="medicine-item">Total # of Medicine</span>
                            <span class="medicine-item">Remarks</span>
                        </div>

                        <div v-for="(value, index) in data.selected_medicine" :key="index" class="font-weight-regular text-center d-flex mt-2">
                            <span class="medicine-item">{{ value.generic_name }}</span>
                            <span class="medicine-item">{{ value.dosage }} / {{ value.preparation }}</span>
                            <span class="medicine-item">{{ value.frequency_of_med }}</span>
                            <span class="medicine-item">{{ value.duration }}</span>
                            <span class="medicine-item"># {{ value.total_num_of_med }}</span>
                            <span class="medicine-item">{{ value.notes }}</span>
                        </div>
                    </div>
                </div>

                <v-row v-else class="font-weight-medium body-2" dense>
                    <v-col sm="6" md="6" lg="6">
                        <span class="d-block mt-4">Labs:</span>
                        <span class="d-block mt-4">Meds:</span>
                    </v-col>

                    <v-col sm="6" md="6" lg="6">
                        <span class="d-block mt-4">Rest:</span>
                        <span class="d-block mt-4">Diet:</span>
                    </v-col>
                </v-row>

                <v-row class="mt-6" justify="space-between" align="end" dense>
                    <v-col sm="6" md="6" lg="6">
                        <div class="d-print-none">
                            <h6 class="font-weight-medium body-2">PRINT OPTIONS</h6>
                            <v-checkbox v-model="include_lab_and_prescription" class="ma-0" label="INCLUDE LAB REQUEST AND PRESCRIPTION" hide-details></v-checkbox>  
                        </div>
                    </v-col>

                    <v-col class="text-center" sm="3" md="3" lg="3">
                        <h6 class="font-weight-medium body-1">{{ data.doctor_name }}</h6>
                        <h6 class="font-weight-regular body-2">{{ data.doctor_specialization}}</h6>
                        <h6 class="font-weight-regular body-2">Lic. #:{{ data.doctor_prc_license }}</h6>
                        <v-divider class="darken-1 grey mt-1"></v-divider>
                        <h6 class="font-weight-medium body-2 mt-1">Doctor</h6>
                    </v-col>
                </v-row>
            </template>

        </div>

        <Footer @editForms="editForms" :is_medical_certificate="true" :input_undersigned="input_undersigned" :input_remarks="input_remarks" @saveAsPDF="saveAsPDF" @print="print" @close="close" :emr_params="emr_params"/>
    </v-card>
</template>

<script>
import Header from '@/components/emr/printable-form/Header.vue'
import Footer from '@/components/emr/printable-form/Footer.vue'
import html2canvas from 'html2canvas'
import jsPDF from 'jspdf'

export default {    
    props: ['jspdf', 'doctor_notes', 'select_management', 'data', 'emr_params'],

    components: {
        Header,
        Footer,
    },

    data() {
        return {
            show_dialog: false,
            include_lab_and_prescription: false,
            input_undersigned: false,
            input_remarks: false,
            print_own: false,
        }
    },

    methods: {
        editForms() {
            this.input_undersigned = !this.input_undersigned
            this.input_remarks = !this.input_remarks
        },

        print() {
            window.scrollTo(0, 0);
            window.print();
        },

        close() {
            this.$emit('close'); 
        },

        saveAsPDF() {
            html2canvas(document.getElementById('for-print'), { scale: 2 }).then((canvas) => {
                let margin = 12.7; 
                let img_data = canvas.toDataURL('image/png');
                let page_width = 216;
                let page_height = 356;
                let img_width = page_width - 2 * margin; 
                let img_height = canvas.height * img_width / canvas.width; 
                let doc = new jsPDF('p', 'mm', 'a4');
                let height_left = img_height;
                let position = margin; 

                doc.addImage(img_data, 'PNG', margin, position, img_width, img_height);
                height_left -= page_height;
                while (height_left > 0) {
                    position = height_left - img_height + margin;
                    doc.addPage();
                    doc.addImage(img_data, 'PNG', margin, position, img_width, img_height);
                    height_left -= page_height;
                }

                let file_name = `PATIENT ${this.data.patient_name} MED CERT ${this.$moment().format('MM-DD-YYYY hh_mm A')}`
                doc.save(file_name + '.pdf')
            });
        }
    }
}
</script>

<style scoped>
.border-bottom, .print-border-bottom {
    border-bottom: 1px solid grey;
    margin-top: 13px; 
    padding-top: 2px;
    width: 100%;
}

.from-brgy {
    width: 74px;
}

.impression-diagnosis {
    width: 160px;
}

.medicine-item {
    width: calc(100% / 7);
}

.readonly {
    pointer-events: none;
}

.examined {
    word-spacing: 50px;
    text-align: center;
}

@media print {
    body * {
        background: white;
        position: relative;
        width: 100%;
    }

    ::v-deep .v-dialog {
        box-shadow: none;
    }

    #for-print-absolute{
        left: 0;
        padding-top: 50px;
        position: fixed !important; 
        top: 0;
    }

    .qr-code-med{
        padding-left: 75px;
    }

    .antipolo-med-cert {
        padding: 0px 50px 0px 50px !important;
    }

    .from-brgy {
        width: 165px;
    }

    .impression-diagnosis {
        width: 205px;
    }

    .remove-print-item{
        visibility: hidden;
    }
    
    .print-border-bottom {
        border-bottom: none;
    }
    
    .legal-size .undersign_text {
        margin-top: -1px;
        padding-left: 85px;
    }

    .legal-size .remakrs-field {
        margin-top: 35px;
        padding-left: 85px;
    }

    .legal-size .date-admitted {
        margin-top: 3rem;
        right: 5rem;
    }

    .legal-size .patient-name {
        top: -0.9rem;
        left: 1.5rem;
    }

    .legal-size .patient-age {
        top: -1.2rem;
        left: 3.5rem;
    }
    
    .legal-size .patient-address {
        top: -12px;
        left: 6rem;
    }

    .a4-size .undersign_text {
        margin-top: 0.8rem;
        padding-left: 40px;
    }

    .a4-size .remakrs-field {
        margin-top: 75px;
        padding-left: 40px;
    }

    .a4-size .date-admitted {
        margin-top: 0.5rem;
        right: 3.5rem;
    }

    .a4-size .patient-name {
        left: 0.5rem;
    }

    .a4-size .patient-age {
        left: 5.3rem;
    }
    
    .a4-size .patient-address {
        top: 7px;
        left: 4.6rem;
    }
}

</style>