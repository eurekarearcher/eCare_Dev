<template>
    <v-card id="for-print-absolute" width="1400" class="elevation-0">
        <div id="for-print" class="pa-8">
            <v-sheet class="antipolo-med-cert"> 
                <Header />
                <v-row class="mt-4" align="center" justify="end" dense>
                    <v-col sm="12" md="12" lg="12">
                        <h6 class="font-weight-medium text-center text-h4 grey--text text--darken-4">Medical Certification</h6>
                    </v-col>
                </v-row>

                <v-row class="mt-6" align="center" justify="end" dense>
                    <v-col sm="1" md="1" lg="2"></v-col>

                    <v-col class="text-center mt-4" sm="3" md="3" lg="2">
                        <h6 class="border-bottom body-2">{{ data.date_admitted }}</h6>
                        <h6 class="font-weight-medium body-2 mt-1">Date</h6>
                    </v-col>
                </v-row>

                <v-row align="baseline" dense class="mt-5">
                    <v-col sm="4" md="2" lg="2">
                        <h6 class="font-weight-medium text-left body-2">To whom it concern,</h6>
                    </v-col>              
                </v-row>

                <v-row align="baseline" dense class="antipolo">
                    <v-col sm="4" md="2" lg="2">
                        <h6 class="font-weight-medium text-right  body-2">This is to certify that</h6>
                    </v-col>

                    <v-col sm="8" md="10" lg="10" class="d-flex justify-space-around mt-n2">
                        <span class="border-bottom body-2 d-block mr-2">{{ data.patient_name }}</span>
                        <div class="body-2 d-flex align-baseline text-no-wrap "> <span class="border-bottom body-2" style="width: 150px;"> {{ data.patient_age }} </span> <span class="body-2"> years old </span> </div>
                    </v-col>               
                </v-row>

                <div class="font-weight-medium align-end d-flex body-2 text-no-wrap mt-4">
                    and presently residing at <span class="border-bottom body-2 d-block mt-1 ml-2" style="visibility: visible;">{{ data.address }}</span>
                </div>

                <div :class="[print_own ? 'remove-print-item' : '', 'font-weight-medium align-end d-flex body-2 mt-5 justify-center text-no-wrap']">
                    <span :class="print_own ? 'remove-print-item examined' : 'examined'"> was thoroughly examined by the undersigned for </span> 
                </div>
                
                <div v-if="print_own" :class="[print_own ? 'undersign_text' : 'mt-5', 'px-1 body-2 d-block  print-border-bottom ']">
                    <pre class="body-2 undersign_text"> {{ data.input_undersigned_field }} </pre>
                </div>   

                <div v-else class="px-1 body-2 d-block mt-3">
                    <v-text-field v-model="data.input_undersigned_field" :readonly="!input_undersigned" :class="{'readonly': !input_undersigned}" hide-details dense ></v-text-field>
                </div>    

                <div class="font-weight-medium align-end d-flex body-2 mt-7 mb-4">
                    &nbsp;<v-divider class="darken-1 grey mr-2"></v-divider>
                </div>

                <div class="font-weight-medium align-end d-flex body-2 mt-7">
                    <h6 class="font-weight-medium body-1 mr-2">Remarks:</h6>
                </div>

                <div v-if="input_remarks" class="mt-5">
                    <v-textarea name="input-1-1" v-model="data.input_remarks_field" :readonly="!input_remarks" :style="input_remarks" outlined hide-details dense></v-textarea>
                </div>

                <div v-else class="remakrs-field d-block ml-2" style="margin-bottom: 200px;">
                    <pre style="white-space: pre-wrap;">{{ data.input_remarks_field }}</pre>
                </div>

                <v-row class="mt-6" justify="space-between" align="end" dense>
                    <v-col sm="6" md="6" lg="6">
                        <h6 class="font-weight-medium body-2">Note: <span class="ml-2"> Not valid for MEDICO LEGAL purposes <br/> <span class="ml-12"> Not valid without official seal</span> </span> </h6>
                    </v-col>

                    <v-col class="text-center" sm="3" md="3" lg="3">
                        <h6 class="font-weight-medium body-1">{{ $store.state.usr_credentials.lgu_host_code === 'BT' || $store.state.usr_credentials.lgu_host_code === 'SJ'? data.doctor_name : data.doctor_name2 + ", MD."}}</h6>
                        <h6 class="font-weight-regular body-2">{{ $store.state.usr_credentials.lgu_host_code === 'BT' || $store.state.usr_credentials.lgu_host_code === 'SJ'? data.doctor_specialization : data.doctor_position}}</h6>
                        <h6 class="font-weight-regular body-2">Lic. #:{{ data.doctor_prc_license }}</h6>
                        <template v-if="$store.state.usr_credentials.lgu_host_code === 'BT' || $store.state.usr_credentials.lgu_host_code === 'SJ'"> 
                            <v-divider class="darken-1 grey mt-1"></v-divider>
                            <h6  class="font-weight-medium body-2 mt-1">Doctor</h6>
                        </template>
                    </v-col>
                </v-row>
            </v-sheet>

            <v-layout wrap class="mt-8 pl-10 ml-10">
                <!-- Medical Certificate QR Code Section -->
                <v-sheet id="medical-certificate" class="qr-code-med" style="box-shadow: none; border: none;">
                    <QrcodeVue :value="medical_certificate_qr_value" :size="90" renderAs="svg" />
                </v-sheet>
            </v-layout>
        </div>
        <Footer @editForms="editForms" :is_medical_certificate="true" :input_undersigned="input_undersigned" :input_remarks="input_remarks" @saveAsPDF="saveAsPDF" @print="print" @close="close" :emr_params="emr_params"/>
    </v-card>
</template>

<script>
import html2canvas from 'html2canvas'
import jsPDF from 'jspdf'
import Header from '@/components/emr/printable-form/Header.vue'
import Footer from '@/components/emr/printable-form/Footer.vue'
import QrcodeVue from 'qrcode.vue';

export default {    
    props: ['jspdf', 'doctor_notes', 'select_management', 'data', 'medical_certificate_qr_value', 'emr_params'],

    components: {
        Header,
        Footer,
        QrcodeVue
    },

    data() {
        return {
            show_dialog: false,
            include_lab_and_prescription: false,
            input_undersigned: false,
            input_remarks: false,
            print_own: false,
        }
    },

    methods: {
        editForms() {
            this.input_undersigned = !this.input_undersigned
            this.input_remarks = !this.input_remarks
        },

        print() {
            window.scrollTo(0, 0);
            window.print();
        },

        close() {
            this.$emit('close'); 
        },

        saveAsPDF() {
            html2canvas(document.getElementById('for-print'), { scale: 2 }).then((canvas) => {
                let margin = 12.7; 
                let img_data = canvas.toDataURL('image/png');
                let page_width = 216;
                let page_height = 356;
                let img_width = page_width - 2 * margin; 
                let img_height = canvas.height * img_width / canvas.width; 
                let doc = new jsPDF('p', 'mm', 'a4');
                let height_left = img_height;
                let position = margin; 

                doc.addImage(img_data, 'PNG', margin, position, img_width, img_height);
                height_left -= page_height;
                while (height_left > 0) {
                    position = height_left - img_height + margin;
                    doc.addPage();
                    doc.addImage(img_data, 'PNG', margin, position, img_width, img_height);
                    height_left -= page_height;
                }

                let file_name = `PATIENT ${this.data.patient_name} MED CERT ${this.$moment().format('MM-DD-YYYY hh_mm A')}`
                doc.save(file_name + '.pdf')
            });
        }
    }
}
</script>

<style scoped>
.border-bottom, .print-border-bottom {
    border-bottom: 1px solid grey;
    margin-top: 13px; 
    padding-top: 2px;
    width: 100%;
}

.from-brgy {
    width: 74px;
}

.impression-diagnosis {
    width: 160px;
}

.medicine-item {
    width: calc(100% / 7);
}

.readonly {
    pointer-events: none;
}

.examined {
    word-spacing: 50px;
    text-align: center;
}

@media print {
    body * {
        background: white;
        position: relative;
        width: 100%;
    }

    ::v-deep .v-dialog {
        box-shadow: none;
    }

    #for-print-absolute{
        left: 0;
        padding-top: 50px;
        position: fixed !important; 
        top: 0;
    }

    .qr-code-med{
        padding-left: 75px;
    }

    .antipolo-med-cert {
        padding: 0px 50px 0px 50px !important;
    }

    .from-brgy {
        width: 165px;
    }

    .impression-diagnosis {
        width: 205px;
    }

    .remove-print-item{
        visibility: hidden;
    }
    
    .print-border-bottom {
        border-bottom: none;
    }
    
    .legal-size .undersign_text {
        margin-top: -1px;
        padding-left: 85px;
    }

    .legal-size .remakrs-field {
        margin-top: 35px;
        padding-left: 85px;
    }

    .legal-size .date-admitted {
        margin-top: 3rem;
        right: 5rem;
    }

    .legal-size .patient-name {
        top: -0.9rem;
        left: 1.5rem;
    }

    .legal-size .patient-age {
        top: -1.2rem;
        left: 3.5rem;
    }
    
    .legal-size .patient-address {
        top: -12px;
        left: 6rem;
    }

    .a4-size .undersign_text {
        margin-top: 0.8rem;
        padding-left: 40px;
    }

    .a4-size .remakrs-field {
        margin-top: 75px;
        padding-left: 40px;
    }

    .a4-size .date-admitted {
        margin-top: 0.5rem;
        right: 3.5rem;
    }

    .a4-size .patient-name {
        left: 0.5rem;
    }

    .a4-size .patient-age {
        left: 5.3rem;
    }
    
    .a4-size .patient-address {
        top: 7px;
        left: 4.6rem;
    }
}

</style>
