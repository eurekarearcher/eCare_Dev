<template>
    <div class="cf3_test" >
        <v-row class="wrap mb-12" justify="space-between">
            <v-col cols="4" sm="4" md="4" lg="4" xl="4" align-self="center">
                <v-img src="@/assets/philhealth.png" class="image_logo" lazy-src="@/assets/philhealth.png"></v-img> <!-- width:300 height:100 -->
            </v-col>

            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="text-center">
                <h5 class="h5-header text-center">This may be reproduce and  is NOT FOR SALE</h5>
                <h1 class="h1-header font-weight-bold ">CF-3</h1>
                <h4 class="h4-header">(Claim Form)</h4>
                <h4 class="h4-header font-weight-regular">revised September 2013</h4>
            </v-col>
        </v-row> 

        <v-row class="wrap py-1 mb-3 border-top border-bottom">
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="py-1 border-top border-bottom">
                <h3 class="h3-header text-center">PART I - PATIENT'S CLINICAL RECORD</h3>
            </v-col>
        </v-row>

        <v-row class="wrap">
            <v-col cols="9" sm="9" md="9" lg="9" xl="9" class="pa-2">
                <div class="wrap mb-5"> <!-- 1. PhilHealth Accreditation Number (PAN) of Health Care Institution -->
                    <h4 class="h4-header mr-5">1. PhilHealth Accreditation Number (PAN) of Health Care Institution:</h4> 
                    <div class="box_no_top_pan">{{cf3_data_p1.TRANSACTION.prov_phic_accreditation_number ? cf3_data_p1.TRANSACTION.prov_phic_accreditation_number.charAt(0) : ''}}</div>
                    <div class="box_no_top_pan">{{cf3_data_p1.TRANSACTION.prov_phic_accreditation_number ? cf3_data_p1.TRANSACTION.prov_phic_accreditation_number.charAt(1) : ''}}</div>
                    <div class="box_no_top_pan">{{cf3_data_p1.TRANSACTION.prov_phic_accreditation_number ? cf3_data_p1.TRANSACTION.prov_phic_accreditation_number.charAt(2) : ''}}</div>
                    <div class="box_no_top_pan">{{cf3_data_p1.TRANSACTION.prov_phic_accreditation_number ? cf3_data_p1.TRANSACTION.prov_phic_accreditation_number.charAt(3) : ''}}</div>
                    <div class="box_no_top_pan">{{cf3_data_p1.TRANSACTION.prov_phic_accreditation_number ? cf3_data_p1.TRANSACTION.prov_phic_accreditation_number.charAt(4) : ''}}</div>
                    <div class="box_no_top_pan">{{cf3_data_p1.TRANSACTION.prov_phic_accreditation_number ? cf3_data_p1.TRANSACTION.prov_phic_accreditation_number.charAt(5) : ''}}</div>
                    <div class="box_no_top_pan">{{cf3_data_p1.TRANSACTION.prov_phic_accreditation_number ? cf3_data_p1.TRANSACTION.prov_phic_accreditation_number.charAt(6) : ''}}</div>
                    <div class="box_no_top_pan">{{cf3_data_p1.TRANSACTION.prov_phic_accreditation_number ? cf3_data_p1.TRANSACTION.prov_phic_accreditation_number.charAt(7) : ''}}</div>
                    <div class="box_no_top_pan">{{cf3_data_p1.TRANSACTION.prov_phic_accreditation_number ? cf3_data_p1.TRANSACTION.prov_phic_accreditation_number.charAt(8) : ''}}</div>
                </div>

                <v-row class="mb-5"><!-- 2. NAME OF PATIENT -->
                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" > 
                        <h4 class="h4-header">2. Name of Patient </h4>
                        <v-row class="wrap mt-5"> 
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                                <h5 class="h5-header text-center border-bottom">{{cf3_data_p1.PRINCIPAL_DATA.last_name ? cf3_data_p1.PRINCIPAL_DATA.last_name :'N/A'}}</h5>
                                <h6 class="sub-header text-center font-weight-regular pa-0 ma-0">Last Name,</h6>
                            </v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                                <h5 class="h5-header text-center border-bottom">{{cf3_data_p1.PRINCIPAL_DATA.first_name ? cf3_data_p1.PRINCIPAL_DATA.first_name : 'N/A'}}</h5>
                                <h6 class="sub-header text-center font-weight-regular pa-0 ma-0">First Name,</h6>
                            </v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                                <h5 class="h5-header text-center border-bottom ">{{cf3_data_p1.PRINCIPAL_DATA.middle_name ? cf3_data_p1.PRINCIPAL_DATA.middle_name : 'N/A'}}</h5>
                                <h6 class="sub-header text-center font-weight-regular pa-0 ma-0">Middle Name</h6>
                            </v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                                <h5 class="h5-header text-center border-bottom" :class="{'white--text' : cf3_data_p1.PRINCIPAL_DATA.suffix == ''}">{{cf3_data_p1.PRINCIPAL_DATA.suffix ? cf3_data_p1.PRINCIPAL_DATA.suffix  : 'N/A'}}</h5>
                                <h6 class="sub-header-subtitle text-center font-weight-regular pa-0 ma-0">(example: Dela Cruz, Juan Jr., Sipag)</h6>
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>
                
                <!--4. DATE AND TIME ADMITTED -->
                <div class="wrap mb-5">  
                    <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                        <v-row no-gutters class="wrap">
                            <v-col cols="8" sm="8" md="8" lg="8" xl="8"> <!-- DATE ADMITTED --->
                                <v-row class="wrap" align="baseline">
                                    <h4 class="h4-header mr-2">4. Date Admitted</h4>
                                    <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                        <v-row class="wrap">
                                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_admitted ? cf3_data_p1.TRANSACTION.date_admitted.charAt(0) : ''}}</v-col>
                                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_admitted ? cf3_data_p1.TRANSACTION.date_admitted.charAt(1) : ''}}</v-col>
                                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                                <label class="sub-header-subtitle">Month</label>
                                            </v-col>
                                        </v-row>
                                    </v-col>
                                    <h6>-</h6>
                                    <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                        <v-row class="wrap">
                                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_admitted ? cf3_data_p1.TRANSACTION.date_admitted.charAt(3) : ''}}</v-col>
                                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_admitted ? cf3_data_p1.TRANSACTION.date_admitted.charAt(4) : ''}}</v-col>
                                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                                <label class="sub-header-subtitle">Day</label>
                                            </v-col>
                                        </v-row>
                                    </v-col>
                                    <h6>-</h6>
                                    <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                                        <v-row class="wrap">
                                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_admitted ? cf3_data_p1.TRANSACTION.date_admitted.charAt(6) : ''}}</v-col>
                                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_admitted ? cf3_data_p1.TRANSACTION.date_admitted.charAt(7) : ''}}</v-col>
                                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_admitted ? cf3_data_p1.TRANSACTION.date_admitted.charAt(8) : ''}}</v-col>
                                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_admitted ? cf3_data_p1.TRANSACTION.date_admitted.charAt(9) : ''}}</v-col>
                                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                                <label class="sub-header-subtitle">Year</label>
                                            </v-col>
                                        </v-row>
                                    </v-col>
                                </v-row>   
                            </v-col>
                            <v-col cols="4" sm="4" md="4" lg="4" xl="4"> <!-- TIME ADMITTED --->
                                <v-row no-gutters class="wrap">
                                    <h4 class="h4-header mr-2">Time Admitted</h4>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="ml-n1">
                                        <v-row no-gutters class="wrap">
                                            <v-col cols="8" sm="8" md="8" lg="8" xl="8">
                                                <h6 class="box_no_top font-weight-regular" :class="{'white--text' : cf3_data_p1.TRANSACTION.time_admitted.time_am === '00:00'}">{{cf3_data_p1.TRANSACTION.time_admitted.time_am}}</h6>
                                                <h6 class="small font-weight-regular text-center">hh mm</h6>
                                            </v-col>
                                            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="font-data font-weight-bold px-1">AM</v-col>
                                        </v-row>
                                    </v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="ml-2">
                                        <v-row no-gutters class="wrap">
                                            <v-col cols="8" sm="8" md="8" lg="8" xl="8">
                                                <h6 class="box_no_top font-weight-regular" :class="{'white--text' : cf3_data_p1.TRANSACTION.time_admitted.time_pm === '00:00'}">{{cf3_data_p1.TRANSACTION.time_admitted.time_pm}}</h6>
                                                <h6 class="small font-weight-regular text-center">hh mm</h6>
                                            </v-col>
                                            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="font-data font-weight-bold px-1">PM</v-col>
                                        </v-row>
                                    </v-col>
                                </v-row>   
                            </v-col>
                        </v-row>
                    </v-col>
                </div>

                <!--5. DATE AND TIME DISCHARGE -->
                <div class="wrap">  
                    <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                        <v-row no-gutters class="wrap">
                            <v-col cols="8" sm="8" md="8" lg="8" xl="8"> <!-- DATE ADMITTED --->
                                <v-row class="wrap" align="baseline">
                                    <h4 class="h4-header mr-2">5. Date Discharged</h4>
                                    <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                        <v-row class="wrap">
                                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_discharged ? cf3_data_p1.TRANSACTION.date_discharged.charAt(0) : ''}}</v-col>
                                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_discharged ? cf3_data_p1.TRANSACTION.date_discharged.charAt(1) : ''}}</v-col>
                                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                                <label class="sub-header-subtitle">Month</label>
                                            </v-col>
                                        </v-row>
                                    </v-col>
                                    <h6>-</h6>
                                    <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                        <v-row class="wrap">
                                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_discharged ? cf3_data_p1.TRANSACTION.date_discharged.charAt(3) : ''}}</v-col>
                                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_discharged ? cf3_data_p1.TRANSACTION.date_discharged.charAt(4) : ''}}</v-col>
                                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                                <label class="sub-header-subtitle">Day</label>
                                            </v-col>
                                        </v-row>
                                    </v-col>
                                    <h6>-</h6>
                                    <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                                        <v-row class="wrap">
                                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_discharged ? cf3_data_p1.TRANSACTION.date_discharged.charAt(6) : ''}}</v-col>
                                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_discharged ? cf3_data_p1.TRANSACTION.date_discharged.charAt(7) : ''}}</v-col>
                                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_discharged ? cf3_data_p1.TRANSACTION.date_discharged.charAt(8) : ''}}</v-col>
                                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p1.TRANSACTION.date_discharged ? cf3_data_p1.TRANSACTION.date_discharged.charAt(9) : ''}}</v-col>
                                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                                <label class="sub-header-subtitle">Year</label>
                                            </v-col>
                                        </v-row>
                                    </v-col>
                                </v-row>   
                            </v-col>
                            <v-col cols="4" sm="4" md="4" lg="4" xl="4"> <!-- TIME ADMITTED --->
                                <v-row no-gutters class="wrap">
                                    <h4 class="h4-header mr-2">Time Discharged</h4>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="ml-n1">
                                        <v-row no-gutters class="wrap">
                                            <v-col cols="8" sm="8" md="8" lg="8" xl="8">
                                                <h6 class="box_no_top font-weight-regular" :class="{'white--text' : cf3_data_p1.TRANSACTION.time_discharged.time_am === '00:00'}">{{cf3_data_p1.TRANSACTION.time_discharged.time_am}}</h6>
                                                <h6 class="small font-weight-regular text-center">hh mm</h6>
                                            </v-col>
                                            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="font-data font-weight-bold px-1">AM</v-col>
                                        </v-row>
                                    </v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="ml-2">
                                        <v-row no-gutters class="wrap">
                                            <v-col cols="8" sm="8" md="8" lg="8" xl="8">
                                                <h6 class="box_no_top font-weight-regular" :class="{'white--text' : cf3_data_p1.TRANSACTION.time_discharged.time_pm === '00:00'}">{{cf3_data_p1.TRANSACTION.time_discharged.time_pm}}</h6>
                                                <h6 class="small font-weight-regular text-center">hh mm</h6>
                                            </v-col>
                                            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="font-data font-weight-bold px-1">PM</v-col>
                                        </v-row>
                                    </v-col>
                                </v-row>   
                            </v-col>
                        </v-row>
                    </v-col>
                </div>
            </v-col>

            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="pa-6"><!-- 3. Chief Complaint / Reason for Admission -->
                <v-row class="border pa-1" style="height:100%">
                    <h5 class="h5-header">3. Chief Complaint / Reason for Admission:</h5>
                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" style="height:100%">
                        <p class="font-data word-wrap">{{cf3_data_p1.PATIENT_DATA.chief_complaint ? cf3_data_p1.PATIENT_DATA.chief_complaint : 'N/A'}}</p>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>
        
        <v-row class="height_45 border-top wrap pa-2" >  <!-- 6. Brief History of Patient Illness / OB History -->
            <h4 class="h4-header">6. Brief History of Present Illness / OB History:</h4>
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="word-wrap" style="height:100%">
                <p class="font-data word-wrap">{{cf3_data_p1.PATIENT_DATA.illness_hstry ? cf3_data_p1.PATIENT_DATA.illness_hstry : 'N/A'}}</p>
            </v-col>
        </v-row>
  
        <v-row no-gutters class="border-top wrap pa-2"><!-- 7.  Physical Examination ( Pertinent Findings per System ) -->
            <h4 class="h4-header">7. Physical Examination ( Pertinent Findings per System )</h4>
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-5">
                <div class="wrap">
                    <h5 class="h5-header mr-10">General Survey:</h5>
                    <h5 class="h5-header font-weight-regular">{{cf3_data_p1.PE_DATA.general_survey ? cf3_data_p1.PE_DATA.general_survey : 'N/A'}}</h5>
                </div>
            </v-col>

            <v-row no-gutters class="wrap">
                <v-col cols="8" sm="8" md="8" lg="8" xl="8">
                    <v-row align="center" no-gutters class="wrap mb-7">
                        <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                            <h5 class="h5-header mr-2">Vital Signs :</h5>
                        </v-col>
                        <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                            <v-row class="wrap">
                                <h5 class="h5-header mr-2">BP</h5>
                                <h5 class="h5-header border-bottom font-weight-regular" style="width:50%">{{cf3_data_p1.PE_DATA.vital_sign_bp ? cf3_data_p1.PE_DATA.vital_sign_bp : 'N/A'}}</h5>
                            </v-row>
                        </v-col>
                        <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                            <v-row class="wrap">
                                <h5 class="h5-header mr-2">CR</h5>
                                <h5 class="h5-header border-bottom font-weight-regular" style="width:50%">{{cf3_data_p1.PE_DATA.vital_sign_bp ? cf3_data_p1.PE_DATA.vital_sign_cr : 'N/A'}}</h5>
                            </v-row>
                        </v-col>
                        <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                            <v-row class="wrap">
                                <h5 class="h5-header mr-2">RR</h5>
                                <h5 class="h5-header border-bottom font-weight-regular" style="width:50%">{{cf3_data_p1.PE_DATA.vital_sign_bp ? cf3_data_p1.PE_DATA.vital_sign_rr : 'N/A'}}</h5>
                            </v-row>
                        </v-col>
                        <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                            <v-row class="wrap">
                                <h5 class="h5-header mr-2">Temperature</h5>
                                <h5 class="h5-header border-bottom font-weight-regular" style="width:30%">{{cf3_data_p1.PE_DATA.vital_sign_bp ? cf3_data_p1.PE_DATA.vital_sign_temp : 'N/A'}}</h5>
                            </v-row>
                        </v-col>
                    </v-row>
                    <v-row class="wrap mb-7" align="center" no-gutters>
                        <v-col cols="2">
                            <h5 class="h5-header mr-2">HEENT :</h5>
                        </v-col>
                        <v-col cols="10">
                            <template v-if="cf3_data_p1.PE_DATA.pe_heent && cf3_data_p1.PE_DATA.pe_heent.length > 0">
                                <span  v-for="(heent, i) in cf3_data_p1.PE_DATA.pe_heent" :key="i" class="font-weight-regular h5-header word-wrap">
                                    {{ heent.assessment || 'N/A' }}
                                    <span v-if="i < cf3_data_p1.PE_DATA.pe_heent.length - 1">, </span>
                                </span>
                            </template>
                            <span v-else>N/A</span>
                        </v-col>
                    </v-row>

                    <v-row class="wrap mb-7" no-gutters>
                        <v-col cols="2">
                            <h5 class="h5-header mr-2">Chest/Lungs :</h5>
                        </v-col>
                        <v-col cols="10">
                            <template v-if="cf3_data_p1.PE_DATA.pe_chest_lungs && cf3_data_p1.PE_DATA.pe_chest_lungs.length > 0">
                                <span v-for="(item, i) in cf3_data_p1.PE_DATA.pe_chest_lungs" :key="i" class="font-weight-regular h5-header">
                                    {{ item.assessment || 'N/A' }}
                                    <span v-if="i < cf3_data_p1.PE_DATA.pe_chest_lungs.length - 1">, </span>
                                </span>
                            </template>
                            <span v-else>N/A</span>
                        </v-col>
                    </v-row>

                    <v-row class="wrap mb-5" no-gutters>
                        <v-col cols="2">
                            <h5 class="h5-header mr-2">CVS :</h5>
                        </v-col>
                        <v-col cols="10">
                            <template v-if="cf3_data_p1.PE_DATA.pe_cvs && cf3_data_p1.PE_DATA.pe_cvs.length > 0">
                                <span v-for="(item, i) in cf3_data_p1.PE_DATA.pe_cvs"  :key="i" class="font-weight-regular h5-header">
                                    {{ item.assessment || 'N/A' }}
                                    <span v-if="i < cf3_data_p1.PE_DATA.pe_cvs.length - 1">, </span>
                                </span>
                            </template>
                            <span v-else>N/A</span>
                        </v-col>
                    </v-row>
                </v-col>
                <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                    <v-row class="wrap mb-7" no-gutters>
                        <v-col cols="4">
                            <h5 class="h5-header mr-2">Abdomen :</h5>
                        </v-col>
                        <v-col cols="8">
                            <template v-if="cf3_data_p1.PE_DATA.pe_abdomen && cf3_data_p1.PE_DATA.pe_abdomen.length > 0">
                                <span v-for="(item, i) in cf3_data_p1.PE_DATA.pe_abdomen" :key="i" class="font-weight-regular h5-header">
                                    {{ item.assessment || 'N/A' }}
                                    <span v-if="i < cf3_data_p1.PE_DATA.pe_abdomen.length - 1">, </span>
                                </span>
                            </template>
                            <span v-else>N/A</span>
                        </v-col>
                    </v-row>

                    <v-row class="wrap mb-7" no-gutters>
                        <v-col cols="4">
                            <h5 class="h5-header mr-2">GU (IE) :</h5>
                        </v-col>
                        <v-col cols="8">
                            <template v-if="cf3_data_p1.PE_DATA.pe_gu_ie && cf3_data_p1.PE_DATA.pe_gu_ie.length > 0">
                                <span v-for="(item, i) in cf3_data_p1.PE_DATA.pe_gu_ie"  :key="i" class="font-weight-regular h5-header">
                                    {{ item.assessment || 'N/A' }}
                                    <span v-if="i < cf3_data_p1.PE_DATA.pe_gu_ie.length - 1">, </span>
                                </span>
                            </template>
                            <span v-else>N/A</span>
                        </v-col>
                    </v-row>

                    <v-row class="wrap mb-7" no-gutters>
                        <v-col cols="4">
                            <h5 class="h5-header mr-2">Skin/Extremities :</h5>
                        </v-col>
                        <v-col cols="8">
                            <template v-if="cf3_data_p1.PE_DATA.pe_skin_extremities && cf3_data_p1.PE_DATA.pe_skin_extremities.length > 0">
                                <span v-for="(item, i) in cf3_data_p1.PE_DATA.pe_skin_extremities"  :key="i" class="font-weight-regular h5-header">
                                    {{ item.assessment || 'N/A' }}
                                    <span v-if="i < cf3_data_p1.PE_DATA.pe_skin_extremities.length - 1">, </span>
                                </span>
                            </template>
                            <span v-else>N/A</span>
                        </v-col>
                    </v-row>

                    <v-row class="wrap mb-7" no-gutters>
                        <v-col cols="4">
                            <h5 class="h5-header mr-2">Neuro Examination :</h5>
                        </v-col>
                        <v-col cols="8">
                             <template v-if="cf3_data_p1.PE_DATA.pe_neuro_exam && cf3_data_p1.PE_DATA.pe_neuro_exam.length > 0">
                                <span v-for="(item, i) in cf3_data_p1.PE_DATA.pe_neuro_exam"  :key="i" class="font-weight-regular h5-header">
                                    {{ item.assessment || 'N/A' }}
                                    <span v-if="i < cf3_data_p1.PE_DATA.pe_neuro_exam.length - 1">, </span>
                                </span>
                            </template>
                            <span v-else>N/A</span>
                        </v-col>
                    </v-row>
                    
                </v-col>
            </v-row>
        </v-row>

        <div align="start" class="border-top wrap pa-2" :class="{'height_45' : cf3_data_p1.COURSE_IN_THE_WARD.length >0 }">   <!-- 8. Course in the Wards (attach additional sheets if necessary) -->
            <h4 class="h4-header">8. Course in the Wards <span class="h6-header"> (attach additional sheets if necessary)</span></h4>
            <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                <table border="0" class="text-center" style="width:100%" v-show="cf3_data_p1.COURSE_IN_THE_WARD.length > 0">
                    <thead>
                        <tr class="h5-header">
                            <td style="border-bottom:1px solid black;border-top:1px solid black;width:30%">Date</td>
                            <td style="border-bottom:1px solid black;border-top:1px solid black;width:70%">Doctors's Order/Action</td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(course,i) in cf3_data_p1.COURSE_IN_THE_WARD" :key="i" class="h5-header">
                            <td>{{course.date}}</td>
                            <td>{{course.doctors_order}}</td>
                        </tr>
                    </tbody>
                </table>
            </v-col>
        </div>
        
        <div align="start" class="border-top wrap pa-2" :class="{'height_45' : cf3_data_p1.PERTINENT_LABORATORY.length >0}">   <!-- 9. Pertinent Laboratory and Diagnostic Findings: ( CBC, Urinalysis, Fecalysis, X-ray, Biopsy, etc. ) -->
            <h4 class="h4-header">9. Pertinent Laboratory and Diagnostic Findings:<span class="font-data">( CBC, Urinalysis, Fecalysis, X-ray, Biopsy, etc. )</span></h4>
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="word-wrap">
                <table border="0" class="text-center" style="width:100%" v-show="cf3_data_p1.PERTINENT_LABORATORY.length > 0">
                    <thead>
                        <tr class="h5-header">
                            <td style="border-bottom:1px solid black;border-top:1px solid black;width:30%">Date</td>
                            <td style="border-bottom:1px solid black;border-top:1px solid black;width:70%;">Description</td>
                        </tr>
                    </thead>
                    <tbody >
                        <tr v-for="(course,i) in cf3_data_p1.PERTINENT_LABORATORY" :key="i" class="h5-header">
                            <td>{{course.date_of_lab}}</td>
                            <td>{{course.description}}</td>
                        </tr>
                    </tbody>
                </table>
            </v-col>
        </div>

        <div class="border-top border-bottom wrap" >  <!--10. Disposition on Discharge: -->
            <h4 class="h4-header mr-1">10. Disposition on Discharge:</h4>
            <v-row justify="space-between">
                <v-col cols="2" sm="2" md="2" lg="2" xl="2" align-self="center">
                    <input onclick="return false" :checked="cf3_data_p1.PATIENT_DATA.patient_disposition === 'I'" type="checkbox"> <label  class="mx-2 sub-header">Improved</label>
                </v-col>
                <v-col cols="2" sm="2" md="2" lg="2" xl="2" align-self="center">
                    <input onclick="return false" :checked="cf3_data_p1.PATIENT_DATA.patient_disposition === 'T'" type="checkbox"> <label  class="mx-2 sub-header-diagnosis ">Transfered</label>
                </v-col>
                <v-col cols="2" sm="2" md="2" lg="2" xl="2" align-self="center">
                    <input onclick="return false" :checked="cf3_data_p1.PATIENT_DATA.patient_disposition === 'H'" type="checkbox"> <label  class="mx-2 sub-header  ">HAMA</label>
                </v-col>
                <v-col cols="2" sm="2" md="2" lg="2" xl="2" align-self="center">
                    <input onclick="return false" :checked="cf3_data_p1.PATIENT_DATA.patient_disposition === 'A'" type="checkbox"> <label  class="mx-2 sub-header-diagnosis">Absconded</label>
                </v-col>
                <v-col cols="2" sm="2" md="2" lg="2" xl="2" align-self="center">
                    <input onclick="return false" :checked="cf3_data_p1.PATIENT_DATA.patient_disposition === 'E'" type="checkbox"> <label  class="mx-2 sub-header ">EXPIRED</label>
                </v-col>
            </v-row>
        </div>
    </div>
</template>

<script>
export default {
    props:["menu","cf3_data_p1"],
}
</script>

<style scoped>
  .border{border:1px solid black}
  .border-top{border-top:1px solid black}
  .border-bottom{ border-bottom:1px solid black}
  .box{
     align-items: center;
     border:1px solid black;
     display: flex;
     font-size:8pt;
     height:2em;
     justify-content: center;
     text-align:center;
     width:2%;
  }
  .box_no_top_pan{
    border-left:1px solid black;
    border-right:1px solid black;
    border-bottom:1px solid black;
    font-size:10pt;
    text-align: center;
    width:2%;
  }
  .box_no_top{
    border-left:1px solid black;
    border-right:1px solid black;
    border-bottom:1px solid black;
    font-size:10pt;
    text-align: center;
  }
  .cf3_test{
    padding-top:3em ;
    padding-left:2.35em !important;
    padding-right:2.55em !important;
  }
  
  .h1-header{ font-size:34pt;line-height:0.8;}
  .h3-header{font-size:14pt}
  .h4-header{font-size:11.5pt}
  .h4-header{font-size:11pt}
  .h5-header{font-size:9pt}
  .h5-reminder{font-size:7.3pt}
  .height_45{
    height:35vh;
    width:100%
   }
  .hide-content{display: none}
  .font-data{ font-size:9pt}
  .image_logo{
     width:200px;
     height:70px;
  }

  .p-y-12{padding-top:3em;padding-bottom:3em}
  .m-b-12{margin-bottom:5em}
  .line-height-sub{line-height: 0.8;}
  .p-b-1{padding-bottom:0.25em}
  .p-b-2{padding-bottom:0.5em}
  .p-b-3{padding-bottom:0.7em}
  .p-b-4{padding-bottom:1em}
  
  .small{font-size:8pt}
  .sub-header,.sub-header-diagnosis{font-size:8pt}
  .sub-header-subtitle{font-size:7pt}
  .word-wrap{word-wrap: break-word}
      
.wrap {
    display: flex;
    flex-wrap: wrap !important;
}

@media print{
  .cf3_test{
    padding:0.25em 0 0!important
  }
  .h1-header{font-size:16pt;line-height:0.8 !important;}
  .h3-header,.font-header{font-size:10pt !important}
  .h4-header,   .font-data{font-size:7pt !important}
  .h5-reminder{font-size:7.2pt !important}
  .h5-header{font-size:6.5pt}
  .height_45{height:10vh}
  .m-b-12{margin-bottom:0}

  .p-y-12{padding-top:1.5em;padding-bottom: 1.5em;}

  .sub-header, .box_no_top, .small{font-size:6pt}
  .sub-header-subtitle,.sub-header-diagnosis,.dis_check_lbl{font-size:5pt}
    .wrap {
        flex-wrap: wrap !important;
    }
}
</style>

