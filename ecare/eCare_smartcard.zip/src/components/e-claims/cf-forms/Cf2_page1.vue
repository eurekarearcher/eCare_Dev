<template>
  <div class="cf2_test" >
    <v-row class="border-bottom pb-2 px-2 mx-1 wrap">
      <v-col cols="2" sm="2" md="2" lg="2" xl="2" align-self="center">
        <v-img src="@/assets/philhealth.png" class="image_logo" lazy-src="@/assets/philhealth.png"></v-img>
      </v-col>

      <v-col cols="8" sm="8" md="8" lg="8" xl="8" class="text-center roman">
          <h4 class="font-weight-regular h4-header"><i>Republic of the Philippines</i></h4>
          <h3 class="h3-header">PHILIPPINE HEALTH INSURANCE CORPORATION</h3>
          <h4 class="h4-header font-weight-regular mb-0" style="line-height:1">Citystate Centre 709 Shaw Boulevard, Pasig City</h4>
          <h4 class="h4-header font-weight-regular mb-0" style="line-height:1">Call Center (02) 441-7442 * Trunkline (02) 441-7444</h4>
          <h4 class="h4-header font-weight-regular mb-0" style="line-height:1">www.philhealth.gov.ph</h4>
          <h4 class="h4-header font-weight-regular mb-0" style="line-height:1">email:actioncenter@philhealth.gov.ph</h4>
      </v-col>
      
      <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="text-center">
          <h4 class="h4-header font-weight-regular text-center" style="line-height:1;">This may be reproduce and <br/> is NOT FOR SALE</h4>
          <h1 class="h1-header font-weight-bold ">CF-2</h1>
          <h4 class="h4-header mb-0">(Claim Form 2)</h4>
          <h4 class="h4-header font-weight-regular">Revised September 2018</h4>
      </v-col>

      <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="padding-1">
          <v-row wrap justify="end">
              <label class="h4-header mr-3">Series # &nbsp; </label>
              <div class="box"></div>
              <div class="box"></div>
              <div class="box"></div>
              <div class="box"></div>
              <div class="box"></div>
              <div class="box"></div>
              <div class="box"></div>
              <div class="box"></div>
              <div class="box"></div>
              <div class="box"></div>
              <div class="box"></div>
              <div class="box"></div>
              <div class="box"></div>
          </v-row>
      </v-col>
    </v-row> 
   
    <h4 class="h4-header mt-4 px-1">IMPORTANT REMINDERS: </h4>
    <h5 class="h5-reminder font-weight-regular px-1" >PLEASE WRITE IN CAPITAL <b>LETTERS</b> AND <b>CHECK</b> THE APPROPRIATE BOXES</h5>
    <h5 class="h5-reminder font-weight-regular px-1" >This form together with other supporting documents should be filed within sixty (60) calendar days from date of discharge</h5>
    <h5 class="h5-reminder font-weight-regular px-1" >All information, fields and trick boxes required in this form are necessary. Claim forms with incomplete information sha ll not be processed</h5>
    <h5 class="h5-reminder px-1 p-b-2">FALSE/INCORRECT INFORMATION OR MISREPRESENTATION SHALL BE SUBJECT TO CRIMINAL, CIVIL OR ADMINISTRATIVE LIABILITIES.</h5>
    
    <h3 class=" text-center font-header white--text black padding-y1" >PART I - HEALTH CARE INSTITUTION (HCI) INFORMATION</h3>
    <v-row class="pa-2 mt-2 wrap" no-gutters>
          <h4 class="h4-header mr-5 ml-3">1. PhilHealth Accreditation Number (PAN) of Health Care Institution:</h4>
          <div class="box_no_top_pan">{{cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(0) : ''}}</div>
          <div class="box_no_top_pan">{{cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(1) : ''}}</div>
          <div class="box_no_top_pan">{{cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(2) : ''}}</div>
          <div class="box_no_top_pan">{{cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(3) : ''}}</div>
          <div class="box_no_top_pan">{{cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(4) : ''}}</div>
          <div class="box_no_top_pan">{{cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(5) : ''}}</div>
          <div class="box_no_top_pan">{{cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(6) : ''}}</div>
          <div class="box_no_top_pan">{{cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(7) : ''}}</div>
          <div class="box_no_top_pan">{{cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf2_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(8) : ''}}</div>
          <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="my-1"> <!--  Name of Health Care Institution: -->
              <v-row class="wrap" no-gutters>
                <v-col cols="3" sm="3" md="3" lg="3" xl="3" bg>
                    <h4 class="h4-header">2. Name of Health Care Institution: </h4>
                </v-col>
                <v-col cols="9" sm="9" md="9" lg="9" xl="9">
                    <h6 class=" border-bottom font-data">{{cf2_data_p1.TRANSACTION.provider_name ? cf2_data_p1.TRANSACTION.provider_name : 'N/A'}}</h6>
                </v-col>
              </v-row>
          </v-col>

          <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="my-1"> <!--  Name of Health Care Institution: -->
            <v-row class="wrap" no-gutters>
                <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                    <h4 class="h4-header">3. Address</h4>
                </v-col>
                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2">
                    <h6 class=" text-center border-bottom font-data capitalize">{{cf2_data_p1.prv_barangay ? cf2_data_p1.prv_barangay : ''}}</h6>
                    <h6 class="sub-header text-center font-weight-regular pa-0 ma-0">Building Number and Street Name</h6>
                </v-col>
                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2">
                    <h6 class=" text-center border-bottom font-data capitalize">{{cf2_data_p1.prv_municipality ? cf2_data_p1.prv_municipality : ''}}</h6>
                    <h6 class="sub-header text-center font-weight-regular pa-0 ma-0">City Municipality</h6>

                </v-col>
                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2">
                    <h6 class=" text-center border-bottom font-data capitalize">{{cf2_data_p1.prv_province ? cf2_data_p1.prv_province : ''}}</h6>
                    <h6 class="sub-header text-center font-weight-regular pa-0 ma-0">Province</h6>

                </v-col>
            </v-row>
        </v-col>
    </v-row>

    <h3 class="text-center font-header white--text black padding-y1">PART II -  PATIENT CONFINEMENT INFORMATION</h3>
    <div class="border-bottom px-2 py-3 wrap">  
        <v-row class="p-b-4 wrap" no-gutters> <!--  Name of Patient: -->
            <v-col cols="2" sm="2" md="2" lg="2" xl="2" >
                <h4 class="h4-header">1. Name of Patient</h4>
            </v-col>
            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{cf2_data_p1.PRINCIPAL_DATA.last_name ? cf2_data_p1.PRINCIPAL_DATA.last_name : 'N/A'}}</h6>
                <h6 class="sub-header font-weight-regular text-center">Last Name</h6>
            </v-col>
            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{cf2_data_p1.PRINCIPAL_DATA.first_name ? cf2_data_p1.PRINCIPAL_DATA.first_name : 'N/A'}}</h6>
                <h6 class="sub-header font-weight-regular text-center">First Name</h6>
            </v-col>
            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                <h6 :class="{'white--text' : cf2_data_p1.PRINCIPAL_DATA.suffix == ''}" class="sub-header text-center border-bottom">{{cf2_data_p1.PRINCIPAL_DATA.suffix ? cf2_data_p1.PRINCIPAL_DATA.suffix  : 'N/A'}}</h6>
                <h6 class="sub-header font-weight-regular text-center" style="line-height:1.3">Name Extension <br/><span style="font-size:7pt">(JR/SR/III)</span></h6>
            </v-col>
            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{cf2_data_p1.PRINCIPAL_DATA.middle_name ? cf2_data_p1.PRINCIPAL_DATA.middle_name : 'N/A'}}</h6>
                <h6 class="sub-header font-weight-regular text-center" style="line-height:1.3">Middle Name <br/> <span class="sub-header-subtitle">(ex: DELA CRUZ JUAN JR SIPAG)</span></h6>
            </v-col>
        </v-row>

        <div class="p-b-4 wrap"> <!-- refered by another HCI -->
            <h4 class="h4-header" style="width:100%">2. Was patient referred by another Health Care Institution (HCI)?</h4>
            <v-row wrap no-gutters>
                <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-3">
                    <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.is_referred === 'NO'" type="checkbox"  ><label  class="mx-2 font-label">No</label>
                    <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.is_referred === 'YES'" type="checkbox"  ><label  class="mx-2 font-label" >Yes</label>
                </v-col>

                <v-col cols="10" sm="10" md="10" lg="10" xl="10">
                    <v-row wrap>
                        <v-col cols="4" sm="4" md="4" lg="4" xl="4" class="px-2">
                            <h6 class="sub-header text-center border-bottom capitalize">{{cf2_data_p1.PATIENT_DATA.originating_provider ? cf2_data_p1.PATIENT_DATA.originating_provider : 'N/A'}}</h6>
                            <h6 class="sub-header font-weight-regular pa-0 ma-0 text-center">Name of referring Health Care Institution</h6>
                        </v-col>
                        <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2">
                            <h6 class="sub-header text-center border-bottom capitalize">{{cf2_data_p1.PATIENT_DATA.originating_provider_address.building ? cf2_data_p1.PATIENT_DATA.originating_provider_address.building : ''}}</h6>
                            <h6 class="sub-header font-weight-regular pa-0 ma-0 text-center">Building Number and Street Name</h6>

                        </v-col>
                        <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                            <h6 class="sub-header text-center border-bottom capitalize">{{cf2_data_p1.PATIENT_DATA.originating_provider_address.city_municipality ? cf2_data_p1.PATIENT_DATA.originating_provider_address.city_municipality : ''}}</h6>
                            <h6 class="sub-header font-weight-regular pa-0 ma-0 text-center">City/Municipality</h6>

                        </v-col>
                        <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                            <h6 class="sub-header text-center border-bottom capitalize">{{cf2_data_p1.PATIENT_DATA.originating_provider_address.province ? cf2_data_p1.PATIENT_DATA.originating_provider_address.province : ''}}</h6>
                            <h6 class="sub-header font-weight-regular pa-0 ma-0 text-center">Province</h6>

                        </v-col>
                            <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="px-2">
                            <h6 class="sub-header text-center border-bottom capitalize">{{cf2_data_p1.PATIENT_DATA.originating_provider_address.zip_code ? cf2_data_p1.PATIENT_DATA.originating_provider_address.zip_code : ''}}</h6>
                            <h6 class="sub-header font-weight-regular pa-0 ma-0 text-center">Zip code</h6>
                        </v-col>
                    </v-row>
                </v-col>
            </v-row>
        </div>
        
        <!--  Confinement Period: -->
        <v-row align="baseline" class="p-b-4 wrap" no-gutters>
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="p-b-2 my-1">
                <v-row align="baseline" class="mb-2 wrap">
                    <!-- ADMITTED -->
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                        <h4 class="h4-header">3. Confinement Period</h4>
                    </v-col>
                
                    <!-- DATE ADMITTED -->
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                        <v-row align="baseline" justify="center" class="wrap">
                            <h6 class="sub-header mr-2 font-weight-regular">a. Date Admitted</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_admitted ? cf2_data_p1.PATIENT_DATA.date_admitted.charAt(0) : ''}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_admitted ? cf2_data_p1.PATIENT_DATA.date_admitted.charAt(1) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">Month</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                            <h6>-</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_admitted ? cf2_data_p1.PATIENT_DATA.date_admitted.charAt(3) : ''}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_admitted ? cf2_data_p1.PATIENT_DATA.date_admitted.charAt(4) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">Day</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                            <h6>-</h6>
                            <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                                <v-row class="wrap">
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_admitted ? cf2_data_p1.PATIENT_DATA.date_admitted.charAt(6) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_admitted ? cf2_data_p1.PATIENT_DATA.date_admitted.charAt(7) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_admitted ? cf2_data_p1.PATIENT_DATA.date_admitted.charAt(8) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_admitted ? cf2_data_p1.PATIENT_DATA.date_admitted.charAt(9) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">Year</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                        </v-row>
                    </v-col>
                
                    <!-- TIME ADMITTED -->
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                        <v-row align="baseline" justify="center" class="wrap">
                            <h6 class="sub-header mr-2 font-weight-regular">b. Time Admitted</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.time_admitted ? this.$moment(cf2_data_p1.PATIENT_DATA.time_admitted, 'HH:mm:ss').format('hh:mm A').charAt(0) : ''}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.time_admitted ? this.$moment(cf2_data_p1.PATIENT_DATA.time_admitted, 'HH:mm:ss').format('hh:mm A').charAt(1) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">hour</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                            <h6> : </h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.time_admitted ? this.$moment(cf2_data_p1.PATIENT_DATA.time_admitted, 'HH:mm:ss').format('hh:mm A').charAt(3) : ''}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.time_admitted ? this.$moment(cf2_data_p1.PATIENT_DATA.time_admitted, 'HH:mm:ss').format('hh:mm A').charAt(4) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">min</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                        </v-row>
                    </v-col>
                
                    <!-- CHECK BOX -->
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="text-center">
                        <v-row class="align-center">
                            <input onclick="return false" :checked="this.$moment(cf2_data_p1.PATIENT_DATA.time_admitted, 'HH:mm:ss').format('hh:mm A').includes('AM')" type="checkbox">
                            <label class="mx-2 font-label">AM</label>
                            <input onclick="return false" :checked="this.$moment(cf2_data_p1.PATIENT_DATA.time_admitted, 'HH:mm:ss').format('hh:mm A').includes('PM')" type="checkbox">
                            <label class="mx-2 font-label">PM</label>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>


        <v-row align="baseline" class="p-b-4 wrap" no-gutters> <!-- DISCHARGED -->
            <v-col cols="2" sm="2" md="2" lg="2" xl="2">&nbsp;</v-col>
            <v-col cols="4" sm="4" md="4" lg="4" xl="4"> <!-- DATE DISCHARGE --->
                <v-row align="baseline" class="wrap">
                    <h6 class="sub-header mr-2 font-weight-regular">c. Date Discharge</h6>
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                        <v-row class="wrap">
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_discharged ? cf2_data_p1.PATIENT_DATA.date_discharged.charAt(0)  : ''}}</v-col>
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_discharged ? cf2_data_p1.PATIENT_DATA.date_discharged.charAt(1) : ''}}</v-col>
                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub" ><label class="sub-header-subtitle">Month</label></v-col>
                        </v-row>
                    </v-col>
                    <h6>-</h6>
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                        <v-row class="wrap">
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_discharged ? cf2_data_p1.PATIENT_DATA.date_discharged.charAt(3) : ''}}</v-col>
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_discharged ? cf2_data_p1.PATIENT_DATA.date_discharged.charAt(4) : ''}}</v-col>
                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub" ><label class="sub-header-subtitle">Day</label></v-col>
                        </v-row>
                    </v-col>
                    <h6>-</h6>
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                        <v-row class="wrap">
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_discharged ? cf2_data_p1.PATIENT_DATA.date_discharged.charAt(6) : ''}}</v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_discharged ? cf2_data_p1.PATIENT_DATA.date_discharged.charAt(7) : ''}}</v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_discharged ? cf2_data_p1.PATIENT_DATA.date_discharged.charAt(8) : ''}}</v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.date_discharged ? cf2_data_p1.PATIENT_DATA.date_discharged.charAt(9) : ''}}</v-col>
                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub" ><label class="sub-header-subtitle">Year</label></v-col>
                        </v-row>
                    </v-col> 
                </v-row>
            </v-col>

            <v-col cols="4" sm="4" md="4" lg="4" xl="4"> <!-- TIME DISCHARGE --->
                <v-row align="baseline" justify="center" class="wrap">
                    <h6 class="sub-header mr-2 font-weight-regular">d. Time Discharge</h6>
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                        <v-row class="wrap">
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.time_discharged ? this.$moment(cf2_data_p1.PATIENT_DATA.time_discharged, 'HH:mm:ss').format('hh:mm A').charAt(0) : ''}}</v-col>
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.time_discharged ? this.$moment(cf2_data_p1.PATIENT_DATA.time_discharged, 'HH:mm:ss').format('hh:mm A').charAt(1) : ''}}</v-col>
                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub" ><label class="sub-header-subtitle">hour</label></v-col>
                        </v-row>
                    </v-col>
                    <h6> : </h6>
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" >
                        <v-row class="wrap">
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.time_discharged ? this.$moment(cf2_data_p1.PATIENT_DATA.time_discharged, 'HH:mm:ss').format('hh:mm A').charAt(3) : ''}}</v-col>
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p1.PATIENT_DATA.time_discharged ? this.$moment(cf2_data_p1.PATIENT_DATA.time_discharged, 'HH:mm:ss').format('hh:mm A').charAt(4) : ''}}</v-col>
                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub" ><label class="sub-header-subtitle">min</label></v-col>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
            
            <v-col cols="2" sm="2" md="2" lg="2" xl="2"> <!-- Check Box -->
                <input onclick="return false" :checked="this.$moment(cf2_data_p1.PATIENT_DATA.time_discharged, 'HH:mm:ss').format('hh:mm A').includes('AM')" type="checkbox"  name="vehicle1">
                <label  class="mx-2 font-label">AM</label>
                <input onclick="return false" :checked="this.$moment(cf2_data_p1.PATIENT_DATA.time_discharged, 'HH:mm:ss').format('hh:mm A').includes('PM')" type="checkbox"  name="vehicle1">
                <label  class="mx-2 font-label">PM</label>
            </v-col>
        </v-row>
            
        <v-row class="p-b-3 wrap" no-gutters> <!-- Patient Disposition -->
            <v-col cols="12" sm="12" md="12" lg="12" xl="12"><h4 class="h4-header">4. Patient Disposition: <span class="font-weight-regular" style="font-size:8pt;">(select only 1)</span></h4></v-col>
            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-3">
            <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.patient_disposition === 'I'" type="checkbox" ><label  class="mx-2  sub-header" >a. Improved</label><br/>
            <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.patient_disposition === 'R'" type="checkbox" ><label  class="mx-2  sub-header" >b. Recovered</label><br/>
            <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.patient_disposition === 'H'" type="checkbox" ><label  class="mx-2 sub-header" >c. Home/Discharged Against Medical Advise</label><br/>
            <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.patient_disposition === 'A'" type="checkbox" ><label  class="mx-2 sub-header" >d. Absconded</label><br/>
            </v-col>

            <v-col cols="9" sm="9" md="9" lg="9" xl="9">
                <v-row class="mb-2 wrap" no-gutters>
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" align-self="center">
                        <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.patient_disposition === 'E'"  type="checkbox" >
                        <label  class="mx-2 sub-header">e. Expired</label>
                    </v-col>

                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <v-row justify="end" class="wrap">
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row v-if="cf2_data_p1.PATIENT_DATA.patient_disposition === 'E'" class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top"  :class="{'white--text' : cf2_data_p1.PATIENT_DATA.disposition_expiration_date == '' || cf2_data_p1.PATIENT_DATA.disposition_expiration_date == null}">{{cf2_data_p1.PATIENT_DATA.disposition_expiration_date ? cf2_data_p1.PATIENT_DATA.disposition_expiration_date.charAt(5) : '0'}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top"  :class="{'white--text' : cf2_data_p1.PATIENT_DATA.disposition_expiration_date == '' || cf2_data_p1.PATIENT_DATA.disposition_expiration_date == null}">{{cf2_data_p1.PATIENT_DATA.disposition_expiration_date ? cf2_data_p1.PATIENT_DATA.disposition_expiration_date.charAt(6) : '0'}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Month</label></v-col>
                                </v-row>
                                <v-row v-else class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top white--text">0</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top white--text">0</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Month</label></v-col>
                                </v-row>
                            </v-col>
                            <h6>-</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row v-if="cf2_data_p1.PATIENT_DATA.patient_disposition === 'E'" class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top" :class="{'white--text' : cf2_data_p1.PATIENT_DATA.disposition_expiration_date == '' || cf2_data_p1.PATIENT_DATA.disposition_expiration_date == null}">{{cf2_data_p1.PATIENT_DATA.disposition_expiration_date ? cf2_data_p1.PATIENT_DATA.disposition_expiration_date.charAt(8) : '0'}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top" :class="{'white--text' : cf2_data_p1.PATIENT_DATA.disposition_expiration_date == '' || cf2_data_p1.PATIENT_DATA.disposition_expiration_date == null}">{{cf2_data_p1.PATIENT_DATA.disposition_expiration_date ? cf2_data_p1.PATIENT_DATA.disposition_expiration_date.charAt(9) : '0'}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Day</label></v-col>
                                </v-row>
                                <v-row v-else class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top white--text">0</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top white--text">0</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Day</label></v-col>
                                </v-row>
                            </v-col>
                            <h6>-</h6>
                            <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                                <v-row v-if="cf2_data_p1.PATIENT_DATA.patient_disposition === 'E'" class="wrap">
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top" :class="{'white--text' : cf2_data_p1.PATIENT_DATA.disposition_expiration_date == '' || cf2_data_p1.PATIENT_DATA.disposition_expiration_date == null}">{{cf2_data_p1.PATIENT_DATA.disposition_expiration_date ? cf2_data_p1.PATIENT_DATA.disposition_expiration_date.charAt(0) : '0'}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top" :class="{'white--text' : cf2_data_p1.PATIENT_DATA.disposition_expiration_date == '' || cf2_data_p1.PATIENT_DATA.disposition_expiration_date == null}">{{cf2_data_p1.PATIENT_DATA.disposition_expiration_date ? cf2_data_p1.PATIENT_DATA.disposition_expiration_date.charAt(1) : '0'}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top" :class="{'white--text' : cf2_data_p1.PATIENT_DATA.disposition_expiration_date == '' || cf2_data_p1.PATIENT_DATA.disposition_expiration_date == null}">{{cf2_data_p1.PATIENT_DATA.disposition_expiration_date ? cf2_data_p1.PATIENT_DATA.disposition_expiration_date.charAt(2) : '0'}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top" :class="{'white--text' : cf2_data_p1.PATIENT_DATA.disposition_expiration_date == '' || cf2_data_p1.PATIENT_DATA.disposition_expiration_date == null}">{{cf2_data_p1.PATIENT_DATA.disposition_expiration_date ? cf2_data_p1.PATIENT_DATA.disposition_expiration_date.charAt(3) : '0'}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Year</label></v-col>
                                </v-row>
                                <v-row v-else class="wrap">
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top white--text">0</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top white--text">0</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top white--text">0</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top white--text">0</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Year</label></v-col>
                                </v-row>
                            </v-col>
                        </v-row>
                    </v-col>
                    
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                        <v-row justify="center" class="wrap">
                            <h6 class="font-weight-regular mr-3">Time</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row v-if="cf2_data_p1.PATIENT_DATA.patient_disposition === 'e'" class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top"  :class="{'white--text' : cf2_data_p1.PATIENT_DATA.disposition_expiration_time == null}">{{cf2_data_p1.PATIENT_DATA.disposition_expiration_time ? this.$moment(cf2_data_p1.PATIENT_DATA.disposition_expiration_time, 'HH:mm:ss').format('hh:mm A').charAt(0) : '0'}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top"  :class="{'white--text' : cf2_data_p1.PATIENT_DATA.disposition_expiration_time == null}">{{cf2_data_p1.PATIENT_DATA.disposition_expiration_time ? this.$moment(cf2_data_p1.PATIENT_DATA.disposition_expiration_time, 'HH:mm:ss').format('hh:mm A').charAt(1) : '0'}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Hour</label></v-col>
                                </v-row>
                                <v-row v-else class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top white--text" >0</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top white--text" >0</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Hour</label></v-col>
                                </v-row>
                            </v-col>
                            <h6>-</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row v-if="cf2_data_p1.PATIENT_DATA.patient_disposition === 'e'" class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top" :class="{'white--text' : cf2_data_p1.PATIENT_DATA.disposition_expiration_time == null}">{{cf2_data_p1.PATIENT_DATA.disposition_expiration_time ? this.$moment(cf2_data_p1.PATIENT_DATA.disposition_expiration_time, 'HH:mm:ss').format('hh:mm A').charAt(3) : '0'}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top" :class="{'white--text' : cf2_data_p1.PATIENT_DATA.disposition_expiration_time == null}">{{cf2_data_p1.PATIENT_DATA.disposition_expiration_time ? this.$moment(cf2_data_p1.PATIENT_DATA.disposition_expiration_time, 'HH:mm:ss').format('hh:mm A').charAt(4) : '0'}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Min</label></v-col>
                                </v-row>
                                <v-row v-else class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top white--text" >0</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top white--text" >0</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Min</label></v-col>
                                </v-row>
                            </v-col>
                        </v-row>
                    </v-col>

                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" > <!-- Check Box -->
                        <input onclick="return false" :checked="this.$moment(cf2_data_p1.PATIENT_DATA.disposition_expiration_time, 'HH:mm:ss').format('hh:mm A').includes('AM') && cf2_data_p1.PATIENT_DATA.patient_disposition === 'e'" type="checkbox">
                        <label  class="mx-2 font-label">AM</label>
                        <input onclick="return false" :checked="this.$moment(cf2_data_p1.PATIENT_DATA.disposition_expiration_time, 'HH:mm:ss').format('hh:mm A').includes('PM') && cf2_data_p1.PATIENT_DATA.patient_disposition === 'e'" type="checkbox">
                        <label  class="mx-2 font-label">PM</label>
                    </v-col>
                </v-row>

                <v-row class="mb-2 wrap" no-gutters>
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.patient_disposition === 'T'"  type="checkbox"  name="vehicle1">
                        <label  class="mx-2 sub-header">f. Transfered/Referred</label><br/>
                    </v-col>
                    <v-col cols="9" sm="9" md="9" lg="9" xl="9">
                        <h6 class="sub-header text-center border-bottom capitalize">{{cf2_data_p1.PATIENT_DATA.referral_prov ? cf2_data_p1.PATIENT_DATA.referral_prov : ''}}</h6>
                        <h6 class="sub-header font-weight-regular text-center p-b-4">Name of Referral Health Care Institution</h6>
                
                        <v-row class="wrap p-b-3">
                            <v-col cols="4" sm="4" md="4" lg="4" xl="4" class="px-2">
                                <h6 class="sub-header text-center border-bottom capitalize">{{cf2_data_p1.PATIENT_DATA.referral_prov_address.building ? cf2_data_p1.PATIENT_DATA.referral_prov_address.building : ''}}</h6>
                                <h6 class="sub-header font-weight-regular text-center">Building Number and Street Name</h6>
                            </v-col>
                                <v-col cols="4" sm="4" md="4" lg="4" xl="4" class="px-2">
                                <h6 class="sub-header text-center border-bottom capitalize">{{cf2_data_p1.PATIENT_DATA.referral_prov_address.city_municipality ? cf2_data_p1.PATIENT_DATA.referral_prov_address.city_municipality :''}}</h6>
                                <h6 class="sub-header font-weight-regular text-center">City/Municipality</h6>
                            </v-col>
                                <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                                <h6 class="sub-header text-center border-bottom capitalize">{{cf2_data_p1.PATIENT_DATA.referral_prov_address.province ? cf2_data_p1.PATIENT_DATA.referral_prov_address.province : ''}}</h6>
                                <h6 class="sub-header font-weight-regular text-center">Province</h6>
                            </v-col>
                                <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                                <h6 class="sub-header text-center border-bottom capitalize">{{cf2_data_p1.PATIENT_DATA.referral_prov_address.zip_code ? cf2_data_p1.PATIENT_DATA.referral_prov_address.zip_code : ''}}</h6>
                                <h6 class="sub-header font-weight-regular text-center">Zip code </h6>
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>

                <v-row class="mb-2 wrap">
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3"> <h6 class="sub-header font-weight-regular ">Reason/s for referral / transfer: </h6> </v-col>
                    <v-col cols="9" sm="9" md="9" lg="9" xl="9" class="px-2"><h6 class="sub-header text-left border-bottom p-b-2">{{cf2_data_p1.PATIENT_DATA.referral_prov_address.reason ? cf2_data_p1.PATIENT_DATA.referral_prov_address.reason : ''}}</h6></v-col>
                </v-row>
            </v-col>
        </v-row>
  
        <div class="p-b-2 wrap align-baseline"> <!-- TYPE OF ACCOMODATION --> 
            <h4 class="h4-header mr-5">5. Type of Accomodation</h4>
            <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.type_of_accommodation === 'P'" type="checkbox"  name="vehicle1" ><label  class="mx-2 font-label" >Private</label>
            <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.type_of_accommodation === 'N'" type="checkbox"  name="vehicle1" ><label  class="mx-2 font-label" >Non-Private (Charity/Service)</label>
        </div>
    </div>

    <!-- <div class="border-bottom wrap px-2 py-3 pr-0">
     <h4 class="h4-header">6. Admision Diagnosis/es:</h4>
      <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="px-3"><p class="font-data mb-0" style=" word-wrap: break-word;">{{cf2_data_p1.ADMISSION_DIAGNOSIS ? cf2_data_p1.ADMISSION_DIAGNOSIS : 'N/A'}}</p></v-col>
    </div> -->

    <div class="border-bottom wrap px-2 py-3 pr-0">
        <h4 class="h4-header">6. Admission Diagnosis/es:</h4>
        <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="px-3">
            <template v-if="cf2_data_p1.ADMISSION_DIAGNOSIS && cf2_data_p1.ADMISSION_DIAGNOSIS.length > 0">
            <p v-for="(diagnosis, index) in cf2_data_p1.ADMISSION_DIAGNOSIS" :key="index" class="font-data mb-0" style="word-wrap: break-word;">
                {{ diagnosis.icd_code ? diagnosis.icd_code : 'N/A' }} - 
                {{ diagnosis.icd_description ? diagnosis.icd_description : 'N/A' }}
            </p>
            </template>
            <p v-else class="font-data mb-0" style="word-wrap: break-word;">N/A</p>
        </v-col>
    </div>

    <div class="wrap px-2 pa-1 pr-0">
        <h4 class="h4-header mt-1 mb-3">7. Discharge Diagnosis/es <span class="font-weight-regular font-label">(Use additional CF2 if necessary):</span></h4>
        <v-col cols="12" sm="12" md="12" lg="12" xl="12">
            <v-row class="wrap">
                <v-col cols="3" sm="3" md="3" lg="3" xl="3" align-self="center">
                    <h6 class="sub-header font-weight-regular text-center ">Diagnosis</h6>
                </v-col>
                <v-col cols="1" sm="1" md="1" lg="1" xl="1" align-self="center">
                    <h6  class="sub-header font-weight-regular text-center">ICD-10 Code/s</h6>
                </v-col>
                <v-col cols="4" sm="4" md="4" lg="4" xl="4" align-self="center">
                    <h6  class="sub-header font-weight-regular text-center">Related Procedure/s (if there’s any)</h6>
                </v-col>
                <v-col cols="1" sm="1" md="1" lg="1" xl="1" align-self="center">
                    <h6  class="sub-header font-weight-regular text-center">RVS CODE</h6>
                </v-col>
                <v-col cols="1" sm="1" md="1" lg="1" xl="1" align-self="center">
                    <h6  class="sub-header font-weight-regular text-center">Date of Procedure</h6>
                </v-col>
                <v-col cols="2" sm="2" md="2" lg="2" xl="2" align-self="center">
                    <h6  class="sub-header font-weight-regular text-center">Laterality (check applicable box)</h6>
                </v-col>
            </v-row>
            <!-- LOOOP -->
            <template v-if="cf2_data_p1 && cf2_data_p1.DISCHARGED_DIAGNOSIS && cf2_data_p1.DISCHARGED_DIAGNOSIS.PRIMARY && cf2_data_p1.DISCHARGED_DIAGNOSIS.PRIMARY.length > 0">
                <div v-for="(discharge,i) in cf2_data_p1.DISCHARGED_DIAGNOSIS.PRIMARY" :key="i"  class="wrap" >
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-1">
                        <h6 class="sub-header-diagnosis font-weight-regular text-center border-bottom" style=" word-wrap: break-word;">{{discharge.icd_description}} </h6>  
                    </v-col>
                    <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="px-1">
                        <h6  class="sub-header-diagnosis font-weight-regular  border-bottom">{{discharge.icd_code}}</h6>
                    </v-col>
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4" class="px-1">
                        <ol type="i">
                            <h6 class="sub-header-diagnosis font-weight-regular "><li  v-for="(procedure,x) in discharge.procedure" :key="x" class="border-bottom">{{procedure.cpt_description ? procedure.cpt_description : 'N/A'}}</li></h6>
                        </ol>
                    </v-col>

                    <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="px-2">
                        <h6 v-for="(procedure,x) in discharge.procedure" :key="x" class="sub-header font-weight-regular text-center border-bottom" :class="{'white--text' : procedure.cpt_code === null || procedure.cpt_code === ''}">{{procedure.cpt_code ? procedure.cpt_code : 'N/A'}}</h6>
                    </v-col>
                    <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="px-2">
                        <h6 v-for="(procedure,x) in discharge.procedure" :key="x" class="sub-header font-weight-regular text-center border-bottom" :class="{'white--text' : procedure.date_of_diagnosis === null}">{{procedure.date_of_diagnosis ? procedure.date_of_diagnosis : 'N/A' }}</h6>
                    </v-col>
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                        <!-- LOOP -->
                        <v-row v-for="(procedure,x) in discharge.procedure" :key="x" align="center" justify="center" class="wrap" no-gutters>
                            <input onclick="return false" :checked="procedure.laterality === 'L'" type="checkbox"><label  class="mx-2 dis_check_lbl" >left</label>
                            <input onclick="return false" :checked="procedure.laterality === 'R'" type="checkbox"><label  class="mx-2 dis_check_lbl" >right</label>
                            <input onclick="return false" :checked="procedure.laterality === 'B'" type="checkbox"><label  class="mx-2 dis_check_lbl" >both</label>
                        </v-row>
                    </v-col>
                </div>
            </template>

            <template v-else>
                <v-row class="wrap" no-gutters>
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-1">
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2" style=" word-wrap: break-word;">N/A</h6>  
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2" style=" word-wrap: break-word;">N/A</h6>  
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2" style=" word-wrap: break-word;">N/A</h6>  
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2" style=" word-wrap: break-word;">N/A</h6>  
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2" style=" word-wrap: break-word;">N/A</h6>  
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2" style=" word-wrap: break-word;">N/A</h6>  
                    </v-col>
                    <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="px-1">
                        <h6  class="sub-header font-weight-regular  border-bottom white--text p-b-2">N/A</h6>
                        <h6  class="sub-header font-weight-regular  border-bottom white--text p-b-2">N/A</h6>
                        <h6  class="sub-header font-weight-regular  border-bottom white--text p-b-2">N/A</h6>
                        <h6  class="sub-header font-weight-regular  border-bottom white--text p-b-2">N/A</h6>
                        <h6  class="sub-header font-weight-regular  border-bottom white--text p-b-2">N/A</h6>
                        <h6  class="sub-header font-weight-regular  border-bottom white--text p-b-2">N/A</h6>
                    </v-col>
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4" class="px-1">
                        <ol type="i">
                            <h6 class="sub-header font-weight-regular "><li  class="border-bottom p-b-2"><span class="white--text">N/A</span></li></h6>
                            <h6 class="sub-header font-weight-regular "><li  class="border-bottom p-b-2"><span class="white--text">N/A</span></li></h6>
                            <h6 class="sub-header font-weight-regular "><li  class="border-bottom p-b-2"><span class="white--text">N/A</span></li></h6>
                        </ol>
                        <ol type="i">
                            <h6 class="sub-header font-weight-regular "><li  class="border-bottom p-b-2"><span class="white--text">N/A</span></li></h6>
                            <h6 class="sub-header font-weight-regular "><li  class="border-bottom p-b-2"><span class="white--text">N/A</span></li></h6>
                            <h6 class="sub-header font-weight-regular "><li  class="border-bottom p-b-2"><span class="white--text">N/A</span></li></h6>
                        </ol>
                    </v-col>
                    <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="px-1">
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2">N/A</h6>
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2">N/A</h6>
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2">N/A</h6>
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2">N/A</h6>
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2">N/A</h6>
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2">N/A</h6>
                    </v-col>
                    <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="px-1">
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2">N/A</h6>
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2">N/A</h6>
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2">N/A</h6>
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2">N/A</h6>
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2">N/A</h6>
                        <h6 class="sub-header font-weight-regular text-center border-bottom white--text p-b-2">N/A</h6>
                    </v-col>
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" align-self="center">
                        <v-row justify="center" align="center" class="wrap">
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >left</label>
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >right</label>
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >both</label>
                        </v-row>
                        <v-row justify="center" align="center" class="wrap">
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >left</label>
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >right</label>
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >both</label>
                        </v-row>
                        <v-row justify="center" align="center" class="wrap">
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >left</label>
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >right</label>
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >both</label>
                        </v-row>
                        <v-row justify="center" align="center" class="wrap">
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >left</label>
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >right</label>
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >both</label>
                        </v-row>
                        <v-row justify="center" align="center" class="wrap">
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >left</label>
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >right</label>
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >both</label>
                        </v-row>
                        <v-row justify="center" align="center" class="wrap">
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >left</label>
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >right</label>
                            <input onclick="return false"  type="checkbox"  ><label  class="mx-2 dis_check_lbl p-b-2" >both</label>
                        </v-row>
                    </v-col>
                </v-row>
            </template>
        </v-col> 
    </div>

    <div class="border-bottom wrap">
        <v-col cols="12" sm="12" md="12" lg="12" xl="12">
            <h4 class="h4-header border-top border-bottom mb-1 py-1">8. Special Considerations:</h4>
            <div class="wrap px-3">
                <h6 class="sub-header font-weight-regular m-b-2">a. For the following repetitive procedures, check box that applies and enumerate the procedure/sessions dates [mm-dd-yyyy]. For chemotherapy, see guidelines.</h6>
                <v-col cols="12" sm="12" md="12" lg="12" xl="12" >
                    <v-row class="mb-2 wrap" no-gutters>
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="text-left px-2 p-b-1"> 
                            <v-row class="wrap" >
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <input  onclick="return false"  type="checkbox">
                                    <label class="mx-2 font-label">Hemodialysis</label>
                                </v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <!-- <h6 v-if="repetitive_proc_category.hemo_date.length !== 0" class="font-weight-regular border-bottom"><span></span> </h6> -->
                                    <h6  class="font-weight-regular border-bottom white--text">N/A</h6>
                                </v-col>
                            </v-row>
                        </v-col>
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="text-left px-2 p-b-1"> 
                            <v-row class="wrap" >
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <input  onclick="return false"  type="checkbox">
                                    <label class="mx-2 font-label">Blood Transfusion</label>
                                </v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <!-- <h6 v-if="repetitive_proc_category.blood_date.length !== 0" class="font-weight-regular border-bottom"><span>{{repetitive_proc_category.blood_date.join()}} </span> </h6> -->
                                    <h6 class="font-weight-regular border-bottom white--text">N/A</h6>
                                </v-col>
                            </v-row>
                        </v-col>
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="text-left px-2 p-b-1"> 
                            <v-row class="wrap" >
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <input onclick="return false"  type="checkbox">
                                    <label class="mx-2 font-label">Peritoneal Dialysis</label>
                                </v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <!-- <h6 v-if="repetitive_proc_category.peritoneal_date.length !== 0" class="font-weight-regular border-bottom"><span>{{repetitive_proc_category.peritoneal_date.join()}} </span> </h6> -->
                                    <h6  class="font-weight-regular border-bottom white--text">N/A</h6>
                                </v-col>
                            </v-row>
                        </v-col>
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="text-left px-2 p-b-1"> 
                            <v-row class="wrap" >
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <input onclick="return false"  type="checkbox">
                                    <label class="mx-2 font-label">Brachytherapy</label>
                                </v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <!-- <h6 v-if="repetitive_proc_category.brachytherapy_date.length !== 0" class="font-weight-regular border-bottom"><span>{{repetitive_proc_category.brachytherapy_date.join()}} </span> </h6> -->
                                    <h6 class="font-weight-regular border-bottom white--text">N/A</h6>
                                </v-col>
                            </v-row>
                        </v-col>
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="text-left px-2 p-b-1"> 
                            <v-row class="wrap" >
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <input  onclick="return false"  type="checkbox">
                                    <label class="mx-2 font-label">Radiotherapy</label>
                                </v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <!-- <h6 v-if="repetitive_proc_category.radiotherapy_date.length !== 0" class="font-weight-regular border-bottom"><span>{{repetitive_proc_category.radiotherapy_date.join()}} </span> </h6> -->
                                    <h6 class="font-weight-regular border-bottom white--text">N/A</h6>
                                </v-col>
                            </v-row>
                        </v-col>
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="text-left px-2 p-b-1"> 
                            <v-row class="wrap" >
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <input  onclick="return false"  type="checkbox">
                                    <label class="mx-2 font-label">Chemotherapy</label>
                                </v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <!-- <h6 v-if="repetitive_proc_category.chemotherapy_date.length !== 0" class="font-weight-regular border-bottom"><span >{{repetitive_proc_category.chemotherapy_date.join()}} </span> </h6> -->
                                    <h6 class="font-weight-regular border-bottom white--text">N/A</h6>
                                </v-col>
                            </v-row>
                        </v-col>
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="text-left px-2 p-b-1"> 
                            <v-row class="wrap" >
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <input  onclick="return false"  type="checkbox">
                                    <label class="mx-2 font-label">Radiotheraphy (Cobalt)</label>
                                </v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                        <!-- <h6 v-if="repetitive_proc_category.cobalt_date.length !== 0" class="font-weight-regular border-bottom"><span>{{repetitive_proc_category.cobalt_date.join()}} </span> </h6> -->
                                    <h6 class="font-weight-regular border-bottom white--text">N/A</h6>
                                </v-col>
                            </v-row>
                        </v-col>
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="text-left px-2 p-b-1"> 
                            <v-row class="wrap" >
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <input  onclick="return false"  type="checkbox">
                                    <label class="mx-2 font-label">Simple Debridment</label>
                                </v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <!-- <h6 v-if="repetitive_proc_category.debridment_date.length !== 0" class="font-weight-regular border-bottom"><span>{{repetitive_proc_category.debridment_date.join()}} </span> </h6> -->
                                    <h6 class="font-weight-regular border-bottom white--text">N/A</h6>
                                </v-col>
                            </v-row>
                        </v-col>
                    </v-row> 
                </v-col>
                
                <v-row class="wrap m-b-4" align="center" no-gutters>
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                        <h6 class="sub-header font-weight-regular">b. For Z-Benefit Package</h6>
                    </v-col>
                    <h6 >Z-Benefit Package Code:</h6>
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4" class="px-2">
                        <h6 class="sub-header border-bottom">{{cf2_data_p1.PATIENT_DATA.z_benefit ? cf2_data_p1.PATIENT_DATA.z_benefit : 'N/A'}}</h6>
                    </v-col>
                </v-row>
                
                <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-2">
                    <h6 class="sub-header font-weight-regular">c. For MCP Package (enumerate four dates [mm-dd-year] of pre-natal check-ups)</h6>
                    <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                        <v-row align="center" justify="space-around" class="wrap" no-gutters>
                            <h6 class="sub-header">1.</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <h6  class="sub-header font-weight-regular border-bottom">{{cf2_data_p1.PATIENT_DATA.mcp_package_date1 ? cf2_data_p1.PATIENT_DATA.mcp_package_date1 : 'N/A'}}</h6>
                            </v-col>

                            <h6 class="sub-header">2.</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <h6  class="sub-header font-weight-regular border-bottom">{{cf2_data_p1.PATIENT_DATA.mcp_package_date2 ? cf2_data_p1.PATIENT_DATA.mcp_package_date2 : 'N/A'}}</h6>
                            </v-col>

                            <h6 class="sub-header">3.</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <h6  class="sub-header font-weight-regular border-bottom">{{cf2_data_p1.PATIENT_DATA.mcp_package_date3 ? cf2_data_p1.PATIENT_DATA.mcp_package_date3 : 'N/A'}}</h6>
                            </v-col>

                            <h6 class="sub-header">4.</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <h6  class="sub-header font-weight-regular border-bottom">{{cf2_data_p1.PATIENT_DATA.mcp_package_date4 ? cf2_data_p1.PATIENT_DATA.mcp_package_date4 : 'N/A'}}</h6>
                            </v-col>
                        </v-row>
                    </v-col>
                </v-col>

                <v-row align="center" no-gutters dense class="wrap m-b-4 ma-0 pa-0">
                    <h6 class="sub-header font-weight-regular mr-5">d. For TB DOTS Package</h6>
                    <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.tb_dots === 'I'" type="checkbox"><label  class="mx-2 font-label text-no-wrap" >Intensive Phase</label>
                    <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.tb_dots === 'M'" type="checkbox"><label  class="mx-2 font-label text-no-wrap" >Maintenance Phase</label>
                    <!-- <label class="sub-header font-weight-regular">NTP Card No.</label>
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                        <h6 class="sub-header font-weight-regular border-bottom">{{cf2_data_p1.PATIENT_DATA.ntp_card_no ? cf2_data_p1.PATIENT_DATA.ntp_card_no : 'N/A'}}</h6>
                    </v-col> -->
                </v-row>
                
                <v-row justify="space-between" class="wrap m-b-3" no-gutters>
                    <h6 class="sub-header font-weight-regular mr-5">e. For Animal Bite Package (write the dates [mm-dd-year] when the following doses of vaccine were given)</h6>
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4" class="text-center">
                        <h6 class="sub-header" style=" border:1px solid black">Note: Anti Rabies Vaccine (ARV), Rabies Immunoglobulin (RIG)</h6>
                    </v-col>
                </v-row>
                
                <v-row align="center" justify="space-around" class="wrap m-b-4" no-gutters>
                    <h6 class="sub-header">DAY 0 ARV</h6>
                    <v-col cols="1" sm="1" md="1" lg="1" xl="1">
                        <h6  class="sub-header font-weight-regular border-bottom text-no-wrap">{{formatDate(cf2_data_p1.ANIMAL_BITES.animal_bite_day_0_arv) ? formatDate(cf2_data_p1.ANIMAL_BITES.animal_bite_day_0_arv) : 'N/A'}}</h6>
                    </v-col>
                    <h6 class="sub-header">DAY 3 ARV</h6>
                    <v-col cols="1" sm="1" md="1" lg="1" xl="1">
                        <h6  class="sub-header font-weight-regular border-bottom text-no-wrap">{{formatDate(cf2_data_p1.ANIMAL_BITES.animal_bite_day_3_arv) ? formatDate(cf2_data_p1.ANIMAL_BITES.animal_bite_day_3_arv) : 'N/A'}}</h6>
                    </v-col>
                    <h6 class="sub-header">DAY 7 ARV</h6>
                    <v-col cols="1" sm="1" md="1" lg="1" xl="1">
                        <h6  class="sub-header font-weight-regular border-bottom text-no-wrap">{{formatDate(cf2_data_p1.ANIMAL_BITES.animal_bite_day_7_arv) ? formatDate(cf2_data_p1.ANIMAL_BITES.animal_bite_day_7_arv) : 'N/A'}}</h6>
                    </v-col>
                    <h6 class="sub-header">RIG</h6>
                    <v-col cols="1" sm="1" md="1" lg="1" xl="1">
                        <h6  class="sub-header font-weight-regular border-bottom text-no-wrap">{{formatDate(cf2_data_p1.ANIMAL_BITES.animal_bite_rig) ? formatDate(cf2_data_p1.ANIMAL_BITES.animal_bite_rig) : 'N/A'}}</h6>
                    </v-col>
                    <h6 class="sub-header">OTHERS(specify)</h6>
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                        <h6  class="sub-header font-weight-regular border-bottom text-no-wrap">{{formatDate(cf2_data_p1.ANIMAL_BITES.animal_bite_others) ? formatDate(cf2_data_p1.ANIMAL_BITES.animal_bite_others) : 'N/A'}}</h6>
                    </v-col>
                </v-row>
                
                <v-row class="wrap m-b-4" no-gutters>
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3"><h6 class="sub-header font-weight-regular mr-5">f. For Newborn Care Package</h6></v-col>
                    <v-col cols="9" sm="9" md="9" lg="9" xl="9" class="d-flex align-center">
                        <v-row align="center" class="wrap">
                            <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.newborn_care_package === 'essential'" type="checkbox"  ><label  class="mx-1 font-label" >Essential Newborn Care</label>
                            <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.newborn_care_package === 'hearing'" type="checkbox"  ><label  class="mx-1 font-label" >Newborn Hearing Screening Test</label>
                            <input onclick="return false" :checked="cf2_data_p1.PATIENT_DATA.newborn_care_package === 'screening'" type="checkbox"  ><label  class="mr-1 font-label" >Newborn Screening Test</label>
                            <h6 class="sub-header"  style="border:1px solid black">For Newborn Screening <br/><i>please attach NBS Filter Sitcker <br> here</i></h6>
                        </v-row>
                    </v-col>
                    <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                        <h6 class="sub-header px-2 text-center mb-1"  style="border:1px solid black;width:30%">For Essential Newborn Care (check applicable boxes)</h6>
                        <v-row no-gutters class="wrap">
                            <v-col cols="3">
                                <input onclick="return false" :checked="cf2_data_p1.ESSENTIAL_NEW_BORN.immediate_drying_of_newborn === 'Immediate drying of newborn'" type="checkbox" ><label class=" font-label mx-2">Immediate drying of newborn</label><br/>
                                <input onclick="return false" :checked="cf2_data_p1.ESSENTIAL_NEW_BORN.early_skin_contact === 'Early skin-to-skin contact'" type="checkbox"  ><label class=" font-label mx-2">Early skin-to-skin contact</label>
                            </v-col>

                            <v-col cols="2" >
                                <input onclick="return false" :checked="cf2_data_p1.ESSENTIAL_NEW_BORN.time_cord_clamping === 'Timely Cord Clamping'" type="checkbox"  > <label class=" font-label">Timely cord clamping</label><br/>
                                <input onclick="return false" :checked="cf2_data_p1.ESSENTIAL_NEW_BORN.eye_prophylaxis === 'Eye Prophylaxis'" type="checkbox"  > <label class=" font-label">Eye Prophylaxis</label>
                            </v-col>

                            <v-col cols="2" class="text-no-wrap">            
                                <input onclick="return false" :checked="cf2_data_p1.ESSENTIAL_NEW_BORN.weighing_newborn === 'Weighing of the newborn'" type="checkbox"  > <label class=" font-label">Weighing of the newborn</label><br/>
                                <input onclick="return false" :checked="cf2_data_p1.ESSENTIAL_NEW_BORN.vitamin_administration === 'Vitamin K administration'" type="checkbox"  > <label class=" font-label">Vitamin K administration</label>
                            </v-col>

                            <v-col>
                              <v-row no-gutters>
                                  <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="px-3">
                                      <input onclick="return false" :checked="cf2_data_p1.ESSENTIAL_NEW_BORN.bcg_vaccination === 'BCG vaccination'" type="checkbox"><label class="mx-2 font-label">BCG vaccination </label>
                                  </v-col>
                                  <v-col cols="6" sm="6" md="6" lg="6" xl="6" >
                                      <input onclick="return false" :checked="cf2_data_p1.ESSENTIAL_NEW_BORN.hepatitis_vaccination === 'Hepatitis B vaccination'" type="checkbox"><label class="mx-2 font-label">Hepatitis B vaccination </label>
                                  </v-col>
                              </v-row>

                              <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="d-flex align-center">
                                <v-row>
                                    <input onclick="return false" :checked="cf2_data_p1.ESSENTIAL_NEW_BORN.non_seperation === 'Non-seperation of mother/baby for early breastfeeding initiation.'" type="checkbox"> <label class="mx-2 font-label">Non-separation of mother/baby for early breastfeeding initiation</label>
                                </v-row> 
                              </v-col>
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>
                
                <v-row align="center" class="wrap mb-3" no-gutters>
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4"><h6 class="font-weight-regular">g. For Outpatient HIV/AIDS Treatment Package</h6></v-col>
                    <h6 >Laboratory Number:</h6>
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4" class="px-2">
                        <h6 style="border-bottom:1px solid black">{{cf2_data_p1.PATIENT_DATA.hiv_treatment_lab_no ? cf2_data_p1.PATIENT_DATA.hiv_treatment_lab_no : 'N/A'}}</h6>
                    </v-col>
                </v-row>
            </div>
        </v-col>
    </div>

    <div class="wrap px-2 py-3 pr-0">
        <h4 class="h4-header m-b-2">9. PhilHealth Benefits:</h4>
        <v-col cols="12" sm="12" md="12" lg="12" xl="12">
            <v-row align="center" class="wrap" >
                <h6 class="sub-header mx-2">ICD 10 OR RVS CODE</h6>
                <h6 class="sub-header font-weight-regular">a. First Case Rate</h6>
                <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                    <h6 class="border-bottom">{{cf2_data_p1.FIRST_CASE_RATES.first_case_rate ?  Number(parseFloat(cf2_data_p1.FIRST_CASE_RATES.first_case_rate.replace(',', '')).toFixed(2)).toLocaleString('en',{minimumFractionDigits: 2}) : 'N/A'}}</h6>
                </v-col>
                <h6 class="sub-header font-weight-regular">2. Second Case Rate</h6>
                <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                    <h6 class="border-bottom">{{cf2_data_p1.SECOND_CASE_RATES.second_case_rate ? Number(parseFloat(cf2_data_p1.SECOND_CASE_RATES.second_case_rate.replace(',', '')).toFixed(2)).toLocaleString('en',{minimumFractionDigits: 2}) : 'N/A'}}</h6>
                </v-col>
            </v-row>
        </v-col>
    </div>

  </div>
</template>

<script>
export default {
   props:["menu","cf2_data_p1"],
   computed:{
    // repetitive_proc_category(){
    //   let hemo_date = [], blood_date = [], peritoneal_date = [], brachytherapy_date = [], radiotherapy_date = [], chemotherapy_date = [], cobalt_date = [], debridment_date = []
    //   let hemo_status,blood_status,peritoneal_status,brachytherapy_status,radiotherapy_status,chemotherapy_status,cobalt_status,debridment_status
    //   if(this.cf2_data_p1.repetitive_proc !== null){
    //     this.cf2_data_p1.repetitive_proc.map(item => {
    //       if(item.category === 'Hemodialysis'){
    //           hemo_status = true
    //           let date_hold = []
    //           for(let x =0;x< item.procedure_list.length;x++){
    //               date_hold.push(item.procedure_list[x].rvs_code+' - '+item.procedure_list[x].date_of_proc)
    //           }
    //           hemo_date = date_hold
              
    //       }else if(item.category === 'Blood Transfusion'){
    //           blood_status = true
    //           let date_hold = []
    //           for(let x =0;x< item.procedure_list.length;x++){
    //               date_hold.push(item.procedure_list[x].rvs_code+' - '+item.procedure_list[x].date_of_proc)
    //           }
    //           blood_date = date_hold
    //       }else if(item.category === 'Peritoneal Dialysis'){
    //           peritoneal_status = true
    //           let date_hold = []
    //           for(let x =0;x< item.procedure_list.length;x++){
    //               date_hold.push(item.procedure_list[x].rvs_code+' - '+item.procedure_list[x].date_of_proc)
    //           }
    //           peritoneal_date = date_hold
    //       }else if(item.category === 'Brachytherapy'){
    //           brachytherapy_status = true
    //           let date_hold = []
    //           for(let x =0;x< item.procedure_list.length;x++){
    //               date_hold.push(item.procedure_list[x].rvs_code+' - '+item.procedure_list[x].date_of_proc)
    //           }
    //           brachytherapy_date = date_hold
    //       }else if(item.category === 'Radiotherapy'){
    //           radiotherapy_status = true
    //           let date_hold = []
    //           for(let x =0;x< item.procedure_list.length;x++){
    //               date_hold.push(item.procedure_list[x].rvs_code+' - '+item.procedure_list[x].date_of_proc)
    //           }
    //           radiotherapy_date = date_hold
    //       }else if(item.category === 'Chemotherapy'){
    //           chemotherapy_status = true
    //           let date_hold = []
    //           for(let x =0;x< item.procedure_list.length;x++){
    //               date_hold.push(item.procedure_list[x].rvs_code+' - '+item.procedure_list[x].date_of_proc)
    //           }
    //           chemotherapy_date = date_hold
    //       }else if(item.category === 'Radiotherapy Cobalt'){
    //           cobalt_status = true
    //           let date_hold = []
    //           for(let x =0;x< item.procedure_list.length;x++){
    //               date_hold.push(item.procedure_list[x].rvs_code+' - '+item.procedure_list[x].date_of_proc)
    //           }
    //           cobalt_date = date_hold
    //       }else if(item.category === 'Simple Debridement'){
    //           debridment_status = true
    //           let date_hold = []
    //           for(let x =0;x< item.procedure_list.length;x++){
    //               date_hold.push(item.procedure_list[x].rvs_code+' - '+item.procedure_list[x].date_of_proc)
    //           }
    //           debridment_date = date_hold
    //       }
    //     })
    //   }
    //   return { hemo_status,hemo_date,blood_status,blood_date,peritoneal_status,peritoneal_date,brachytherapy_status,brachytherapy_date,radiotherapy_status,radiotherapy_date,chemotherapy_status,chemotherapy_date,cobalt_status,cobalt_date,debridment_status,debridment_date}
    // },

    essential_newborn_care(){
        let immediate_drying_of_newborn, time_cord_clamping, weighing_newborn, bcg_vaccination, hepatitis_vaccination, early_skin_contact, eye_prophylaxis, vitamin_administration, non_seperation
        if(this.cf2_data_p1.ESSENTIAL_NEW_BORN !== null){
            this.cf2_data_p1.ESSENTIAL_NEW_BORN.map(item => {
                if(item === 'Immediate drying of newborn') immediate_drying_of_newborn= 'Immediate drying of newborn'
                if(item === 'Timely Cord Clamping') time_cord_clamping = 'Timely Cord Clamping'
                if(item === 'Weighing of the newborn') weighing_newborn = 'Weighing of the newborn'
                if(item === 'BCG vaccination')bcg_vaccination = 'BCG vaccination'
                if(item === 'Hepatitis B vaccination') hepatitis_vaccination = 'Hepatitis B vaccination'
                if(item === 'Early skin-to-skin contact') early_skin_contact = 'Early skin-to-skin contact'
                if(item === 'Eye Prophylaxis') eye_prophylaxis = 'Eye Prophylaxis'
                if(item === 'Vitamin K administration') vitamin_administration = 'Vitamin K administration'
                if(item === 'Non-seperation of mother/baby for early breastfeeding initiation.') non_seperation = 'Non-seperation of mother/baby for early breastfeeding initiation.'
            })
        }
        return{immediate_drying_of_newborn, time_cord_clamping, weighing_newborn, bcg_vaccination, hepatitis_vaccination, early_skin_contact, eye_prophylaxis, vitamin_administration, non_seperation}
    }
  },
}
</script>


<style scoped>
  .border-bottom{ border-bottom:1px solid black}
  .border-top{border-top:1px solid black}
  .box{
     align-items: center;
     border:1px solid black;
     display: flex;
     font-size:8pt;
     height:2em;
     justify-content: center;
     text-align:center;
     width:2%;
  }
  .box_no_top_pan{
    border-left:1px solid black;
    border-right:1px solid black;
    border-bottom:1px solid black;
    font-size:10pt;
    text-align: center;
    width:2%;
  }
  .box_no_top{
    /* border-left:1px solid black;
    border-right:1px solid black;
    border-bottom:1px solid black;
    font-size:10pt;
    text-align: center; */

    border: 1px solid #000;
    height: 1.5em;
    text-align: center;
    padding: 0;
    margin: 0;
    font-size:10pt;
  }
  .cf2_test{
    padding-top:3em ;
    padding-left:2.35em !important;
    padding-right:2.55em !important;
  }
  .dis_check_lbl, .font-label{font-size:10pt}
  .font-header{ font-size:13pt}
  .h1-header{ font-size:34pt;line-height:0.8;}
  .h3-header{font-size:14pt}
  .h4-header{font-size:11.5pt}
  .h4-header{font-size:11pt}
  .h5-reminder{font-size:7.3pt}
  .hide-content{display: none}
  .font-data{ font-size:9pt}
  .image_logo{
     width:200px;
     height:70px;
  }
  .line-height-sub{line-height: 0.8;}
  .p-b-1{padding-bottom:0.25em}
  .p-b-2{padding-bottom:0.5em}
  .p-b-3{padding-bottom:0.7em}
  .p-b-4{padding-bottom:1em}
  .m-b-2{margin-bottom:0.5em}
  .m-b-3{margin-bottom:0.75em}
  .m-b-4{margin-bottom:1em}
  .roman{ font-family:'Times New Roman', Times, serif}
  .sub-header,.sub-header-diagnosis{font-size:8pt}
  .sub-header-subtitle{font-size:7pt}

.wrap {
    display: flex;
    flex-wrap: wrap !important;
}

@media print{
  .cf2_test{
    padding:0.25em 0 0!important
  }
  .h1-header{font-size:16pt;line-height:0.8 !important;}
  .h3-header,.font-header{font-size:10pt !important}
  .h4-header, .font-label, .font-data{font-size:7pt !important}
  .h5-reminder{font-size:7.2pt !important}
  .line-height-sub{line-height: 0.4;}
  .m-b-2, .m-b-3, .m-b-4{margin-bottom:0}
  .p-b-1, .p-b-2, .p-b-3, .p-b-4{padding-bottom:0}

  .sub-header, .box_no_top{font-size:6pt}
  .sub-header-subtitle,.sub-header-diagnosis{font-size:5pt}
  .dis_check_lbl{font-size:4pt}

  .wrap {
    flex-wrap: wrap;
  }

   input[type=checkbox]
        {
        
        -webkit-transform: scale(1); /* Safari and Chrome */
        transform: scale(0.8);
        padding: 0px;
       
        }
}
</style>

