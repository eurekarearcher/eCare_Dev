<template>
    <div class="cf2_test" >
        <v-row class="border-bottom pb-2 px-2 mx-1 wrap">
            <v-col cols="2" sm="2" md="2" lg="2" xl="2" align-self="center">
                <v-img src="@/assets/philhealth.png" class="image_logo" lazy-src="@/assets/philhealth.png"></v-img>
            </v-col>

            <v-col cols="8" sm="8" md="8" lg="8" xl="8" class="text-center roman">
                <h4 class="font-weight-regular h4-header"><i>Republic of the Philippines</i></h4>
                <h3 class="h3-header">PHILIPPINE HEALTH INSURANCE CORPORATION</h3>
                <h4 class="h4-header font-weight-regular mb-0" style="line-height:1">Citystate Centre 709 Shaw Boulevard, Pasig City</h4>
                <h4 class="h4-header font-weight-regular mb-0" style="line-height:1">Call Center (02) 441-7442 * Trunkline (02) 441-7444</h4>
                <h4 class="h4-header font-weight-regular mb-0" style="line-height:1">www.philhealth.gov.ph</h4>
                <h4 class="h4-header font-weight-regular mb-0" style="line-height:1">email:actioncenter@philhealth.gov.ph</h4>
            </v-col>
            
            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="text-center">
                <h4 class="h4-header font-weight-regular text-center" style="line-height:1;">This may be reproduce and <br/> is NOT FOR SALE</h4>
                <h1 class="h1-header font-weight-bold ">CF-1</h1>
                <h4 class="h4-header mb-0">(Claim Form 1)</h4>
                <h4 class="h4-header font-weight-regular">Revised September 2018</h4>
            </v-col>

            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="padding-1">
                <v-row justify="end" class="wrap">
                    <label class="h4-header mr-3">Series # &nbsp; </label>
                    <div class="box"></div>
                    <div class="box"></div>
                    <div class="box"></div>
                    <div class="box"></div>
                    <div class="box"></div>
                    <div class="box"></div>
                    <div class="box"></div>
                    <div class="box"></div>
                    <div class="box"></div>
                    <div class="box"></div>
                    <div class="box"></div>
                    <div class="box"></div>
                    <div class="box"></div>
                </v-row>
            </v-col>
        </v-row> 

        <h4 class="h4-header mt-4 px-1">IMPORTANT REMINDERS: </h4>
        <h5 class="h5-reminder font-weight-regular px-1" >PLEASE WRITE IN CAPITAL <b>LETTERS</b> AND <b>CHECK</b> THE APPROPRIATE BOXES</h5>
        <h5 class="h5-reminder font-weight-regular px-1" >This form together with other supporting documents should be filed within sixty (60) calendar days from date of discharge</h5>
        <h5 class="h5-reminder font-weight-regular px-1" >For <b>availment of benefits abroad</b>, this form together with other supporting documents should be filed within 180 days from date of discharge.</h5>
        <h5 class="h5-reminder font-weight-regular px-1" >All information, fields and trick boxes required in this form are necessary. Claim forms with incomplete information sha ll not be processed</h5>
        <h5 class="h5-reminder px-1 p-b-2">FALSE/INCORRECT INFORMATION OR MISREPRESENTATION SHALL BE SUBJECT TO CRIMINAL, CIVIL OR ADMINISTRATIVE LIABILITIES.</h5>

        <h3 class=" text-center font-header white--text black padding-y1" >PART I - MEMBER INFORMATION</h3>
        <v-row class="pa-2 mt-1 wrap">
            <h4 class="h4-header mr-5 ml-3">1. PhilHealth Identification Number (PIN) of Member:</h4>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(0) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(1) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(2) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(3) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(4) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(5) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(6) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(7) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(8) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(9) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(10) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_phic_pin.charAt(11) : ''}}</div>
        </v-row>

        <v-row align="baseline" class="p-b-4 wrap"> <!--  Name of MEMBER: -->
            <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                <v-row class="wrap">
                    <v-col cols="7" sm="7" md="7" lg="7">
                        <v-row align="center" class="wrap">
                            <h4 class="h4-header text-left pl-5">2. Name of Member:</h4>
                        </v-row>
                    </v-col>

                    <v-col cols="3" sm="3" md="3" lg="3">
                        <v-row align="center" class="wrap">
                            <h4 class="h4-header text-left pl-2">3. Date of Birth:</h4>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>

        <v-row align="baseline" class="p-b-1 pl-3 wrap"> <!--  Name of Member: -->
            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-1">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.last_name }}</h6>
                <h6 class="sub-header font-weight-regular text-center">Last Name</h6>
            </v-col>
            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-1">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.first_name }}</h6>
                <h6 class="sub-header font-weight-regular text-center">First Name</h6>
            </v-col>
            <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="px-1">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.suffix ? cf1_data_p1.PRINCIPAL_DATA.suffix : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center" style="line-height:1.3">Name Extension <br/><span style="font-size:7pt">(JR/SR/III)</span></h6>
            </v-col>
            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-1">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.middle_name }}</h6>
                <h6 class="sub-header font-weight-regular text-center" style="line-height:1.3">Middle Name <br/> <span class="sub-header-subtitle">(ex: DELA CRUZ JUAN JR SIPAG)</span></h6>
            </v-col>

            <v-col cols="5" sm="5" md="5" lg="5" xl="5" class="px-4">
                <v-row class="wrap" justify="center">
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <v-row class="wrap">
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top_pan">{{ cf1_data_p1.PRINCIPAL_DATA.birthday  ? cf1_data_p1.PRINCIPAL_DATA.birthday.charAt(0) : '' }}</v-col>
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top_pan">{{ cf1_data_p1.PRINCIPAL_DATA.birthday  ? cf1_data_p1.PRINCIPAL_DATA.birthday.charAt(1) : '' }}</v-col>
                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Month</label></v-col>
                        </v-row>
                    </v-col>
                    <h6 class="sub-header mx-1">-</h6>
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <v-row class="wrap">
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top_pan">{{ cf1_data_p1.PRINCIPAL_DATA.birthday  ? cf1_data_p1.PRINCIPAL_DATA.birthday.charAt(3) : '' }}</v-col>
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top_pan">{{ cf1_data_p1.PRINCIPAL_DATA.birthday  ? cf1_data_p1.PRINCIPAL_DATA.birthday.charAt(4) : '' }}</v-col>
                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Day</label></v-col>
                        </v-row>
                    </v-col>
                    <h6 class="sub-header mx-1">-</h6>
                    <v-col cols="5" sm="5" md="5" lg="5" xl="5">
                        <v-row class="wrap">
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top_pan">{{ cf1_data_p1.PRINCIPAL_DATA.birthday  ? cf1_data_p1.PRINCIPAL_DATA.birthday.charAt(6) : '' }}</v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top_pan">{{ cf1_data_p1.PRINCIPAL_DATA.birthday  ? cf1_data_p1.PRINCIPAL_DATA.birthday.charAt(7) : '' }}</v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top_pan">{{ cf1_data_p1.PRINCIPAL_DATA.birthday  ? cf1_data_p1.PRINCIPAL_DATA.birthday.charAt(8) : '' }}</v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top_pan">{{ cf1_data_p1.PRINCIPAL_DATA.birthday  ? cf1_data_p1.PRINCIPAL_DATA.birthday.charAt(9) : '' }}</v-col>
                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Year</label></v-col>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>

        <v-row align="baseline" class="p-b-4 wrap"> <!--  Address and Gender of Patient -->
            <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                <v-row class="wrap">
                    <v-col cols="9" sm="9" md="9" lg="9">
                        <v-row align="center" class="wrap">
                            <h4 class="h4-header text-left pl-5">4. Mailing Address: </h4>
                        </v-row>
                    </v-col>

                    <v-col cols="3" sm="3" md="3" lg="3">
                        <v-row align="center" class="wrap">
                            <h4 class="h4-header text-left pl-2">5. Sex:</h4>
                            <input onclick="return false" :checked="cf1_data_p1.PRINCIPAL_DATA.gender ? cf1_data_p1.PRINCIPAL_DATA.gender === 'M' : false" type="checkbox" class="mx-1">
                            <label class="mx-2 sub-header">Male</label><br />
                            <input onclick="return false" :checked="cf1_data_p1.PRINCIPAL_DATA.gender ? cf1_data_p1.PRINCIPAL_DATA.gender === 'F' : false" type="checkbox" class="mx-1">
                            <label class="mx-2 sub-header">Female</label>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>

        <v-row align="baseline" class="p-b-4 pl-3 wrap">
            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.mem_home_unit_room_floor ? cf1_data_p1.PRINCIPAL_DATA.mem_home_unit_room_floor : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center">Unit/Room No./Floor</h6>
            </v-col>

            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.mem_home_building_name ? cf1_data_p1.PRINCIPAL_DATA.mem_home_building_name : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center">Building Name</h6>
            </v-col>

            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.mem_home_bldgno ? cf1_data_p1.PRINCIPAL_DATA.mem_home_bldgno : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center" style="line-height:1.3">Lot/Blk/House/Bldg.No</h6>
            </v-col>

            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.mem_home_street ? cf1_data_p1.PRINCIPAL_DATA.mem_home_street : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center" style="line-height:1.3">Street</h6>
            </v-col>

            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.mem_home_subdivision ? cf1_data_p1.PRINCIPAL_DATA.mem_home_subdivision : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center" style="line-height:1.3">Subdivision/Village</h6>
            </v-col>
        </v-row>

        <v-row align="baseline" class="p-b-4 pl-3 wrap">
            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.mem_home_bgy ? cf1_data_p1.PRINCIPAL_DATA.mem_home_bgy : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center">Barangay</h6>
            </v-col>

            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.mem_home_city_municipality ? cf1_data_p1.PRINCIPAL_DATA.mem_home_city_municipality : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center">City/Municipality</h6>
            </v-col>

            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.mem_home_province ? cf1_data_p1.PRINCIPAL_DATA.mem_home_province : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center" style="line-height:1.3">Province</h6>
            </v-col>

            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.region ? cf1_data_p1.PRINCIPAL_DATA.region : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center" style="line-height:1.3">Country</h6>
            </v-col>

            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.mem_home_zip ? cf1_data_p1.PRINCIPAL_DATA.mem_home_zip : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center" style="line-height:1.3">Zip Code</h6>
            </v-col>
        </v-row>

        <v-row align="baseline" class="p-b-4 mt-2 wrap"> <!--  Contact Information -->
            <v-col cols="9" sm="9" md="9" lg="9">
                <h4 class="h4-header pl-2">6. Contact Information: </h4>
            </v-col>
        </v-row>

        <v-row align="baseline" class="p-b-4 pl-3 wrap">
            <v-col cols="4" sm="4" md="4" lg="4" xl="4" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.phone_no ?  cf1_data_p1.PRINCIPAL_DATA.phone_no : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center">Landline No. (Area Code + Tel. No.)</h6>
            </v-col>

            <v-col cols="4" sm="4" md="4" lg="4" xl="4" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.mobile_no ?  cf1_data_p1.PRINCIPAL_DATA.mobile_no : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center">Mobile No.</h6>
            </v-col>

            <v-col cols="4" sm="4" md="4" lg="4" xl="4" class="px-2">
                <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.email_add ?  cf1_data_p1.PRINCIPAL_DATA.email_add : '&nbsp;' }}</h6>
                <h6 class="sub-header font-weight-regular text-center" style="line-height:1.3">Email Address</h6>
            </v-col>
        </v-row>

        <v-row align="baseline" class="p-b-4 mt-4 wrap"> <!--  Patient is the member? -->
            <v-col cols="3" sm="3" md="3" lg="3">
                <h4 class="h4-header pl-2">7. Patient is the member? </h4>
            </v-col>

            <v-col cols="5" sm="5" md="5" lg="5">
                <v-row justify="start" align="start" class="ml-n12">
                    <input onclick="return false" :checked="cf1_data_p1.PATIENT_DATA.is_patient ? cf1_data_p1.PATIENT_DATA.is_patient === '1' : false" type="checkbox" class="mx-1"><label  class="mx-2 sub-header">Yes, Proceed to Part III</label>
                    <input onclick="return false" :checked="cf1_data_p1.PATIENT_DATA.is_patient ? cf1_data_p1.PATIENT_DATA.is_patient === '0' : false" type="checkbox" class="mx-1"><label  class="mx-2 sub-header">No, Proceed to Part II</label>
                </v-row>
            </v-col>
        </v-row>

        <h3 class=" text-center font-header white--text black padding-y1" >PART II - PATIENT INFORMATION <span class="sub-header font-weight-regular text-center">(To be filled-out only if the patient is a dependent)</span></h3>
        <v-row class="pa-2 mt-1 wrap">
            <h4 class="h4-header mr-5 ml-3">1. PhilHealth Identification Number (PIN) of Dependent:</h4>
            <div class="box_no_top_pan"></div>
            <div class="box_no_top_pan"></div>
            <div class="box_no_top_pan"></div>
            <div class="box_no_top_pan"></div>
            <div class="box_no_top_pan"></div>
            <div class="box_no_top_pan"></div>
            <div class="box_no_top_pan"></div>
            <div class="box_no_top_pan"></div>
            <div class="box_no_top_pan"></div>
            <div class="box_no_top_pan"></div>
            <div class="box_no_top_pan"></div>
            <div class="box_no_top_pan"></div>
        </v-row>

        <v-row align="baseline" class="p-b-4 wrap"> <!--  Name of Patient: -->
            <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                <v-row class="wrap">
                    <v-col cols="7" sm="7" md="7" lg="7">
                        <v-row align="center" class="wrap">
                            <h4 class="h4-header text-left pl-5">2. Name of Member:</h4>
                        </v-row>
                    </v-col>

                    <v-col cols="3" sm="3" md="3" lg="3">
                        <v-row align="center" class="wrap">
                            <h4 class="h4-header text-left pl-2">3. Date of Birth:</h4>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>

        <v-row align="baseline" class="p-b-1 pl-3 wrap"> <!--  Name of Patient: -->
            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-1">
                <h6 class="sub-header text-center border-bottom"></h6>
                <h6 class="sub-header font-weight-regular text-center">Last Name</h6>
            </v-col>
            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-1">
                <h6 class="sub-header text-center border-bottom"></h6>
                <h6 class="sub-header font-weight-regular text-center">First Name</h6>
            </v-col>
            <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="px-1">
                <h6 class="sub-header text-center border-bottom"></h6>
                <h6 class="sub-header font-weight-regular text-center" style="line-height:1.3">Name Extension <br/><span style="font-size:7pt">(JR/SR/III)</span></h6>
            </v-col>
            <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-1">
                <h6 class="sub-header text-center border-bottom"></h6>
                <h6 class="sub-header font-weight-regular text-center" style="line-height:1.3">Middle Name <br/> <span class="sub-header-subtitle">(ex: DELA CRUZ JUAN JR SIPAG)</span></h6>
            </v-col>

            <v-col cols="5" sm="5" md="5" lg="5" xl="5" class="px-4">
                <v-row class="wrap" justify="center">
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <v-row class="wrap">
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top_pan"></v-col>
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top_pan"></v-col>
                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Month</label></v-col>
                        </v-row>
                    </v-col>
                    <h6 class="sub-header mx-1">-</h6>
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <v-row class="wrap">
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top_pan"></v-col>
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top_pan"></v-col>
                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Day</label></v-col>
                        </v-row>
                    </v-col>
                    <h6 class="sub-header mx-1">-</h6>
                    <v-col cols="5" sm="5" md="5" lg="5" xl="5">
                        <v-row class="wrap">
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top_pan"></v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top_pan"></v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top_pan"></v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top_pan"></v-col>
                            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Year</label></v-col>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>

        <v-row align="baseline" class="p-b-4 wrap"><!--  Relationship of Patient: -->
            <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                <v-row class="wrap">
                    <v-col cols="9" sm="9" md="9" lg="9">
                        <v-row align="center" class="wrap">
                            <h4 class="h4-header text-left pl-5">4. Relationship to Member: </h4>
                            <input onclick="return false" type="checkbox" class="mx-1">
                            <label class="mx-2 sub-header">Child</label><br />
                            <input onclick="return false" type="checkbox" class="mx-1">
                            <label class="mx-2 sub-header">Parent</label><br />
                            <input onclick="return false" type="checkbox" class="mx-1">
                            <label class="mx-2 sub-header">Spouse</label>
                        </v-row>
                    </v-col>

                    <v-col cols="3" sm="3" md="3" lg="3">
                        <v-row align="center" class="wrap">
                            <h4 class="h4-header text-left pl-2">5. Sex:</h4>
                            <input onclick="return false" type="checkbox" class="mx-1">
                            <label class="mx-2 sub-header">Male</label><br />
                            <input onclick="return false" type="checkbox" class="mx-1">
                            <label class="mx-2 sub-header">Female</label>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>

        <h3 class=" text-center font-header white--text black padding-y1" >PART III - MEMBER CERTIFICATION</h3>

        <v-row class="pa-2 wrap">
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center my-1">
                <h6 class="mb-3" style="position:relative;z-index:2; font-size: 11px;"><i>Under the penalty of law, I attest that the information I provided in this Form are true and accurate to the best of my knowledge.</i></h6>
            </v-col>
        </v-row>

        <v-row justify="center" align="end" class="wrap">
            <v-col cols="4" sm="4" md="4" lg="4" xl="4" class="px-2 mx-5">
                <v-img :src="cf1_data_p2.TRANSACTION.patient_sign_path" height="30" contain></v-img>
                <h6 class="sub-header text-center border-bottom">{{ textCapitalize(cf1_data_p1.PRINCIPAL_DATA.first_name) + " " + textCapitalize(cf1_data_p1.PRINCIPAL_DATA.middle_name) + " " + textCapitalize(cf1_data_p1.PRINCIPAL_DATA.last_name) }}</h6>
                <h6 class="sub-header font-weight-regular text-center">Signature Over Printed Name of Member</h6>
            </v-col>
            
            <v-col cols="5" sm="5" md="5" lg="5" xl="5" class="px-2 mx-5">
                <h6 class="sub-header text-center border-bottom"></h6>
                <h6 class="sub-header font-weight-regular text-center">Signature Over Printed Name of Member’s Representative</h6>
            </v-col>
        </v-row>

        <v-row class="p-b-4 pa-2 wrap" justify="space-between">
            <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                <v-row class="wrap">
                    <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                        <v-row class="wrap" justify="center">
                            <h6 class="sub-header text-center mr-2">Date Signed:</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf1_data_p2.SIGNATURE.patient_date_signed ? cf1_data_p2.SIGNATURE.patient_date_signed.charAt(5) : ''}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf1_data_p2.SIGNATURE.patient_date_signed ? cf1_data_p2.SIGNATURE.patient_date_signed.charAt(6) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">Month</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                            <h6>-</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf1_data_p2.SIGNATURE.patient_date_signed ? cf1_data_p2.SIGNATURE.patient_date_signed.charAt(8) : ''}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf1_data_p2.SIGNATURE.patient_date_signed ? cf1_data_p2.SIGNATURE.patient_date_signed.charAt(9) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">Day</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                            <h6>-</h6>
                            <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                                <v-row class="wrap">
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf1_data_p2.SIGNATURE.patient_date_signed ? cf1_data_p2.SIGNATURE.patient_date_signed.charAt(0) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf1_data_p2.SIGNATURE.patient_date_signed ? cf1_data_p2.SIGNATURE.patient_date_signed.charAt(1) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf1_data_p2.SIGNATURE.patient_date_signed ? cf1_data_p2.SIGNATURE.patient_date_signed.charAt(2) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf1_data_p2.SIGNATURE.patient_date_signed ? cf1_data_p2.SIGNATURE.patient_date_signed.charAt(3) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">Year</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                        </v-row>
                    </v-col>

                    <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                        <v-row class="wrap" justify="center">
                            <h6 class="sub-header text-center mr-2">Date Signed:</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top"></v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top"></v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">Month</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                            <h6>-</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top"></v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top"></v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">Day</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                            <h6>-</h6>
                            <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                                <v-row class="wrap">
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top"></v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top"></v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top"></v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top"></v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">Year</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>

        <v-row class="p-b-4 pa-2 wrap"><!-- THUMB MARK--->
            <v-col cols="12" sm="12" md="12" lg="12">
                <v-row class="p-b-2 wrap">
                    <!-- Left Side -->
                    <v-col cols="auto">
                        <v-row class="wrap">
                            <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                                <p class="sub-header">
                                    If member/representative is unable to write, put right thumbmark. Member/Representative should be assisted by an HCI representative. Check the appropriate box.
                                </p>
                                <v-row align="center" class="pl-3">
                                    <input onclick="return false" type="checkbox"><label class="mx-2 sub-header">Member</label>
                                    <input onclick="return false" type="checkbox"><label class="mx-2 sub-header">Representative</label>
                                </v-row>
                            </v-col>

                            <v-col cols="auto">
                                <div style="height: 100px; width: 100px; border: 1px solid black;"></div>
                            </v-col>

                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row class="pl-2">
                                    <h6 class="sub-header">Relationship of the representative to the member</h6>
                                </v-row>

                                <v-row class="pl-2 mt-12">
                                    <h6 class="sub-header">Reason for signing on behalf of the member</h6>
                                </v-row>
                            </v-col>

                            <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                                <v-row align="center">
                                        <input onclick="return false" type="checkbox"><label  class="mx-2 sub-header">Spouse</label>
                                        <input onclick="return false" type="checkbox"><label  class="mx-2 sub-header">Child</label>
                                        <input onclick="return false" type="checkbox"><label  class="mx-2 sub-header">Parent</label> 
                                </v-row>
                                <v-row align="center" class="mt-5">
                                    <input onclick="return false" type="checkbox" ><label  class="mx-2 sub-header">Sibling</label>
                                    <input onclick="return false" type="checkbox" ><label  class="mx-2 sub-header">Others, Specify </label> <div style="margin-left: 9rem;border-bottom: 1px solid black; width: 100%;"></div>
                                </v-row>

                                <v-row class="mt-10" align="center">
                                    <input onclick="return false" type="checkbox">
                                    <label  class="mx-2 sub-header">Member is incapacitated</label> <br/>
                                </v-row>
                                
                                <v-row align="center">
                                    <input onclick="return false" type="checkbox"><label  class="mx-2 sub-header">Other Reasons</label>
                                    <v-row align="baseline">
                                        <v-col cols="12">
                                                <h6 class="border-bottom" style="width:100%;word-wrap: break-word;" ></h6>
                                        </v-col>
                                    </v-row>
                                </v-row>
                            </v-col>


                                <v-row class="wrap">
                                    <v-col cols="5" sm="5" md="5" lg="5" xl="5">
                                    </v-col>
                                    <v-col cols="7" sm="7" md="7" lg="7" xl="7">
                                        
                                    </v-col>
                                </v-row>
                        </v-row>
                    </v-col>

                    <!-- Right Side -->
                </v-row>
            </v-col>
        </v-row>

        <h3 class="text-center font-header white--text black padding-y1" >PART IV - EMPLOYER’S CERTIFICATION <span class="sub-header font-weight-regular text-center">(for employed members only)</span></h3>
        
        <v-row class="pa-2 mt-1 wrap"> <!--PhilHealth Employer Number (PEN)--->
            <h4 class="h4-header mr-5 ml-3">1. PhilHealth Employer Number (PEN):</h4>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin.charAt(0) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin.charAt(1) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin.charAt(2) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin.charAt(3) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin.charAt(4) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin.charAt(5) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin.charAt(6) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin.charAt(7) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin.charAt(8) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin.charAt(9) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin.charAt(10) : ''}}</div>
            <div class="box_no_top_pan">{{cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin ? cf1_data_p1.PRINCIPAL_DATA.mem_employer_phic_pin.charAt(11) : ''}}</div>

            <v-row align="baseline" class="wrap">
                <v-col cols="5" sm="5" md="5" lg="5">
                    <h4 class="h4-header mx-5">2.Contact No.: </h4>
                </v-col>
                <v-col cols="6" sm="6" md="6" lg="6" align-self="end">
                    <h6 style="border-bottom:1px solid black;"></h6>
                </v-col>
            </v-row>
        </v-row>

        <v-row class="mt-1 wrap border-bottom mx-1"><!--  Business Information -->
            <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                <v-row align="baseline" class="p-b-2 wrap"> 
                    <v-col cols="9" sm="9" md="9" lg="9">
                        <h4 class="h4-header ml-n2">3. Business Name:</h4>
                    </v-col>

                    <v-col cols="8" sm="8" md="8" lg="8" xl="8" offset="2" class="px-2">
                        <h6 class="sub-header text-center border-bottom">{{ cf1_data_p1.PRINCIPAL_DATA.mem_company_name ?  cf1_data_p1.PRINCIPAL_DATA.mem_company_name : '&nbsp;' }}</h6>
                        <h6 class="sub-header font-weight-regular text-center">Business Name of Employer</h6>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>

        <v-row align="baseline" class="p-b-4 mt-4 wrap"> <!--  CERTIFICATION OF EMPLOYER -->
            <v-col cols="9" sm="9" md="9" lg="9">
                <h4 class="h4-header pl-2">4. CERTIFICATION OF EMPLOYER: </h4>
            </v-col>
        </v-row>

        <v-row no-gutters class="pa-2 wrap">
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center my-1"> <!--  CERTIFICATION OF EMPLOYER: -->
                <h6 class="sub-header mb-3" style="position:relative;z-index:2">
                    <i><b>“This is to certify that the required 3/6 monthly premium contributions plus at least 6 months contributions preceding the 3 months qualifying contributions within 12
                    month period prior to the first day of confinement (sufficient regularity) have been regularly remitted to PhilHealth. Moreover, the information supplied by the member or
                    his/her representative on Part I are consistent with our available records.”</b></i>
                </h6>

                <v-row class="wrap" align="center">
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2" style="position:relative;z-index:1">
                        <h6 class="sub-header text-center border-bottom mt-2" style="position:relative;z-index:2"></h6>
                        <h6 class="sub-header font-weight-regular pa-0 ma-0" style="z-index:2">Signature Over Printed Name of Employer/Authorized Representative</h6>
                    </v-col>

                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2">
                        <h6 class="sub-header text-center border-bottom" ></h6>
                        <h6 class="sub-header font-weight-regular pa-0 ma-0">Official Capacity/Designation</h6>
                    </v-col>

                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="px-2 mt-2">
                        <v-row class="wrap" justify="center">
                            <h6 class="sub-header text-center mr-2">Date Signed:</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box"></v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box"></v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Month</label></v-col>
                                </v-row>
                            </v-col>
                            <h6 class="sub-header mx-1">-</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box"></v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box"></v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Day</label></v-col>
                                </v-row>
                            </v-col>
                            <h6 class="sub-header mx-1">-</h6>
                            <v-col cols="5" sm="5" md="5" lg="5" xl="5">
                                <v-row class="wrap">
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box"></v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box"></v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box"></v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box"></v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Year</label></v-col>
                                </v-row>
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>

        <h3 class=" text-center font-header white--text black padding-y1" >PART V - FOR PHILHEALTH USE ONLY</h3>
        <v-row class="pa-3 ma-3 wrap">
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center my-1"> <!--  PART V - FOR PHILHEALTH USE ONLY -->
                <v-row class="wrap" align="start">
                    <h6 class="sub-header text-start mr-2">Date Signed:</h6>
                    <v-col cols="5" sm="5" md="5" lg="5" xl="5">
                            <v-col cols="7" sm="7" md="7" lg="7" xl="7" class="box_no_top"></v-col>
                            <v-col cols="7" sm="7" md="7" lg="7" xl="7" class="box_no_top"></v-col>
                    </v-col>

                    <h6 class="sub-header text-start mr-2">By:</h6>
                    <v-col cols="5" sm="5" md="5" lg="5" xl="5">
                            <v-col cols="7" sm="7" md="7" lg="7" xl="7" class="box_no_top"></v-col>
                            <v-col cols="7" sm="7" md="7" lg="7" xl="7" class="box_no_top">
                                <h6 class="sub-header font-weight-regular text-center">LHIO/PRO Signature Over Printed Name</h6>
                            </v-col>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>
    </div>
</template>

<script>
export default {
    props:["menu","cf1_data_p1", "cf1_data_p2"],
}
</script>

<style scoped>
@media print{
  .cf2_test{
    padding:0.25em 0 0!important
  }
  .h1-header{font-size:16pt;line-height:0.8 !important;}
  .h3-header,.font-header{font-size:10pt !important}
  .h4-header, .font-label, .font-data{font-size:7pt !important}
  .h5-reminder{font-size:7.2pt !important}
  .line-height-sub{line-height: 0.4;}
  .m-b-2, .m-b-3, .m-b-4{margin-bottom:0}
  .p-b-1, .p-b-2, .p-b-3, .p-b-4{padding-bottom:0}

  .sub-header, .box_no_top{font-size:6pt}
  .sub-header-subtitle,.sub-header-diagnosis{font-size:5pt}
  .dis_check_lbl{font-size:4pt}
  .wrap {
    flex-wrap: wrap !important;
  }
}

.wrap {
    display: flex;
    flex-wrap: wrap !important;
}

.border-bottom{ border-bottom:1px solid black}
  .border-top{border-top:1px solid black}
  .box{
     align-items: center;
     border:1px solid black;
     display: flex;
     font-size:8px;
     height:2em;
     justify-content: center;
     text-align:center;
     width:2%;
  }
  .box_no_top_pan{
    border-left:1px solid black;
    border-right:1px solid black;
    border-bottom:1px solid black;
    font-size:10px;
    text-align: center;
    width:2%;
  }
  .box_no_top{
    border-left:1px solid black;
    border-right:1px solid black;
    border-bottom:1px solid black;
    font-size:10px;
    text-align: center;
  }
  .cf2_test{
    padding-top:3em ;
    padding-left:2.35em !important;
    padding-right:2.55em !important;
  }
 .dis_check_lbl, .font-label{font-size:10pt}
  .font-header{ font-size:13pt}
  .h1-header{ font-size:25pt;line-height:0.8;}
  .h3-header{font-size:14pt}
  .h4-header{font-size:11.5pt}
  .h4-header{font-size:11pt}
  .h5-reminder{font-size:7.3pt}
  .hide-content{display: none}
  .font-data{ font-size:9pt}
  .image_logo{
     width:200px;
     height:70px;
  }
  .line-height-sub{line-height: 0.1;}
  .p-b-1{padding-bottom:0.25em}
  .p-b-2{padding-bottom:0.5em}
  .p-b-3{padding-bottom:0.7em}
  .p-b-4{padding-bottom:1em}
  .m-b-2{margin-bottom:0.5em}
  .m-b-3{margin-bottom:0.75em}
  .m-b-4{margin-bottom:1em}
  .roman{ font-family:'Times New Roman', Times, serif}
  .sub-header,.sub-header-diagnosis{font-size:8px}
  .sub-header-subtitle{font-size:7px}
</style>