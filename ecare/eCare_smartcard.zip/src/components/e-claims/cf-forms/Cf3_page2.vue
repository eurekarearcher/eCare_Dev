<template>
    <div class="cf3_test2" >
        <v-row class="py-1 mb-2 border-top border-bottom" wrap no-gutters>
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="border-top border-bottom">
                <h2 class="h2-header text-center">PART II - MATERNITY CARE PACKAGE</h2>
            </v-col>
        </v-row>
            
        <h3 class="h3-header text-center border-bottom border-top mb-2 ">PRENATAL CONSULTATION</h3>
        <v-row class="pa-3" no-gutters wrap > 
            <!--1. Initial Prenatal Consultation-->
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-1">
                <v-row no-gutters wrap>
                    <v-col cols="8" sm="8" md="8" lg="8" xl="8"> 
                        <v-row align="baseline" wrap>
                            <h4 class="h4-header mr-2">1. Initial Prenatal Consultation</h4>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row no-gutters wrap>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date ? cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date.charAt(5) : ''}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date ? cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date.charAt(6) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">Month</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                            <h6>-</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row no-gutters wrap>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date ? cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date.charAt(8) : ''}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date ? cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date.charAt(9) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">Day</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                            <h6>-</h6>
                            <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                                <v-row no-gutters wrap>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date ? cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date.charAt(0) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date ? cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date.charAt(1) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date ? cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date.charAt(2) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date ? cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date.charAt(3) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub">
                                        <label class="sub-header-subtitle">Year</label>
                                    </v-col>
                                </v-row>
                            </v-col>
                        </v-row>   
                    </v-col>
                </v-row>
            </v-col>

            <!--2. Clinical History and Physical Examination-->
            <h4 class="h4-header">2. Clinical History and Physical Examination</h4>
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-1">
                <v-row wrap align="start" no-gutters>
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4">  <!-- A & B -->
                        <v-row justify="space-between" class="mt-2 mb-3 pl-2 pr-5">
                            <h5 class="h5-header">a. Vital signs are normal</h5>
                            <input onclick="return false" :checked="cf3_data_p2.MATERNITY_DATA.vital_sign_is_normal === 'Y'" type="checkbox" >
                        </v-row>
                        <v-row justify="space-between" class="pl-2 pr-5">
                            <h5 class="h5-header">b. Ascertain the present Pregnancy is low-Risk</h5>
                            <input onclick="return false" :checked="cf3_data_p2.MATERNITY_DATA.prsnt_preg_is_low_risk === 'Y'" type="checkbox" >
                        </v-row>
                    </v-col>

                    <v-col cols="7" sm="7" md="7" lg="7" xl="7">  <!-- C & D -->
                        <v-row justify="space-around" align="center" wrap>
                            <h5 class="h5-header my-3">c. Menstrual History</h5>
                            <v-col cols="7" sm="7" md="7" lg="7" xl="7">
                                    <v-row no-gutters justify="center" align="center" wrap>
                                        <h6 class="sub-header mr-2">LMP</h6>
                                        <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                            <v-row no-gutters wrap>
                                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box d-flex align-center">{{cf3_data_p1.PATIENT_DATA.lmp ? cf3_data_p1.PATIENT_DATA.lmp.charAt(0) : ''}}</v-col>
                                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box d-flex align-center">{{cf3_data_p1.PATIENT_DATA.lmp ? cf3_data_p1.PATIENT_DATA.lmp.charAt(1) : ''}}</v-col>
                                                <v-col cols="12" sm="12" md="12" lg="12" xl="12" style="position:relative"><h6 class="text-center small font-weight-regular" style="position:absolute;top:0;right:0;left:0">Month</h6></v-col>
                                            </v-row>
                                        </v-col>
                                        <h6 class="sub-header">-</h6>
                                        <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                            <v-row no-gutters wrap>
                                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box d-flex align-center">{{cf3_data_p1.PATIENT_DATA.lmp ? cf3_data_p1.PATIENT_DATA.lmp.charAt(3) : ''}}</v-col>
                                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box d-flex align-center">{{cf3_data_p1.PATIENT_DATA.lmp ? cf3_data_p1.PATIENT_DATA.lmp.charAt(4) : ''}}</v-col>
                                                <v-col cols="12" sm="12" md="12" lg="12" xl="12" style="position:relative"><h6 class="text-center small font-weight-regular" style="position:absolute;top:0;right:0;left:0">Day</h6></v-col>
                                            </v-row>
                                        </v-col>
                                        <h6 class="sub-header">-</h6>
                                            <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                                            <v-row no-gutters wrap>
                                                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box d-flex align-center">{{cf3_data_p1.PATIENT_DATA.lmp ? cf3_data_p1.PATIENT_DATA.lmp.charAt(6) : ''}}</v-col>
                                                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box d-flex align-center">{{cf3_data_p1.PATIENT_DATA.lmp ? cf3_data_p1.PATIENT_DATA.lmp.charAt(7) : ''}}</v-col>
                                                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box d-flex align-center">{{cf3_data_p1.PATIENT_DATA.lmp ? cf3_data_p1.PATIENT_DATA.lmp.charAt(8) : ''}}</v-col>
                                                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box d-flex align-center">{{cf3_data_p1.PATIENT_DATA.lmp ? cf3_data_p1.PATIENT_DATA.lmp.charAt(9) : ''}}</v-col>
                                                <v-col cols="12" sm="12" md="12" lg="12" xl="12" style="position:relative"><h6 class="text-center small font-weight-regular" style="position:absolute;top:0;right:0;left:0">Year</h6></v-col>
                                            </v-row>
                                        </v-col>
                                    </v-row>  
                            </v-col>
                            <v-col cols="2">
                                <v-row wrap align="center">
                                    <h6 class="sub-header-diagnosis">Age of Menarche: </h6>
                                    <h6 class="sub-header border-bottom text-center">{{cf3_data_p2.MATERNITY_DATA.age_of_menarche ? cf3_data_p2.MATERNITY_DATA.age_of_menarche : 'N/A'}}</h6>
                                </v-row>
                            </v-col>
                        </v-row>
                        

                        <v-row justify="space-between" wrap>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                                <h5 class="h5-header">d. Obstetric History</h5>
                            </v-col>
                            <v-col cols="9" sm="9" md="9" lg="9" xl="9">
                                <v-row align="center" no-gutters wrap>
                                    <h6 class="sub-header">G:</h6>
                                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                                        <h6 class="sub-header border-bottom">{{cf3_data_p2.MATERNITY_DATA.ob_history ? cf3_data_p2.MATERNITY_DATA.ob_history : 'N/A'}}</h6>
                                    </v-col>
                                    <h6>P:</h6>
                                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                                        <h6 class="sub-header border-bottom">{{cf3_data_p2.MATERNITY_DATA.ob_history ? cf3_data_p2.MATERNITY_DATA.ob_history : 'N/A'}}</h6>
                                    </v-col>
                                    <h6 class="sub-header">(</h6>
                                    <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="px-2">
                                        <h6 class="sub-header border-bottom">{{cf3_data_p2.MATERNITY_DATA.ob_history ? cf3_data_p2.MATERNITY_DATA.ob_history : 'N/A'}}</h6>
                                        <h6 class="sub-header text-center xs-small">T</h6>
                                    </v-col>
                                    <h6 class="sub-header">,</h6>
                                    <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="px-2">
                                        <h6 class="sub-header border-bottom">{{cf3_data_p2.MATERNITY_DATA.ob_history ? cf3_data_p2.MATERNITY_DATA.ob_history : 'N/A'}}</h6>
                                        <h6 class="sub-header text-center xs-small">P</h6>
                                    </v-col>
                                    <h6>,</h6>
                                    <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="px-2">
                                        <h6 class="sub-header border-bottom">{{cf3_data_p2.MATERNITY_DATA.ob_history ? cf3_data_p2.MATERNITY_DATA.ob_history : 'N/A'}}</h6>
                                        <h6 class="sub-header text-center xs-small">A</h6>
                                    </v-col>
                                    <h6 class="sub-header">,</h6>
                                    <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="px-2">
                                        <h6 class="sub-header border-bottom">{{cf3_data_p2.MATERNITY_DATA.ob_history ? cf3_data_p2.MATERNITY_DATA.ob_history : 'N/A'}}</h6>
                                        <h6 class="sub-header text-center xs-small">L</h6>
                                    </v-col>
                                    <h6 class="sub-header">)</h6>
                                </v-row>
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
    
            <!--3.  Obstetric risk factors-->
            <h4 class="h4-header">3. Obstetric risk factors</h4>
            <v-col cols="12" sm="12" md="12" lg="12" xl="12"> 
                <v-row class="pa-2 " wrap align="center" no-gutters>
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <v-row class="d-flex justify-space-between" no-gutters wrap>
                            <label  class="mx-2 font-data" style="width:70%"  >a. Multiple Pregnancy</label><input onclick="return false" :checked="cf3_data_p2.OBSTETRIC_RISK_FACTOR.multiple_pregnancy === 'Y'" type="checkbox" > 
                            <label  class="mx-2 font-data" style="width:70%" >b. Ovarian cyst</label><input onclick="return false" :checked="cf3_data_p2.OBSTETRIC_RISK_FACTOR.ovarian_cyst === 'Y'" type="checkbox" > 
                            <label  class="mx-2 font-data" style="width:70%" >c. Myoma uteri</label><input onclick="return false" :checked="cf3_data_p2.OBSTETRIC_RISK_FACTOR.myoma_uteri === 'Y'" type="checkbox" > 
                        </v-row>
                    </v-col>
                
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <v-row class="d-flex justify-space-between" wrap no-gutters>
                            <label  class="mx-2 font-data" style="width:70%" >d. Placenta previa</label><input onclick="return false" :checked="cf3_data_p2.OBSTETRIC_RISK_FACTOR.placenta_previa === 'Y'" type="checkbox" > 
                            <label  class="mx-2 font-data" style="width:70%" >e. History of 3 miscarriages</label><input onclick="return false" :checked="cf3_data_p2.OBSTETRIC_RISK_FACTOR.miscarriages === 'Y'" type="checkbox" > 
                            <label  class="mx-2 font-data" style="width:70%" >f. History of stillbirth</label> <input onclick="return false"  :checked="cf3_data_p2.OBSTETRIC_RISK_FACTOR.still_birth === 'Y'" type="checkbox" > 
                        </v-row>
                    </v-col>
            
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <v-row class="d-flex justify-space-between" wrap no-gutters>
                            <label  class="mx-2 font-data" style="width:70%" >g. History of pre-eclampsia</label> <input onclick="return false" :checked="cf3_data_p2.OBSTETRIC_RISK_FACTOR.pre_eclampsia === 'Y'"  type="checkbox" > 
                            <label  class="mx-2 font-data" style="width:70%" >h. History of eclampsia</label><input onclick="return false" :checked="cf3_data_p2.OBSTETRIC_RISK_FACTOR.eclampsia === 'Y'" type="checkbox" > 
                            <label  class="mx-2 font-data" style="width:70%" >i. Premature contraction</label><input onclick="return false" :checked="cf3_data_p2.OBSTETRIC_RISK_FACTOR.premature_contraction === 'Y'" type="checkbox" > 
                        </v-row>
                    </v-col>
                </v-row>   
            </v-col>

            <!--4.  Medical/Surgical risk factors-->
            <h4 class="h4-header">4.  Medical/Surgical risk factors</h4>
            <v-col cols="12" sm="12" md="12" lg="12" xl="12"> 
                <v-row class="pa-2" align="baseline" wrap no-gutters>
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <v-row class="d-flex justify-space-between" wrap no-gutters>
                            <label  class="mx-2 font-data" style="width:70%;" >a. Hypertension</label><input onclick="return false" :checked="cf3_data_p2.MED_SURG_RISK_FACTOR.hypertension === 'Y'" type="checkbox" > 
                            <label  class="mx-2 font-data" style="width:70%;" >b. Heart Disease</label><input onclick="return false" :checked="cf3_data_p2.MED_SURG_RISK_FACTOR.heart_disease === 'Y'" type="checkbox" > 
                            <label  class="mx-2 font-data" style="width:70%;" >c. Diabetes</label> <input onclick="return false" :checked="cf3_data_p2.MED_SURG_RISK_FACTOR.diabetes === 'Y'" type="checkbox" > 
                        </v-row>
                    </v-col>
                
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <v-row class="d-flex justify-space-between" wrap no-gutters>
                            <label  class="mx-2 font-data" style="width:70%;" >d. Thyroid Disorder</label><input onclick="return false" :checked="cf3_data_p2.MED_SURG_RISK_FACTOR.thyroid_disaster === 'Y'" type="checkbox" > 
                            <label  class="mx-2 font-data" style="width:70%;" >e. Obesity</label> <input onclick="return false" :checked="cf3_data_p2.MED_SURG_RISK_FACTOR.obesity === 'Y'" type="checkbox" > 
                            <label  class="mx-2 font-data" style="width:70%;" >f. Moderate to severe asthma</label><input onclick="return false" :checked="cf3_data_p2.MED_SURG_RISK_FACTOR.hypertension === 'Y'" type="checkbox" > 
                        </v-row>
                    </v-col>
            
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <v-row class="d-flex justify-space-between" wrap no-gutters>
                            <label  class="mx-2 font-data" style="width:70%;" >g. Epilepsy</label><input onclick="return false" :checked="cf3_data_p2.MED_SURG_RISK_FACTOR.epilepsy === 'Y'" type="checkbox" > 
                            <label  class="mx-2 font-data" style="width:70%;" >h. Renal disease</label> <input onclick="return false" :checked="cf3_data_p2.MED_SURG_RISK_FACTOR.renal_disease === 'Y'" type="checkbox" > 
                            <label  class="mx-2 font-data" style="width:70%;" >i. Bleeding disorders</label><input onclick="return false" :checked="cf3_data_p2.MED_SURG_RISK_FACTOR.bleeding_disorder === 'Y'" type="checkbox" > 
                        </v-row>
                    </v-col>
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <v-row class="d-flex justify-space-between" wrap no-gutters>
                            <label  class="mx-2 font-data" style="width:70%;" >j. History of previous cesarian section</label> <input onclick="return false" :checked="cf3_data_p2.MED_SURG_RISK_FACTOR.previous_cs === 'Y'" type="checkbox" > 
                            <label  class="mx-2 font-data" style="width:70%;" >k. History of uterine myomectomy</label><input onclick="return false" :checked="cf3_data_p2.MED_SURG_RISK_FACTOR.uterine_myomectomy === 'Y'" type="checkbox" > 
                        </v-row>
                    </v-col>
                </v-row>   
            </v-col>  

            <!--5. Admitting Diagnosis-->
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-1">
                <v-row class="d-flex justify-space-between mb-2" wrap>  
                    <h4 class="h4-header mr-2">5. Admitting Diagnosis</h4>
                    <!-- <h5 class="h5-header border-bottom" style="width:80%">{{cf3_data_p2.icd_description ? cf3_data_p2.icd_description : 'N/A'}}</h5>  -->
                    <template v-if="cf3_data_p2.ADMISSION_DIAGNOSIS && cf3_data_p2.ADMISSION_DIAGNOSIS.length > 0">
                        <v-row align="center" justify="start" class="mx-2">
                            <p v-for="(diagnosis, index) in cf3_data_p2.ADMISSION_DIAGNOSIS" :key="index" class="font-data mb-0" style="word-wrap: break-word;">
                                {{ diagnosis.icd_code ? diagnosis.icd_code : 'N/A' }} - 
                                {{ diagnosis.icd_description ? diagnosis.icd_description : 'N/A' }}
                            </p>
                        </v-row>
                    </template>
                    <p v-else class="font-data mb-0" style="word-wrap: break-word;">N/A</p>
                </v-row> 
            </v-col>

            <!--6. Delivery Plan-->
            <h4 class="h4-header">6. Delivery Plan</h4>
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-1">
                <v-row class="d-flex justify-space-between" wrap >
                    <v-col cols="5" sm="5" md="5" lg="5" xl="5">
                        <v-row class="d-flex justify-center" align="center" wrap >
                            <h5 class="sub-header font-weight-regular mx-2"> a. Orientation to MCP/Availment of Benefits</h5>
                            <input onclick="return false" :checked="cf3_data_p2.MATERNITY_DATA.orientation_to_mcp === 'Yes'" type="checkbox" name="vehicle1" value="Bike" > <br/>
                            <label class="text-center sub-header mx-2">Yes</label>
                            <input onclick="return false" :checked="cf3_data_p2.MATERNITY_DATA.orientation_to_mcp === 'No'" type="checkbox" name="vehicle1" value="Bike" > <br/>
                            <label class="text-center sub-header mx-2" >NO</label>
                        </v-row>
                    </v-col>

                    <v-col cols="7" sm="7" md="7" lg="7" xl="7">
                        <v-row class="d-flex justify-space-around" wrap align="start" no-gutters>
                            <h5 class="h5-header font-weight-regular  mr-3"> b. Expected date of delivery</h5>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row wrap no-gutters>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.expected_delivery_date ? cf3_data_p2.MATERNITY_DATA.expected_delivery_date.charAt(0) : ''}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.expected_delivery_date ? cf3_data_p2.MATERNITY_DATA.expected_delivery_date.charAt(1) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" style="position:relative"><h6 class="text-center sub-header font-weight-regular" style="position:absolute;top:0;right:0;left:0">Month</h6></v-col>
                                </v-row>
                            </v-col>
                            <h6 class="sub-header">-</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row wrap no-gutters>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.expected_delivery_date ? cf3_data_p2.MATERNITY_DATA.expected_delivery_date.charAt(3) : ''}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.expected_delivery_date ? cf3_data_p2.MATERNITY_DATA.expected_delivery_date.charAt(4) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" style="position:relative"><h6 class="text-center sub-header font-weight-regular" style="position:absolute;top:0;right:0;left:0">Day</h6></v-col>
                                </v-row>
                            </v-col>
                            <h6 class="sub-header">-</h6>
                            <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                                <v-row wrap no-gutters>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.expected_delivery_date ? cf3_data_p2.MATERNITY_DATA.expected_delivery_date.charAt(6) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.expected_delivery_date ? cf3_data_p2.MATERNITY_DATA.expected_delivery_date.charAt(7) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.expected_delivery_date ? cf3_data_p2.MATERNITY_DATA.expected_delivery_date.charAt(8) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.expected_delivery_date ? cf3_data_p2.MATERNITY_DATA.expected_delivery_date.charAt(9) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" style="position:relative"><h6 class="text-center sub-header font-weight-regular" style="position:absolute;top:0;right:0;left:0">Year</h6></v-col>
                                </v-row>
                            </v-col>
                        </v-row>   
                    </v-col>
                </v-row>   
            </v-col>

            <!--7. Initial Prenatal Consultation-->
            <h4 class="h4-header mb-2">7. Follow-up Prenatal Consultation</h4>
        </v-row>

        <v-row wrap no-gutters>
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-1"> 
                <!-- Prenatal Consultation No -->
                <v-row class="mb-2" align="center" wrap no-gutters>
                    <v-col cols="3">
                        <h5 class="h5-header">a. Prenatal Consultation No.</h5>
                    </v-col>
                    <v-col cols="9">
                        <v-row justify="center">
                            <v-col cols="1" class="box text-center small">2nd</v-col>
                            <v-col cols="1" class="box text-center small">3rd</v-col>
                            <v-col cols="1" class="box text-center small">4th</v-col>
                            <v-col cols="1" class="box text-center small">5th</v-col>
                            <v-col cols="1" class="box text-center small">6th</v-col>
                            <v-col cols="1" class="box text-center small">7th</v-col>
                            <v-col cols="1" class="box text-center small">8th</v-col>
                            <v-col cols="1" class="box text-center small">9th</v-col>
                            <v-col cols="1" class="box text-center small">10th</v-col>
                            <v-col cols="1" class="box text-center small">11th</v-col>
                            <v-col cols="1" class="box text-center small">12th</v-col>
                        </v-row>
                    </v-col>
                </v-row>

                <!-- Date of Visit -->
                <v-row class="mb-2" wrap>
                    <v-col cols="3">
                        <h5 class="h5-header">b. Date of visit (mm/dd/yy)</h5>
                    </v-col>
                    <v-col cols="9">
                        <v-row justify="center" align="center" no-gutters wrap>
                            <template v-for="(prenatal, prenatal_key) in cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date">
                                <v-col :key="prenatal_key" cols="1">
                                    <v-row no-gutters wrap>
                                        <v-col cols="4" class="box_no_top text-center">{{prenatal.date_of_consul ? prenatal.date_of_consul.slice(5,7) : ''}}</v-col>
                                        <v-col cols="4" class="box_no_top text-center">{{prenatal.date_of_consul ? prenatal.date_of_consul.slice(8) : ''}}</v-col>
                                        <v-col cols="4" class="box_no_top text-center">{{prenatal.date_of_consul ? prenatal.date_of_consul.slice(2,4) : ''}}</v-col>
                                    </v-row>
                                </v-col>
                            </template>
                            <template v-for="date in prenatal_consult_rows">
                                <v-col :key="date.row" cols="1">
                                    <v-row no-gutters wrap>
                                        <v-col cols="4" class="box_no_top"></v-col>
                                        <v-col cols="4" class="box_no_top"></v-col>
                                        <v-col cols="4" class="box_no_top"></v-col>
                                    </v-row>
                                </v-col>
                            </template>
                        </v-row>
                    </v-col>
                </v-row>

                <!-- AOG in weeks -->
                <v-row class="mb-2" no-gutters wrap>
                    <v-col cols="3">
                        <h5 class="h5-header">c. AOG in weeks</h5>
                    </v-col>
                    <v-col cols="9">
                        <v-row align="center" justify="center" wrap>
                            <template v-for="(prenatal, i) in cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date">
                                <v-col :key="i" cols="1">
                                    <v-row class="border text-center small" align="center" justify="center" :class="{'white--text' : prenatal.aog_in_weeks == '' || prenatal.aog_in_weeks == null }">
                                    {{prenatal.aog_in_weeks ? prenatal.aog_in_weeks : 'N/A'}}
                                    </v-row>
                                </v-col>
                            </template>
                            <template v-for="week in prenatal_consult_rows">
                                <v-col :key="week.row" cols="1">
                                    <v-row class="border text-center small white--text" justify="center" align="center">1</v-row>
                                </v-col>
                            </template>
                        </v-row>
                    </v-col>
                </v-row>

                <!-- Weight & Vital signs -->
                <v-row class="mb-2">
                    <v-col cols="12" class="mb-1">
                        <h5 class="h5-header">d. Weight & Vital signs:</h5>
                    </v-col>
                    <v-col cols="3" class="mb-4">
                        <h5 class="h5-header">d.1 Weight</h5>
                    </v-col>
                    <v-col cols="9" class="mb-4">
                        <v-row class="d-flex justify-center" wrap>
                            <template v-for="(prenatal, i) in cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date">
                                <v-col :key="i" cols="1">
                                    <v-row class="border text-center small" justify="center" :class="{'white--text' : prenatal.weight == '' || prenatal.weight == null }">
                                    {{prenatal.weight ? prenatal.weight : 'N/A'}}
                                    </v-row>
                                </v-col>
                            </template>
                            <template v-for="weight in prenatal_consult_rows">
                                <v-col :key="weight.row" cols="1">
                                    <v-row class="border text-center small white--text" justify="center">1</v-row>
                                </v-col>
                            </template>
                        </v-row>
                    </v-col>
                    <v-col cols="3" class="mb-4">
                        <h5 class="h5-header">d.2 Cardiac Rate</h5>
                    </v-col>
                    <v-col cols="9" class="mb-4">
                        <v-row class="d-flex justify-center" wrap>
                            <template v-for="(prenatal, i) in cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date">
                                <v-col :key="i" cols="1">
                                    <v-row class="border text-center small" justify="center" :class="{'white--text' : prenatal.cardiac_rate == '' || prenatal.cardiac_rate == null }">
                                    {{prenatal.cardiac_rate ? prenatal.cardiac_rate : 'N/A'}}
                                    </v-row>
                                </v-col>
                            </template>
                            <template v-for="cardiac in prenatal_consult_rows">
                                <v-col :key="cardiac.row" cols="1">
                                    <v-row class="border text-center small white--text" justify="center">1</v-row>
                                </v-col>
                            </template>
                        </v-row>
                    </v-col>
                    <v-col cols="3" class="mb-4">
                        <h5 class="h5-header">d.3 Respiratory Rate</h5>
                    </v-col>
                    <v-col cols="9" class="mb-4">
                        <v-row class="d-flex justify-center" wrap>
                            <template v-for="(prenatal, i) in cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date">
                                <v-col :key="i" cols="1">
                                    <v-row class="border text-center small" justify="center" :class="{'white--text' : prenatal.respiratory_rate == '' || prenatal.respiratory_rate == null }">
                                    {{prenatal.respiratory_rate ? prenatal.respiratory_rate : 'N/A'}}
                                    </v-row>
                                </v-col>
                            </template>
                            <template v-for="respiratory in prenatal_consult_rows">
                                <v-col :key="respiratory.row" cols="1">
                                    <v-row class="border text-center small white--text" justify="center">1</v-row>
                                </v-col>
                            </template>
                        </v-row>
                    </v-col>
                    <v-col cols="3" class="mb-4">
                        <h5 class="h5-header">d.4 Blood Pressure</h5>
                    </v-col>
                    <v-col cols="9" class="mb-4">
                        <v-row class="d-flex justify-center" wrap>
                            <template v-for="(prenatal, i) in cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date">
                                <v-col :key="i" cols="1">
                                    <v-row class="border text-center small" justify="center" :class="{'white--text' : prenatal.blood_pressure == '' || prenatal.blood_pressure == null }">
                                    {{prenatal.blood_pressure ? prenatal.blood_pressure : 'N/A'}}
                                    </v-row>
                                </v-col>
                            </template>
                            <template v-for="pressure in prenatal_consult_rows">
                                <v-col :key="pressure.row" cols="1">
                                    <v-row class="border text-center small white--text" justify="center">1</v-row>
                                </v-col>
                            </template>
                        </v-row>
                    </v-col>
                    <v-col cols="3" class="mb-1">
                        <h5 class="h5-header">d.5 Temperature:</h5>
                    </v-col>
                    <v-col cols="9" class="mb-1">
                        <v-row class="d-flex justify-center" wrap>
                            <template v-for="(prenatal, i) in cf3_data_p2.MATERNITY_DATA.ini_prenatal_consul_date">
                                <v-col :key="i" cols="1">
                                    <v-row class="border text-center small" justify="center" :class="{'white--text' : prenatal.temperature == '' || prenatal.temperature == null }">
                                    {{prenatal.temperature ? prenatal.temperature : 'N/A'}}
                                    </v-row>
                                </v-col>
                            </template>
                            <template v-for="temperature in prenatal_consult_rows">
                                <v-col :key="temperature.row" cols="1">
                                    <v-row class="border text-center small white--text" justify="center">1</v-row>
                                </v-col>
                            </template>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>

        <h3 class="h3-header text-center border-bottom border-top py-1 mb-2 ">DELIVERY OUTCOME</h3>
        <v-row class="pa-3" no-gutters wrap>
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-2"><!--8. Date and Time of Delivery --> 
                <v-row no-gutters align="baseline" wrap>
                    <v-col cols="3">
                        <h4 class="h4-header mr-2">8. Date and Time of Delivery </h4>
                    </v-col>
                    
                    <v-col cols="6" > <!-- DATE ADMITTED --->
                        <v-row align="baseline" wrap>
                            <h6 class="font-data font-weight-regular mr-2">Date</h6>
                            <v-col cols="2">
                                <v-row wrap>
                                    <v-col cols="6" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_of_delivery ? cf3_data_p2.MATERNITY_DATA.date_of_delivery.charAt(0) : ''}}</v-col>
                                    <v-col cols="6" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_of_delivery ? cf3_data_p2.MATERNITY_DATA.date_of_delivery.charAt(1) : ''}}</v-col>
                                    <v-col cols="12" class="text-center small">Month</v-col>
                                </v-row>
                            </v-col>
                            <h6 class="sub-header">-</h6>
                            <v-col cols="2">
                                <v-row wrap>
                                    <v-col cols="6" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_of_delivery ? cf3_data_p2.MATERNITY_DATA.date_of_delivery.charAt(3) : ''}}</v-col>
                                    <v-col cols="6" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_of_delivery ? cf3_data_p2.MATERNITY_DATA.date_of_delivery.charAt(4) : ''}}</v-col>
                                    <v-col cols="12" class="text-center small">Day</v-col>
                                </v-row>
                            </v-col>
                            <h6 class="sub-header">-</h6>
                            <v-col cols="4">
                                <v-row wrap>
                                    <v-col cols="3" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_of_delivery ? cf3_data_p2.MATERNITY_DATA.date_of_delivery.charAt(6) : ''}}</v-col>
                                    <v-col cols="3" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_of_delivery ? cf3_data_p2.MATERNITY_DATA.date_of_delivery.charAt(7) : ''}}</v-col>
                                    <v-col cols="3" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_of_delivery ? cf3_data_p2.MATERNITY_DATA.date_of_delivery.charAt(8) : ''}}</v-col>
                                    <v-col cols="3" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_of_delivery ? cf3_data_p2.MATERNITY_DATA.date_of_delivery.charAt(9) : ''}}</v-col>
                                    <v-col cols="12" class="text-center small">Year</v-col>
                                </v-row>
                            </v-col>
                        </v-row>  
                    </v-col>

                    <v-col cols="3"> <!-- TIME ADMITTED --->
                        <v-row no-gutters wrap>
                            <h4 class="h4-header mr-2">Time</h4>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="ml-n1">
                                <v-row no-gutters wrap>
                                    <v-col cols="8" sm="8" md="8" lg="8" xl="8">
                                        <h6 class="box_no_top font-weight-regular" :class="{'white--text' : cf3_data_p2.MATERNITY_DATA.time_of_delivery.time_am === '00:00'}">{{cf3_data_p2.MATERNITY_DATA.time_of_delivery.time_am}}</h6>
                                        <h6 class="small font-weight-regular text-center">hh mm</h6>
                                    </v-col>
                                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="font-data font-weight-bold px-1">AM</v-col>
                                </v-row>
                            </v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="ml-2">
                                <v-row no-gutters wrap>
                                    <v-col cols="8" sm="8" md="8" lg="8" xl="8">
                                        <h6 class="box_no_top font-weight-regular" :class="{'white--text' : cf3_data_p2.MATERNITY_DATA.time_of_delivery.time_pm === '00:00'}">{{cf3_data_p2.MATERNITY_DATA.time_of_delivery.time_pm}}</h6>
                                        <h6 class="small font-weight-regular text-center">hh mm</h6>
                                    </v-col>
                                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="font-data font-weight-bold px-1">PM</v-col>
                                </v-row>
                            </v-col>
                        </v-row>      
                    </v-col>


                </v-row>                          
            </v-col>

            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-2 mt-1"> <!--9. Maternal Outcome:-->
                <v-row wrap no-gutters> 
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <h4 class="h4-header mr-5">9. Maternal Outcome</h4>
                    </v-col>
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                        <v-row wrap>
                            <h5 class="h5-header border-bottom text-center" style="width:80%">{{cf3_data_p2.MATERNITY_DATA.mo_obstetric_index ? cf3_data_p2.MATERNITY_DATA.mo_obstetric_index : 'N/A'}}</h5>
                            <h6 class="sub-header xs-small text-center" style="width:80%">Obstetric Index</h6>
                        </v-row>
                    </v-col>
                    <h6 class="sub-header-diagnosis">Pregnancy Uterine,</h6>
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-4">
                        <v-row wrap>
                            <h5 class="h5-header border-bottom text-center" style="width:80%">{{cf3_data_p2.MATERNITY_DATA.pu_aog_by_lmp ? cf3_data_p2.MATERNITY_DATA.pu_aog_by_lmp : 'N/A'}}</h5>
                            <h6 class="sub-header xs-small text-center" style="width:80%">AOG by LMP</h6>
                        </v-row>
                    </v-col>
                    
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                        <v-row wrap>
                            <h5 class="h5-header border-bottom text-center" style="width:80%">{{cf3_data_p2.MATERNITY_DATA.pu_manner_of_del ? cf3_data_p2.MATERNITY_DATA.pu_manner_of_del : 'N/A'}}</h5>
                            <h6 class="sub-header xs-small text-center" style="width:80%">Manner of Delivery</h6>
                        </v-row>
                    </v-col>
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                        <v-row wrap>
                            <h5 class="h5-header border-bottom text-center" style="width:80%">{{cf3_data_p2.MATERNITY_DATA.pu_presentation ? cf3_data_p2.MATERNITY_DATA.pu_presentation : 'N/A'}}</h5>
                            <h6 class="sub-header xs-small text-center" style="width:80%">Presentation</h6>
                        </v-row>
                    </v-col>
                    
                </v-row>
            </v-col>

            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-2 mt-1"> <!--10. Birth Outcome:-->
                <v-row wrap no-gutters> 
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                        <h4 class="h4-header mr-5">10. Birth Outcome:</h4>
                    </v-col>
                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2">
                        <v-row wrap>
                            <h5 class="h5-header border-bottom text-center" style="width:80%">{{cf3_data_p2.MATERNITY_DATA.bo_fetal_outcome ? cf3_data_p2.MATERNITY_DATA.bo_fetal_outcome : 'N/A'}}</h5>
                            <h6 class="sub-header  text-center" style="width:80%">Fetal Outcome</h6>
                        </v-row>
                    </v-col>
                    
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                        <v-row wrap>
                            <h5 class="h5-header border-bottom text-center" style="width:80%">{{cf3_data_p2.MATERNITY_DATA.bo_sex ? cf3_data_p2.MATERNITY_DATA.bo_sex : 'N/A'}}</h5>
                            <h6 class="sub-header xs-small text-center" style="width:80%">Sex</h6>
                        </v-row>
                    </v-col>
                    
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                        <v-row wrap>
                            <h5 class="h5-header border-bottom text-center" style="width:80%">{{cf3_data_p2.MATERNITY_DATA.bo_birth_weight ? cf3_data_p2.MATERNITY_DATA.bo_birth_weight : 'N/A'}}</h5>
                            <h6 class="sub-header xs-small text-center" style="width:80%">Birth Weight (grm)</h6>
                        </v-row>
                    </v-col>
                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="px-2">
                        <v-row wrap>
                            <h5 class="h5-header border-bottom text-center" style="width:80%">{{cf3_data_p2.MATERNITY_DATA.bo_apgar_score ? cf3_data_p2.MATERNITY_DATA.bo_apgar_score : 'N/A'}}</h5>
                            <h6 class="sub-header xs-small text-center" style="width:80%">APGAR Score</h6>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>

            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-2"> <!--11. Scheduled Postpartum follow-up consultation 1 week after delivery-->
                <v-row align="baseline" wrap no-gutters>
                    <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                        <h4 class="h4-header">11. Scheduled Postpartum follow-up consultation 1 week after delivery</h4>
                    </v-col>
                    <v-row wrap no-gutters>
                        <v-col cols="2">
                            <v-row no-gutters wrap>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.sched_postpartum_date ? cf3_data_p2.MATERNITY_DATA.sched_postpartum_date.charAt(0) : ''}}</v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.sched_postpartum_date ? cf3_data_p2.MATERNITY_DATA.sched_postpartum_date.charAt(1) : ''}}</v-col>
                                <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center small">Month</v-col>
                            </v-row>
                        </v-col>
                        <h6 class="mx-1">-</h6>
                        <v-col cols="2">
                            <v-row no-gutters wrap>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.sched_postpartum_date ? cf3_data_p2.MATERNITY_DATA.sched_postpartum_date.charAt(3) : ''}}</v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.sched_postpartum_date ? cf3_data_p2.MATERNITY_DATA.sched_postpartum_date.charAt(4) : ''}}</v-col>
                                <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center small">Day</v-col>
                            </v-row>
                        </v-col>
                        <h6 class="mx-1">-</h6>
                        <v-col cols="4">
                            <v-row no-gutters wrap>
                                <v-col cols="3" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.sched_postpartum_date ? cf3_data_p2.MATERNITY_DATA.sched_postpartum_date.charAt(6) : ''}}</v-col>
                                <v-col cols="3" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.sched_postpartum_date ? cf3_data_p2.MATERNITY_DATA.sched_postpartum_date.charAt(7) : ''}}</v-col>
                                <v-col cols="3" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.sched_postpartum_date ? cf3_data_p2.MATERNITY_DATA.sched_postpartum_date.charAt(8) : ''}}</v-col>
                                <v-col cols="3" class="box_no_top">{{cf3_data_p2.MATERNITY_DATA.sched_postpartum_date ? cf3_data_p2.MATERNITY_DATA.sched_postpartum_date.charAt(9) : ''}}</v-col>
                                <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center small">Year</v-col>
                            </v-row>
                        </v-col>
                    </v-row>
                </v-row>   
            </v-col>     

            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-2"><!--12. Date and Time of Discharge  --> 
                <v-row align="baseline" wrap no-gutters>
                    <v-col cols="3">
                        <h4 class="h4-header mr-2">12. Date and Time of Discharge </h4>
                    </v-col>
                    
                    <v-col cols="6" > <!-- DATE ADMITTED --->
                        <v-row align="baseline">
                            <h6 class="font-data font-weight-regular mr-2">Date</h6>
                            <v-col cols="2">
                                <v-row wrap>
                                    <v-col cols="6" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_discharged ? cf3_data_p2.MATERNITY_DATA.date_discharged.charAt(5) : ''}}</v-col>
                                    <v-col cols="6" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_discharged ? cf3_data_p2.MATERNITY_DATA.date_discharged.charAt(6) : ''}}</v-col>
                                    <v-col cols="12" class="text-center small">Month</v-col>
                                </v-row>
                            </v-col>
                            <h6 class="sub-header">-</h6>
                            <v-col cols="2">
                                <v-row wrap>
                                    <v-col cols="6" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_discharged ? cf3_data_p2.MATERNITY_DATA.date_discharged.charAt(8) : ''}}</v-col>
                                    <v-col cols="6" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_discharged ? cf3_data_p2.MATERNITY_DATA.date_discharged.charAt(9) : ''}}</v-col>
                                    <v-col cols="12" class="text-center small">Day</v-col>
                                </v-row>
                            </v-col>
                            <h6 class="sub-header">-</h6>
                            <v-col cols="4">
                                <v-row wrap>
                                    <v-col cols="3" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_discharged ? cf3_data_p2.MATERNITY_DATA.date_discharged.charAt(0) : ''}}</v-col>
                                    <v-col cols="3" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_discharged ? cf3_data_p2.MATERNITY_DATA.date_discharged.charAt(1) : ''}}</v-col>
                                    <v-col cols="3" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_discharged ? cf3_data_p2.MATERNITY_DATA.date_discharged.charAt(2) : ''}}</v-col>
                                    <v-col cols="3" class="box d-flex align-center">{{cf3_data_p2.MATERNITY_DATA.date_discharged ? cf3_data_p2.MATERNITY_DATA.date_discharged.charAt(3) : ''}}</v-col>
                                    <v-col cols="12" class="text-center small">Year</v-col>
                                </v-row>
                            </v-col>
                        </v-row>   
                    </v-col>

                    <v-col cols="3"> <!-- TIME ADMITTED --->
                        <v-row no-gutters wrap>
                            <h4 class="h4-header mr-2">Time</h4>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="ml-n1">
                                <v-row no-gutters wrap>
                                    <v-col cols="8" sm="8" md="8" lg="8" xl="8">
                                        <h6 class="box_no_top font-weight-regular" :class="{'white--text' : cf3_data_p2.MATERNITY_DATA.time_discharged.time_am === '00:00'}">{{cf3_data_p2.MATERNITY_DATA.time_discharged.time_am}}</h6>
                                        <h6 class="small font-weight-regular text-center">hh mm</h6>
                                    </v-col>
                                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="font-data font-weight-bold px-1">AM</v-col>
                                </v-row>
                            </v-col>
                            <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="ml-2">
                                <v-row no-gutters wrap>
                                    <v-col cols="8" sm="8" md="8" lg="8" xl="8">
                                        <h6 class="box_no_top font-weight-regular" :class="{'white--text' : cf3_data_p2.MATERNITY_DATA.time_discharged.time_pm === '00:00'}">{{cf3_data_p2.MATERNITY_DATA.time_discharged.time_pm}}</h6>
                                        <h6 class="small font-weight-regular text-center">hh mm</h6>
                                    </v-col>
                                    <v-col cols="2" sm="2" md="2" lg="2" xl="2" class="font-data font-weight-bold px-1">PM</v-col>
                                </v-row>
                            </v-col>
                        </v-row>      
                    </v-col>
                </v-row>                          
            </v-col>
        </v-row>

        <h3 class="border-bottom border-top h3-header text-center py-1 mb-2">POSTPARTUM CARE</h3>
        
        <v-row class="mb-2" wrap no-gutters><!--  Header  -->
            <v-col cols="7" sm="7" md="7" lg="7" xl="7"></v-col>
            <v-col cols="1" sm="1" md="1" lg="1" xl="1"><h5 class="h5-header">Done</h5></v-col>
            <v-col cols="4" sm="4" md="4" lg="4" xl="4"><h5 class="h5-header text-center">Remarks</h5></v-col>
        </v-row>
        
        <v-row class="mb-1" wrap no-gutters><!--  Perineal wound care  -->
            <v-col cols="7" sm="7" md="7" lg="7" xl="7"><h4 class="h4-header">13. Perineal wound care</h4></v-col>
            <v-col cols="1" sm="1" md="1" lg="1" xl="1"><input onclick="return false" :checked="cf3_data_p2.MATERNITY_DATA.perinal_wound_care" type="checkbox" ></v-col>
            <v-col cols="4" sm="4" md="4" lg="4" xl="4"><h5 class="h5-header text-center border-bottom">{{cf3_data_p2.MATERNITY_DATA.perinal_wound_care_remarks ? cf3_data_p2.MATERNITY_DATA.perinal_wound_care_remarks : 'N/A'}}</h5></v-col>
        </v-row>

        <v-row wrap no-gutters>  <!--   Signs of Maternal Postpartum Complications -->
            <v-col cols="7" sm="7" md="7" lg="7" xl="7"><h4 class="h4-header">14. Signs of Maternal Postpartum Complications</h4></v-col>
            <v-col cols="1" sm="1" md="1" lg="1" xl="1"><input onclick="return false" :checked="cf3_data_p2.MATERNITY_DATA.maternal_complication" type="checkbox" ></v-col>
            <v-col cols="4" sm="4" md="4" lg="4" xl="4"><h5 class="h5-header text-center border-bottom">{{cf3_data_p2.MATERNITY_DATA.maternal_complication_remarks ? cf3_data_p2.MATERNITY_DATA.maternal_complication_remarks : 'N/A'}}</h5></v-col>
        </v-row>
        
        <v-row wrap no-gutters><!--  Counselling and Education  -->
            <v-col cols="7" sm="7" md="7" lg="7" xl="7"><h4 class="h4-header">15. Counselling and Education</h4></v-col>

            <v-col cols="12" sm="12" md="12" lg="12" xl="12" > 
                <v-row no-gutters wrap>
                    <v-col cols="7" sm="7" md="7" lg="7" xl="7" px-3><h5 class="h5-header">a. Breastfeeding and Nutrition</h5></v-col>
                    <v-col cols="1" sm="1" md="1" lg="1" xl="1"><input onclick="return false" :checked="cf3_data_p2.MATERNITY_DATA.breastfeeding" type="checkbox" ></v-col>
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4"><h5 class="h5-header text-center border-bottom">{{cf3_data_p2.MATERNITY_DATA.breastfeeding_remarks ? cf3_data_p2.MATERNITY_DATA.breastfeeding_remarks : 'N/A'}}</h5></v-col>
                    <v-col cols="7" sm="7" md="7" lg="7" xl="7" px-3><h5 class="h5-header">b. Family Planning</h5></v-col>
                    <v-col cols="1" sm="1" md="1" lg="1" xl="1"><input onclick="return false" :checked="cf3_data_p2.MATERNITY_DATA.family_planning" type="checkbox" ></v-col>
                    <v-col cols="4" sm="4" md="4" lg="4" xl="4"><h5 class="h5-header text-center border-bottom">{{cf3_data_p2.MATERNITY_DATA.family_planning_remarks ? cf3_data_p2.MATERNITY_DATA.family_planning_remarks : 'N/A'}}</h5></v-col>
                </v-row>
            </v-col>
        </v-row>
        
        <v-row wrap no-gutters> <!--   Provided family planning service to patient (as requested by patient)  -->
            <v-col cols="7" sm="7" md="7" lg="7" xl="7"><h4 class="h4-header">16. Provided family planning service to patient (as requested by patient)</h4></v-col>
            <v-col cols="1" sm="1" md="1" lg="1" xl="1"><input onclick="return false" :checked="cf3_data_p2.MATERNITY_DATA.planning_service" type="checkbox" ></v-col>
            <v-col cols="4" sm="4" md="4" lg="4" xl="4"><h5 class="h5-header text-center border-bottom">{{cf3_data_p2.MATERNITY_DATA.planning_service_remarks ? cf3_data_p2.MATERNITY_DATA.planning_service_remarks : 'N/A'}}</h5></v-col>
        </v-row>
        
        <v-row wrap no-gutters> <!--   Referred to partner physician for Voluntary Surgical Sterilization (as requested by pt.)  -->
            <v-col cols="7" sm="7" md="7" lg="7" xl="7"><h4 class="h4-header">17. Referred to partner physician for Voluntary Surgical Sterilization (as requested by pt.)</h4></v-col>
            <v-col cols="1" sm="1" md="1" lg="1" xl="1"><input onclick="return false"  :checked="cf3_data_p2.MATERNITY_DATA.surgical_sterilization" type="checkbox" ></v-col>
            <v-col cols="4" sm="4" md="4" lg="4" xl="4"><h5 class="h5-header text-center border-bottom">{{cf3_data_p2.MATERNITY_DATA.sterilization_remarks ? cf3_data_p2.MATERNITY_DATA.sterilization_remarks : 'N/A'}}</h5></v-col>
        </v-row>
        
        <v-row wrap no-gutters><!--  Schedule the next postpartum follow-up  -->
            <v-col cols="7" sm="7" md="7" lg="7" xl="7"><h4 class="h4-header">18. Schedule the next postpartum follow-up</h4></v-col>
            <v-col cols="1" sm="1" md="1" lg="1" xl="1"><input onclick="return false" :checked="cf3_data_p2.MATERNITY_DATA.follow_up_sched" type="checkbox" ></v-col>
            <v-col cols="4" sm="4" md="4" lg="4" xl="4"><h5 class="h5-header text-center border-bottom">{{cf3_data_p2.MATERNITY_DATA.follow_up_sched_remarks ? cf3_data_p2.MATERNITY_DATA.follow_up_sched_remarks : 'N/A'}}</h5></v-col>
        </v-row>
            
        <v-row class="border pa-2 m-b-12" wrap no-gutters><!--  Certification of Attending Physician/Midwife  -->
            <h4 class="h4-header">19. Certification of Attending Physician/Midwife</h4>
            <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mt-5 mb-10" >
                <h5 class="h5-header mb-5" style="position:relative;z-index:2"><i>I certify that the above information given in this form are true and correct.</i></h5>
                <v-row class="d-flex justify-space-between" wrap>
                    <v-col cols="4" class="px-2" style="position:relative;z-index:1">          
                        <!-- <h6 class="sub-header text-center text-uppercas grey--text text--darken-2">SIGNATURE HAS BEEN PROVIDED</h6> -->
                        <v-img :src="cf3_data_p2.TRANSACTION.doctor_sign_path" height="30" contain></v-img>
                        <h5 class="h5-header border-bottom text-center" style="position:relative;z-index:2">{{cf3_data_p2.doctor_name}}</h5>
                        <h5 class="small text-center" style="position:relative;z-index:2">Signature Over Printed Name of Attending Physician/Midwife</h5>
                    </v-col>
                    
                    <v-col cols="8"> 
                        <v-row class="d-flex justify-end mt-5" align="baseline" wrap>
                            <v-col cols="8">
                                <v-row class="d-flex justify-center" wrap>
                                    <v-col cols="2">
                                        <v-row wrap>
                                            <v-col cols="6" class="box_no_top d-flex align-center">{{cf3_data_p2.date_signed ? cf3_data_p2.date_signed.charAt(5) : ''}}</v-col>
                                            <v-col cols="6" class="box_no_top d-flex align-center">{{cf3_data_p2.date_signed ? cf3_data_p2.date_signed.charAt(6) : ''}}</v-col>
                                        </v-row>
                                    </v-col>
                                    <h6 class="sub-header">-</h6>
                                    <v-col cols="2">
                                        <v-row wrap>
                                            <v-col cols="6" class="box_no_top d-flex align-center">{{cf3_data_p2.date_signed ? cf3_data_p2.date_signed.charAt(8) : ''}}</v-col>
                                            <v-col cols="6" class="box_no_top d-flex align-center">{{cf3_data_p2.date_signed ? cf3_data_p2.date_signed.charAt(9) : ''}}</v-col>
                                        </v-row>
                                    </v-col>
                                    <h6 class="sub-header">-</h6>
                                    <v-col cols="4">
                                        <v-row wrap>
                                            <v-col cols="3" class="box_no_top d-flex align-center">{{cf3_data_p2.date_signed ? cf3_data_p2.date_signed.charAt(0) : ''}}</v-col>
                                            <v-col cols="3" class="box_no_top d-flex align-center">{{cf3_data_p2.date_signed ? cf3_data_p2.date_signed.charAt(1) : ''}}</v-col>
                                            <v-col cols="3" class="box_no_top d-flex align-center">{{cf3_data_p2.date_signed ? cf3_data_p2.date_signed.charAt(2) : ''}}</v-col>
                                            <v-col cols="3" class="box_no_top d-flex align-center">{{cf3_data_p2.date_signed ? cf3_data_p2.date_signed.charAt(3) : ''}}</v-col>
                                        </v-row>
                                    </v-col>
                                </v-row>
                                <v-row class="d-flex justify-center" wrap>
                                    <v-col cols="10" sm="10" md="10" lg="10" class="small text-center">Date Signed (Month / Day / Year)</v-col>
                                </v-row>
                            </v-col>
                        </v-row>   
                    </v-col>
                </v-row>
            </v-col>
        </v-row>   
    </div>
</template>

<script>
export default {
   props:["menu","cf3_data_p2", "cf3_data_p1"],
   data:()=>({
        doctor_img_loader : true,
    }),

   computed:{
    obstetric_risk_factor(){
        let multiple_pregnancy, ovarian_cyst, myoma_uteri, placenta_previa, miscarriages, still_birth, pre_eclampsia, eclampsia, premature_contraction
        if(this.cf3_data_p2.OBSTETRIC_RISK_FACTOR !== undefined){
            this.cf3_data_p2.OBSTETRIC_RISK_FACTOR.map(item => {
                if(item === 'Multiple Pregnancy') multiple_pregnancy = 'Multiple Pregnancy'
                if(item === 'Ovarian cyst') ovarian_cyst = 'Ovarian cyst'
                if(item === 'Myoma uteri') myoma_uteri = 'Myoma uteri'
                if(item === 'Placenta previa')placenta_previa = 'Placenta previa'
                if(item === 'History of 3 miscarriages') miscarriages = 'History of 3 miscarriages'
                if(item === 'History of stillbirth') still_birth = 'History of still birth'
                if(item === 'History of pre-eclampsia') pre_eclampsia = 'History of pre-eclampsia'
                if(item === 'History of eclampsia') eclampsia = 'History of eclampsia'
                if(item === 'Premature contraction') premature_contraction = 'Premature contraction'
            })
        }
        return {multiple_pregnancy, ovarian_cyst, myoma_uteri, placenta_previa, miscarriages, still_birth, pre_eclampsia, eclampsia, premature_contraction}
    },
    med_surg_risk_factor(){
        let hypertension, heart_disease, diabetes, thyroid_disorder, obesity, severe_asthma,epilepsy, renal_disease, bleeding_disorders,cesarian_section,uterine_myomectomy
        if(this.cf3_data_p2.MED_SURG_RISK_FACTOR !== undefined){
            this.cf3_data_p2.MED_SURG_RISK_FACTOR.map(item => {
                if(item === 'Hypertension') hypertension = 'Hypertension'
                if(item === 'Heart Disease') heart_disease = 'Heart Disease'
                if(item === 'Diabetes') diabetes = 'Diabetes'
                if(item === 'Thyroid Disorder')thyroid_disorder = 'Thyroid Disorder'
                if(item === 'Obesity')  obesity = 'Obesity'
                if(item === 'Moderate to severe asthma') severe_asthma = 'Moderate to severe asthma'
                if(item === 'Epilepsy') epilepsy = 'Epilepsy'
                if(item === 'Renal disease') renal_disease = 'Renal disease'
                if(item === 'Bleeding disorders') bleeding_disorders = 'Bleeding disorders'
                if(item === 'History of previous cesarian section') cesarian_section = 'History of previous cesarian section'
                if(item === 'History of uterine myomectomy') uterine_myomectomy = 'History of uterine myomectomy'
            })
        }
        return{hypertension, heart_disease, diabetes, thyroid_disorder, obesity, severe_asthma,epilepsy, renal_disease, bleeding_disorders,cesarian_section,uterine_myomectomy}
    },
    prenatal_consult_rows(){
        let length = this.cf3_data_p2.MATERNITY_DATA.length ? this.cf3_data_p2.MATERNITY_DATA.length : 0 
        let total = 11 - length
        return  total
    }
   }
}
</script>

<style scoped>
 .border{border:1px solid black}
  .border-top{border-top:1px solid black}
  .border-bottom{ border-bottom:1px solid black}
  .box{
     align-items: center;
     border:1px solid black;
     display: flex;
     font-size:8pt;
     height:2em;
     justify-content: center;
     text-align:center;
     width:2%;
  }
  .box_no_top_pan{
    border-left:1px solid black;
    border-right:1px solid black;
    border-bottom:1px solid black;
    font-size:10pt;
    text-align: center;
    width:1% !important;
  }
  .box_no_top{
    border-left:1px solid black;
    border-right:1px solid black;
    border-bottom:1px solid black;
    font-size:10pt;
    text-align: center;
    height:18px;
   }
  .cf3_test2{
    padding-top:3em ;
    padding-left:2.35em !important;
    padding-right:2.55em !important;
  }
  
  .h1-header{ font-size:34pt;line-height:0.8;}
  .h2-header{font-size:16pt}
  .h3-header{font-size:14pt}
  .h4-header{font-size:11.5pt}
  .h4-header{font-size:11pt}
  .h5-header{font-size:9pt}
  .h5-reminder{font-size:7.3pt}
  .height_45{
    height:35vh;
    width:100%
   }
  .hide-content{display: none}
  .font-data{ font-size:9pt}
  .image_logo{
     width:200px;
     height:70px;
  }

  .p-y-12{padding-top:3em;padding-bottom:3em}
  .m-t-10{margin-top:2.5em}
  .m-b-12{margin-bottom:3em}
  .line-height-sub{line-height: 0.8;}
  .p-b-1{padding-bottom:0.25em}
  .p-b-2{padding-bottom:0.5em}
  .p-b-3{padding-bottom:0.7em}
  .p-b-4{padding-bottom:1em}
  .small{font-size:8pt}
  .sub-header,.sub-header-diagnosis{font-size:8pt}
  .sub-header-subtitle{font-size:7pt}
  .signature{
         position:absolute;
         margin-left: auto;
         margin-right:auto;
         top:-50px;
         left:0;
         right:0;
         z-index: 1

    }
  .word-{word-wrap: break-word}

@media print{
  .cf3_test2{
    padding:0.25em 0 0!important
  }
  .h1-header{font-size:16pt;line-height:0.8 !important;}
  .h2-header{font-size:12pt}
  .h3-header,.font-header{font-size:10pt !important}
  .h4-header,   .font-data{font-size:7pt !important}
  .h5-reminder{font-size:7.2pt !important}
  .h5-header{font-size:6.5pt}
  .height_45{height:10vh}

  .p-y-12{padding-top:1.5em;padding-bottom: 1.5em;}
  .m-t-10{margin-top:2em}
  .m-b-12{margin-bottom:0}

  .line-height-sub{line-height: 0.8;}
  .p-b-1{padding-bottom:0.25em}
  .p-b-2{padding-bottom:0.5em}
  .p-b-3{padding-bottom:0.7em}
  .p-b-4{padding-bottom:1em}


  .sub-header, .small{font-size:6pt}
  .box_no_top{font-size:7pt; height:10px;}
  .sub-header-subtitle,.sub-header-diagnosis,.dis_check_lbl{font-size:5pt}
}
</style>