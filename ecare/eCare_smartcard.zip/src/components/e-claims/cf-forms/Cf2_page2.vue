<template>
  <div class="cf2_test2" >
    <!-- Patient Confinement Information -->
    <h4 class="h4-header px-2 border-top">10. Accreditation Number/Name of Accredited Health Care Professional/Date Signed and Professional Fees/Charges</h4>
    <h6 class="font-weight-regular font-label px-2 mb-2">(Use additional CF2 if necessary):</h6>
    <v-row class="border-top wrap" no-gutters>
        <v-col cols="12" sm="12" md="12" lg="12" xl="12">
            <v-row class="wrap">
                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="border-right mt-3"> <h6 class="sub-header text-center">Accreditation number/Name of Accredited Health Care Professional/Date Signed</h6></v-col>
                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="mt-3"><h6 class="sub-header text-center">Details</h6></v-col>
            </v-row>
    
            <v-row align="center" class="border-top wrap mx-1">
            
                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="border-right">
                    <v-row justify="center" class="pa-2 mb-5 wrap">
                        <h6 class="text-center mr-2">Accreditation No:</h6>
                        <div class="box_no_top_pan" style="position:relative; z-index:2">{{cf2_data_p2.doc_phic_acc_no ? cf2_data_p2.doc_phic_acc_no.charAt(0) : ''}}</div>
                        <div class="box_no_top_pan" style="position:relative; z-index:2">{{cf2_data_p2.doc_phic_acc_no ? cf2_data_p2.doc_phic_acc_no.charAt(2) : ''}}</div>
                        <div class="box_no_top_pan" style="position:relative; z-index:2">{{cf2_data_p2.doc_phic_acc_no ? cf2_data_p2.doc_phic_acc_no.charAt(2) : ''}}</div>
                        <div class="box_no_top_pan" style="position:relative; z-index:2">{{cf2_data_p2.doc_phic_acc_no ? cf2_data_p2.doc_phic_acc_no.charAt(3) : ''}}</div>
                        <h6 class="mx-1" style="position:relative; z-index:2">-</h6>
                        <div class="box_no_top_pan" style="position:relative; z-index:2">{{cf2_data_p2.doc_phic_acc_no ? cf2_data_p2.doc_phic_acc_no.charAt(2) : ''}}</div>
                        <div class="box_no_top_pan" style="position:relative; z-index:2">{{cf2_data_p2.doc_phic_acc_no ? cf2_data_p2.doc_phic_acc_no.charAt(6) : ''}}</div>
                        <div class="box_no_top_pan" style="position:relative; z-index:2">{{cf2_data_p2.doc_phic_acc_no ? cf2_data_p2.doc_phic_acc_no.charAt(7) : ''}}</div>
                        <div class="box_no_top_pan" style="position:relative; z-index:2">{{cf2_data_p2.doc_phic_acc_no ? cf2_data_p2.doc_phic_acc_no.charAt(8) : ''}}</div>
                        <div class="box_no_top_pan" style="position:relative; z-index:2">{{cf2_data_p2.doc_phic_acc_no ? cf2_data_p2.doc_phic_acc_no.charAt(9) : ''}}</div>
                        <div class="box_no_top_pan" style="position:relative; z-index:2">{{cf2_data_p2.doc_phic_acc_no ? cf2_data_p2.doc_phic_acc_no.charAt(10) : ''}}</div>
                        <div class="box_no_top_pan" style="position:relative; z-index:2">{{cf2_data_p2.doc_phic_acc_no ? cf2_data_p2.doc_phic_acc_no.charAt(11) : ''}}</div>
                        <h6 class="mx-1" style="position:relative; z-index:2">-</h6>
                        <div class="box_no_top_pan" style="position:relative; z-index:2">{{cf2_data_p2.doc_phic_acc_no ? cf2_data_p2.doc_phic_acc_no.charAt(13) : ''}}</div>
                    </v-row>

                    <v-row justify="center" class="wrap">
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="px-2" style="position:relative">
                            <!-- <h6 class="sub-header text-center text-uppercas grey--text text--darken-2">SIGNATURE HAS BEEN PROVIDED</h6> -->
                            <v-img :src="cf2_data_p2.TRANSACTION.doctor_sign_path" height="30" contain></v-img>
                            <h6 class="sub-header text-center border-bottom mt-1 text-uppercase" style="position:relative;z-index:2">DR {{ cf2_data_p2.doctor_name}}</h6>
                            <h6 class="sub-header text-center font-weight-regular pa-0 ma-0" style="position:relative;z-index:2">Signature Over Printed Name</h6>
                        </v-col>
                    </v-row>

                    <v-row justify="center" class="pa-2 wrap">
                        <h6 class="text-center mr-2">Date Signed:</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p2.date_signed ? cf2_data_p2.date_signed.charAt(5) : ''}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p2.date_signed ? cf2_data_p2.date_signed.charAt(6) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Month</label></v-col>
                                </v-row>
                            </v-col>
                            <h6 class="mx-1">-</h6>
                            <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                <v-row class="wrap">
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p2.date_signed ? cf2_data_p2.date_signed.charAt(8) : ''}}</v-col>
                                    <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p2.date_signed ? cf2_data_p2.date_signed.charAt(9) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Day</label></v-col>
                                </v-row>
                            </v-col>
                            <h6 class="mx-1">-</h6>
                            <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                                <v-row class="wrap">
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p2.date_signed ? cf2_data_p2.date_signed.charAt(0) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p2.date_signed ? cf2_data_p2.date_signed.charAt(1) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p2.date_signed ? cf2_data_p2.date_signed.charAt(2) : ''}}</v-col>
                                    <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p2.date_signed ? cf2_data_p2.date_signed.charAt(3) : ''}}</v-col>
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub" ><label class="sub-header-subtitle">Year</label></v-col>
                                </v-row>
                            </v-col>
                    </v-row>
                </v-col>
                
                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="pa-2">
                    <div class="wrap" >
                        <input onclick="return false" :checked="cf2_data_p2.co_pay === 'No'" type="checkbox">
                        <label class="mx-2 sub-header" for="vehicle1">No co-pay on top of PhilHealth Benefit</label><br/>
                    </div>
                    <v-row class="wrap">
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                            <input onclick="return false" :checked="cf2_data_p2.co_pay === 'With'"  type="checkbox">
                            <label class="mx-2 sub-header" for="vehicle1">With co-pay on top of PhilHealth Benefit</label><br/>
                        </v-col>
                        <v-col cols="1" sm="1" md="1" lg="1" xl="1">
                            <h6 class="sub-header text-right mr-1">P</h6>
                        </v-col>
                        <v-col cols="5" sm="5" md="5" lg="5" xl="5">
                            <h6 class="sub-header white--text" style="border-bottom:1px solid black">N/A</h6>
                        </v-col>
                    </v-row>
                </v-col>
            </v-row>

            <v-row align="center" class="border-top wrap mx-1">
                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="border-right">
                    <v-row justify="center" class="pa-2 mb-5 wrap">
                        <h6 class="sub-header text-center mr-2">Accreditation No:</h6>
                        <div class="box_no_top_pan"></div>
                        <div class="box_no_top_pan"></div>
                        <div class="box_no_top_pan"></div>
                        <div class="box_no_top_pan"></div>
                        <h6 class="sub-header mx-1">-</h6>
                        <div class="box_no_top_pan"></div>
                        <div class="box_no_top_pan"></div>
                        <div class="box_no_top_pan"></div>
                        <div class="box_no_top_pan"></div>
                        <div class="box_no_top_pan"></div>
                        <div class="box_no_top_pan"></div>
                        <div class="box_no_top_pan"></div>
                        <h6 class="sub-header mx-1">-</h6>
                        <div class="box_no_top_pan"></div>
                    </v-row>

                    <v-row justify="center" class="wrap">
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="px-2">
                            <h6 class="sub-header text-center border-bottom  white--text">N/A</h6>
                            <h6 class="sub-header text-center font-weight-regular pa-0 ma-0">Signature Over Printed Name</h6>
                        </v-col>
                    </v-row>

                    <v-row justify="center" class="wrap pa-2">
                        <h6 class="sub-header text-center mr-2">Date Signed:</h6>
                        <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                            <v-row class="wrap">
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top"></v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top"></v-col>
                                <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Month</label></v-col>
                            </v-row>
                        </v-col>
                        <h6 class="sub-header mx-1">-</h6>
                        <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                            <v-row class="wrap">
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top"></v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top"></v-col>
                                <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Day</label></v-col>
                            </v-row>
                        </v-col>
                        <h6 class="sub-header mx-1">-</h6>
                        <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                            <v-row class="wrap">
                                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top"></v-col>
                                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top"></v-col>
                                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top"></v-col>
                                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top"></v-col>
                                <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Year</label></v-col>
                            </v-row>
                        </v-col>
                    </v-row>
                </v-col>
                
                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="pa-2">
                    <div class="wrap" >
                        <input onclick="return false" type="checkbox">
                        <label  class="mx-2 sub-header" >No co-pay on top of PhilHealth Benefit</label><br/>
                    </div>
                    <v-row class="wrap" >
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                            <input onclick="return false" type="checkbox">
                            <label  class="mx-2 sub-header" >With co-pay on top of PhilHealth Benefit</label><br/>
                        </v-col>
                        
                        <v-col cols="5" sm="5" md="5" lg="5" xl="5">
                            <h6 class="border-bottom sub-header white--text" >N/A</h6>
                        </v-col>
                    </v-row>
                </v-col>
            </v-row>
        </v-col>
    </v-row>   
  

    <!-- CERTIFICATION OF CONSUMPTION OF BENEFITS AND CONSENT TO ACCESS PATIENT RECORD/S -->
    <h4 class="h4-header text-center font-header white--text black padding-y1 ">PART III - CERTIFICATION OF CONSUMPTION OF BENEFITS AND CONSENT TO ACCESS PATIENT RECORD/S</h4>
    <h5 class="h5-header text-center font-header white--text black padding-y1 font-weight-regular" >NOTE: Member/Patient should sign only after the applicable charges have been filled-out</h5>

    <div class="pa-3 wrap">
        <h6 class="sub-header my-2">A.CERTIFICATION OF CONSUMPTION OF BENEFITS:</h6>
        <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-5">
            <v-row class="wrap">
                <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="text-right pr-2"> <input onclick="return false" :checked="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '1'" type="checkbox" ></v-col>
                <v-col cols="11" sm="11" md="11" lg="11" xl="11" class="px-2">
                    <label class="table-subtitle line-height-sub" >PhilHealth benefit is enough to cover HCI and PF Charges.No purchase of drugs/medicines, supplies, diagnostics, and co-pay for professional fees by the member/patient</label>
                    <table class="font-label" style="box-sizing:border-box;width:90%;border:1px solid black;border-collapse: collapse; " border>
                        <tr>
                            <td class="" style="color:white">text</td>
                            <td class="">Total Actual Charges*</td>
                        </tr>
                        <tr>
                            <td>Total Health Care Institution Fees</td>
                            <td v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '1'">{{cf2_data_p2.CERTIFICATION.total_health_inst_fees ? Number(parseFloat(cf2_data_p2.CERTIFICATION.total_health_inst_fees).toFixed(2)).toLocaleString('en',{minimumFractionDigits: 2}) : 'N/A'}}</td>
                            <td v-else class="pl-1">0.00</td>
                        </tr>
                        <tr>
                            <td>Total Professional Fees</td>
                            <td v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '1'">{{cf2_data_p2.CERTIFICATION.total_professional_fees ? Number(parseFloat(cf2_data_p2.CERTIFICATION.total_professional_fees).toFixed(2)).toLocaleString('en',{minimumFractionDigits: 2}) : 'N/A' }}</td>
                            <td v-else class="pl-1">0.00</td>
                        </tr>
                        <tr>
                            <td>Grand Total</td>
                            <td v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '1'">{{cf2_data_p2.CERTIFICATION.grand_total ? Number(parseFloat(cf2_data_p2.CERTIFICATION.grand_total).toFixed(2)).toLocaleString('en',{minimumFractionDigits: 2}): 'N/A'}}</td>
                            <td v-else class="pl-1">0.00</td>
                        </tr>
                    </table>
                </v-col>
            </v-row>
        </v-col>

        <v-row class="mb-5 wrap">
            <v-col cols="1" sm="1" md="1" lg="1" xl="1" class="text-right pr-2">
                <input onclick="return false" type="checkbox" :checked="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" >
            </v-col>
            <v-col cols="11" sm="11" md="11" lg="11" xl="11" class="px-2">
                <p  class="table-subtitle mb-1">The benefit of the member/patient was completely consumed prior to co-pay OR the benefit of the member/patient is not completely consumed BUT with purchases/expenses for drugs/medicines, supplies, diagnostics and others.</p>
                <h6 class="table-subtitle font-weight-regular">a.) The total co-pay for the following are:</h6>

                <table class="mb-5 font-label" style="box-sizing:border-box;width:90%;border:1px solid black;border-collapse: collapse" border>
                    <tr>
                        <td style="color:white">text</td>
                        <td class="sub-header pl-1">Total Actual Charges*</td>
                        <td class="sub-header pl-1">Amount after Application of Discount (i.e., personal discount, Senior Citizen/PWD)</td>
                        <td class="sub-header pl-1">Philhealth Benefit</td>
                        <td class="sub-header pl-1">Amount after Philhealth Deduction</td>
                    </tr>
                    <tr>
                        <td class="sub-header pl-1">Total Health Care Institution Fees</td>
                        <td v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" class="sub-header">{{cf2_data_p2.CERTIFICATION.co_hcf_total_actual_charges ? Number(parseFloat(cf2_data_p2.CERTIFICATION.co_hcf_total_actual_charges).toFixed(2)).toLocaleString('en',{minimumFractionDigits:2}) : 'N/A'}}</td>
                        <td v-else class="pl-1">0.00</td>
                        
                        <td v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" class="sub-header">{{cf2_data_p2.CERTIFICATION.co_hcf_amt_after_dsct ? Number(parseFloat(cf2_data_p2.CERTIFICATION.co_hcf_amt_after_dsct).toFixed(2)).toLocaleString('en',{minimumFractionDigits:2}) : 'N/A'}}</td>
                        <td v-else class="pl-1">0.00</td>
                        
                        <td v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" class="sub-header">{{cf2_data_p2.CERTIFICATION.co_hcf_phic_benefit ? Number(parseFloat(cf2_data_p2.CERTIFICATION.co_hcf_phic_benefit).toFixed(2)).toLocaleString('en',{minimumFractionDigits:2}) : 'N/A'}}</td>
                        <td v-else class="pl-1">0.00</td>
                        
                        <td>
                            <v-row class="wrap" justify="space-around">
                                <h6 class="sub-header font-weight-regular mt-3">Amount</h6>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <h6  v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" class="sub-header border-bottom">{{cf2_data_p2.CERTIFICATION.co_hcf_amt_after_phic_deduc ? Number(parseFloat(cf2_data_p2.CERTIFICATION.co_hcf_amt_after_phic_deduc).toFixed(2)).toLocaleString('en',{minimumFractionDigits: 2}) : 'N/A'}}</h6>
                                    <h6  v-else class="sub-header border-bottom">0.00</h6>
                                </v-col>
                            </v-row>
                            <div class="wrap" >
                                <h6 class="sub-header font-weight-regular pl-1" >Paid by (check all that applies):</h6>
                                <v-col cols="8" sm="8" md="8" lg="8" xl="8">
                                    <input v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" onclick="return false" :checked="cf2_data_p2.CERTIFICATION.co_hcf_paid_by.includes('Member/Patient')" type="checkbox">
                                    <input v-else onclick="return false"  type="checkbox">
                                    <label  class="sub-header mx-2" for="vehicle1">Member/Patient</label>
                                </v-col>

                                <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                                    <input v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" onclick="return false"  :checked="cf2_data_p2.CERTIFICATION.co_hcf_paid_by.includes('HMO')" type="checkbox">
                                    <input v-else onclick="return false"  type="checkbox">
                                    <label  class="sub-header mx-2"  for="vehicle1">HMO</label>
                                </v-col>

                                <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                                        <input v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" onclick="return false" :checked="cf2_data_p2.CERTIFICATION.co_hcf_paid_by.includes('Other')" type="checkbox">
                                        <input v-else onclick="return false"  type="checkbox">
                                        <label  class="sub-header mx-2" >Others (i.e., PCSO, Promisory note, etc.</label>
                                </v-col>
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <td class="sub-header">Total Professional Fees (for accredited and non-accredited professional)</td>
                        <td v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" class="sub-header">{{cf2_data_p2.CERTIFICATION.co_pf_total_actual_charges ? Number(parseFloat(cf2_data_p2.CERTIFICATION.co_pf_total_actual_charges).toFixed(2)).toLocaleString('en',{minimumFractionDigits:2}) : 'N/A'}}</td>
                        <td v-else class="sub-header pl-1">0.00</td>
                        
                        <td v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" class="sub-header">{{cf2_data_p2.CERTIFICATION.co_pf_amt_after_dsct ? Number(parseFloat(cf2_data_p2.CERTIFICATION.co_pf_amt_after_dsct).toFixed(2)).toLocaleString('en',{minimumFractionDigits:2}) : 'N/A'}}</td>
                        <td v-else class="sub-header pl-1">0.00</td>

                        <td v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" class="sub-header">{{cf2_data_p2.CERTIFICATION.co_pf_phic_benefit ?Number(parseFloat( cf2_data_p2.CERTIFICATION.co_pf_phic_benefit).toFixed(2)).toLocaleString('en',{minimumFractionDigits:2}) : 'N/A'}}</td>
                        <td v-else class="sub-header pl-1">0.00</td>
                        
                        <td>
                            <v-row class="wrap" justify="space-around">
                                <h6 class="sub-header font-weight-regular mt-3">Amount</h6>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                    <h6  v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" class="border-bottom sub-header" >{{cf2_data_p2.CERTIFICATION.co_pf_amt_after_phic_deduc ? Number(parseFloat(cf2_data_p2.CERTIFICATION.co_pf_amt_after_phic_deduc).toFixed(2)).toLocaleString('en',{minimumFractionDigits: 2}) : 'N/A'}}</h6>
                                    <h6  v-else class="sub-header border-bottom">0.00</h6>
                                </v-col>
                            </v-row>
                            <div class="wrap" >
                                <h6 class="sub-header font-weight-regular pl-1" >Paid by (check all that applies):</h6>
                                <v-col cols="8" sm="8" md="8" lg="8" xl="8">
                                    <input v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" onclick="return false" :checked="cf2_data_p2.CERTIFICATION.co_pf_paid_by.includes('Member/Patient')"  type="checkbox"> 
                                    <input v-else onclick="return false"  type="checkbox">
                                    <label  class="sub-header mx-2" for="vehicle1">Member/Patient</label>
                                </v-col>

                                <v-col cols="4" sm="4" md="4" lg="4" xl="4">                                           
                                    <input v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" onclick="return false" :checked="cf2_data_p2.CERTIFICATION.co_pf_paid_by.includes('HMO')"  type="checkbox">
                                    <input v-else onclick="return false"  type="checkbox">
                                    <label  class="sub-header mx-2" for="vehicle1">HMO</label>
                                </v-col>

                                <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                                    <input  v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" onclick="return false" :checked="cf2_data_p2.CERTIFICATION.co_pf_paid_by.includes('Other')"  type="checkbox">
                                    <input v-else onclick="return false"  type="checkbox">                                        
                                    <label  class="sub-header mx-2" for="vehicle1">Others (i.e., PCSO, Promisory note, etc.</label>
                                </v-col>
                            </div>
                        </td>
                    </tr>
                    
                </table>

                <h6 class="sub-header font-weight-regular">b.) Purchases/Expenses NOT included in the Health Care Institution Charges</h6>
                <table class="font-label" style="box-sizing:border-box;width:90%;border:1px solid black;border-collapse: collapse;" border>
                    <tr class="sub-header">
                        <td style="color:white">text</td>
                        <td class="pl-1">Total Actual Charges*</td>
                    </tr>
                    <tr class="sub-header">
                        <td class="pl-1">Total cost of purchase/s for drugs/medicines and/or medical supplies <Br/> bought by the patient/member within/outside the HCI during confinement</td>
                        <td>
                            <v-row justify="space-around" class="wrap pl-3">
                                <input v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" onclick="return false" :checked="cf2_data_p2.CERTIFICATION.nco_total_cost_med_sup === 'None'" type="checkbox">
                                <input v-else onclick="return false"  type="checkbox">                                        
                                <label  class="mx-2 d-flex align-center" style="font-size:8pt;" for="vehicle1">None</label>

                                <input v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" onclick="return false" :checked="cf2_data_p2.CERTIFICATION.nco_total_cost_med_sup !== 'None'" type="checkbox">
                                <input v-else onclick="return false"  type="checkbox">                                        
                                <label  class="mx-2 d-flex align-center" style="font-size:8pt" for="vehicle1">Total Amount</label>
                                <h6 class="mx-2 d-flex align-center">P</h6>
                                <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                                    <h6 class="border-bottom" :class="{'white--text' : cf2_data_p2.CERTIFICATION.nco_total_cost_med_sup === 'None' || cf2_data_p2.CERTIFICATION.nco_total_cost_med_sup === null}">{{cf2_data_p2.CERTIFICATION.nco_total_cost_med_sup ? cf2_data_p2.CERTIFICATION.nco_total_cost_med_sup  : 'N/A'}}</h6>
                                </v-col>
                            </v-row>
                        </td>
                    </tr>
                    <tr class="sub-header">
                        <td class="pl-1">Total cost of diagnostic/laboratory examinations paid by the <br/> patient/member done within/outside the HCI during confinement</td>
                        <td>
                            <v-row justify="space-around" class="wrap pl-3">
                                <input v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" onclick="return false" :checked="cf2_data_p2.CERTIFICATION.nco_total_cost_diagnostic_laboratory === 'None'" type="checkbox">
                                <input v-else onclick="return false"  type="checkbox">                                        
                                <label class="mx-2 d-flex align-center" style="font-size:8pt" for="vehicle1">None</label>
                                
                                <input v-if="cf2_data_p2.CERTIFICATION.phic_ben_is_enough === '2'" onclick="return false" :checked="cf2_data_p2.CERTIFICATION.nco_total_cost_diagnostic_laboratory !== 'None'" type="checkbox">
                                <input v-else onclick="return false"  type="checkbox">                                        
                                <label class="mx-2 d-flex align-center" style="font-size:8pt" for="vehicle1">Total Amount</label>
                                <h6 class="mx-2 d-flex align-center">P</h6>
                                <v-col cols="3" sm="3" md="3" lg="3" xl="3">
                                    <h6 class="border-bottom" :class="{'white--text' : cf2_data_p2.CERTIFICATION.nco_total_cost_diagnostic_laboratory === 'None' || cf2_data_p2.CERTIFICATION.nco_total_cost_diagnostic_laboratory === null}">{{cf2_data_p2.CERTIFICATION.nco_total_cost_diagnostic_laboratory ? cf2_data_p2.nco_total_cost_diagnostic_laboratory : 'N/A'}}</h6>
                                </v-col>
                            </v-row>
                        </td>
                    </tr>
                    
                </table>
                <h6 class="sub-header px-2" >* NOTE: <span class="font-weight-regular">Total Actual Charges should be based on Statement of Account (SOA)</span></h6>
            </v-col>
        </v-row>
     
        <h6 class="sub-header mb-2">B.CONSENT TO ACCESS PATIENT RECORD/S:</h6>
        <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="pa-2">
            <p class="small mb-0" style="position:relative;z-index:2 "><i><b>I hereby consent to the submission and examination of the patient’s pertinent medical records for the purpose of verifying the veracity of this claim to effect efficient processing of benefit payment. I hereby hold PhilHealth or any of its officers, employees and/or representatives free from any and all legal liabilities relative to the herein-mentioned consent which I have voluntarily and willingly given in connection with this claim for reimbursement before PhilHealth.</b></i></p>
            <v-row align="center" class="wrap pa-2">
                <v-col cols="8" sm="8" md="8" lg="8" xl="8">
                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-2">
                        <v-row class="wrap">
                            <v-col cols="7" sm="7" md="7" lg="7" xl="7" class="px-2" style="position:relative">
                                <!-- <h6 class="sub-header text-center text-uppercas grey--text text--darken-2 mt-4">SIGNATURE HAS BEEN PROVIDED</h6> -->
                                <v-img :src="cf2_data_p2.TRANSACTION.patient_sign_path" height="30" contain></v-img>
                                <h6 class="sub-header text-center border-bottom mt-2" style="position:relative;z-index:2">{{ textCapitalize(cf2_data_p2.PRINCIPAL_DATA.first_name) + ' ' + (textCapitalize(cf2_data_p2.PRINCIPAL_DATA.middle_name) ? textCapitalize(cf2_data_p2.PRINCIPAL_DATA.middle_name) : '') + ' ' + textCapitalize(cf2_data_p2.PRINCIPAL_DATA.last_name) + ' ' + (textCapitalize(cf2_data_p2.PRINCIPAL_DATA.suffix) ? textCapitalize(cf2_data_p2.PRINCIPAL_DATA.suffix) : '')}}</h6>
                                <h6 class="sub-header font-weight-regular pa-0 ma-0 text-center" >Signature Over Printed Name of Member/Patient/Authorized Representative</h6>
                            </v-col>
                        </v-row>
                    </v-col>

                    <v-col cols="10" sm="10" md="10" lg="10" xl="10" class="mb-2">
                            <v-row justify="center" class="wrap">
                                <h6 class="sub-header text-center mr-2">Date Signed:</h6>
                                <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                    <v-row class="wrap">
                                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p2.SIGNATURE.patient_date_signed ? cf2_data_p2.SIGNATURE.patient_date_signed.charAt(5) : ''}}</v-col>
                                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p2.SIGNATURE.patient_date_signed ? cf2_data_p2.SIGNATURE.patient_date_signed.charAt(6) : ''}}</v-col>
                                        <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Month</label></v-col>
                                    </v-row>
                                </v-col>
                                <h6 class="sub-header mx-1">-</h6>
                                <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                                    <v-row class="wrap">
                                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p2.SIGNATURE.patient_date_signed ? cf2_data_p2.SIGNATURE.patient_date_signed.charAt(8) : ''}}</v-col>
                                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p2.SIGNATURE.patient_date_signed ? cf2_data_p2.SIGNATURE.patient_date_signed.charAt(9) : ''}}</v-col>
                                        <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Day</label></v-col>
                                    </v-row>
                                </v-col>
                                <h6 class="sub-header mx-1">-</h6>
                                <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                                    <v-row class="wrap">
                                        <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p2.SIGNATURE.patient_date_signed ? cf2_data_p2.SIGNATURE.patient_date_signed.charAt(0) : ''}}</v-col>
                                        <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p2.SIGNATURE.patient_date_signed ? cf2_data_p2.SIGNATURE.patient_date_signed.charAt(1) : ''}}</v-col>
                                        <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p2.SIGNATURE.patient_date_signed ? cf2_data_p2.SIGNATURE.patient_date_signed.charAt(2) : ''}}</v-col>
                                        <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p2.SIGNATURE.patient_date_signed ? cf2_data_p2.SIGNATURE.patient_date_signed.charAt(3) : ''}}</v-col>
                                        <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Year</label></v-col>
                                    </v-row>
                                </v-col>
                            </v-row>
                    </v-col>

                    <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="mb-2">
                        <v-row align="center" class="wrap">
                            <h6 class="sub-header font-weight-regular mr-2">Relationship of the representative to<br/> the member/patient</h6>
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                <v-row class="wrap">
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                                        <v-row class="wrap">
                                            <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                                                <v-row align="center">
                                                    <input onclick="return false" :checked="cf2_data_p2.PATIENT_DATA.rel_to_patient === 'Spouse'" type="checkbox" >
                                                    <label  class="mx-2 sub-header" for="vehicle1">Spouse</label><br/>
                                                    <input onclick="return false" :checked="cf2_data_p2.PATIENT_DATA.rel_to_patient === 'Child'" type="checkbox" >
                                                    <label  class="mx-2 sub-header" for="vehicle1">Child</label>
                                                    <input onclick="return false" :checked="cf2_data_p2.PATIENT_DATA.rel_to_patient === 'Parent'" type="checkbox" >
                                                    <label  class="mx-2 sub-header" for="vehicle1">Parent</label>
                                                </v-row>
                                            </v-col>
                                            <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                                                <v-row class="wrap">
                                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                                                        <v-row class="wrap">
                                                            <input onclick="return false" :checked="cf2_data_p2.PATIENT_DATA.rel_to_patient === 'Sibling'" type="checkbox" >
                                                            <label  class="mx-2 sub-header" for="vehicle1">Sibling</label>
                                                            <input onclick="return false" :checked="cf2_data_p2.PATIENT_DATA.rel_to_patient !== 'Spouse' && cf2_data_p2.PATIENT_DATA.rel_to_patient !== 'Sibling' && cf2_data_p2.PATIENT_DATA.rel_to_patient !== 'Child' && cf2_data_p2.PATIENT_DATA.rel_to_patient !== 'Parent'  && cf2_data_p2.PATIENT_DATA.rel_to_patient !== null " type="checkbox" ><label  class="mx-2 sub-header" for="vehicle1">Others, Specify</label>
                                                            <h6 :class="{'white--text' :cf2_data_p2.PATIENT_DATA.rel_to_patient === 'Spouse' || cf2_data_p2.PATIENT_DATA.rel_to_patient === 'Sibling' || cf2_data_p2.PATIENT_DATA.rel_to_patient === 'Child' || cf2_data_p2.PATIENT_DATA.rel_to_patient === 'Parent'}" class="sub-header border-bottom" style="width:40%">{{cf2_data_p2.PATIENT_DATA.rel_to_patient ? cf2_data_p2.PATIENT_DATA.rel_to_patient : 'N/A'}}</h6>
                                                        </v-row>
                                                    </v-col>
                                                </v-row>
                                            </v-col>
                                        </v-row>
                                    </v-col>
                                    
                                </v-row>
                            </v-col>
                        </v-row>
                    </v-col>

                    <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                        <v-row align="center" class="wrap">
                            <h6 class="sub-header font-weight-regular mr-2" >Reason for signing on behalf of the <br/> member/patient:</h6>
                            <v-col cols="6" sm="6" md="6" lg="6" xl="6">
                                <v-row class="wrap">
                                    <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                                        <v-row class="wrap">
                                            <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                                                <v-row align="center">
                                                    <input onclick="return false" :checked="cf2_data_p2.PATIENT_DATA.rel_for_signing_on_behalf === 'Incapacitated'"  type="checkbox">
                                                    <label  class="mx-2 sub-header" for="vehicle1">Patient is Incapacitated</label> <br/>
                                                    <input onclick="return false" :checked="cf2_data_p2.PATIENT_DATA.rel_for_signing_on_behalf === 'Patient'" type="checkbox" >
                                                    <label  class="mx-2 sub-header" for="vehicle1">Patient</label><br/>
                                                    <input onclick="return false" :checked="cf2_data_p2.PATIENT_DATA.rel_for_signing_on_behalf === 'Representative'" type="checkbox" >
                                                    <label  class="mx-2 sub-header" for="vehicle1">Representative</label>
                                                </v-row>
                                            </v-col>
                                            
                                            <v-col cols="12" sm="12" md="12" lg="12" xl="12">
                                                <v-row class="wrap">
                                                    <input onclick="return false" :checked="cf2_data_p2.PATIENT_DATA.rel_for_signing_on_behalf !== 'Incapacitated' && cf2_data_p2.PATIENT_DATA.rel_for_signing_on_behalf !== 'Representative' &&  cf2_data_p2.PATIENT_DATA.rel_for_signing_on_behalf !== 'Patient' &&  cf2_data_p2.PATIENT_DATA.rel_for_signing_on_behalf !== null && cf2_data_p2.PATIENT_DATA.rel_for_signing_on_behalf !== ''" type="checkbox"><label  class="mx-2 sub-header" for="vehicle1">Other Reasons</label>
                                                    <h6 :class="{'white--text' : cf2_data_p2.PATIENT_DATA.rel_for_signing_on_behalf == 'Incapacitated' || cf2_data_p2.PATIENT_DATA.rel_for_signing_on_behalf == 'Representative' || cf2_data_p2.PATIENT_DATA.rel_for_signing_on_behalf == 'Patient'}" class="border-bottom" style="width:40%;word-wrap: break-word" >{{cf2_data_p2.PATIENT_DATA.rel_for_signing_on_behalf ? cf2_data_p2.PATIENT_DATA.rel_for_signing_on_behalf : 'N/A'}}</h6>
                                                </v-row>
                                            </v-col>
                                        </v-row>
                                    </v-col>
                                </v-row>
                            </v-col>
                        </v-row>
                    </v-col>
                </v-col>  

                <v-col cols="4" sm="4" md="4" lg="4" xl="4">
                    <v-row class="wrap">
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" align-self="start">
                            <p class="sub-header mb-4" >If patient/representative is unable to write, put right thumbmark. Patient/ Representative should be assisted by an HCI representative</p>
                        </v-col>
                        <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="px-2">
                            <div style="height:200px;border:1px solid black"></div> 
                        </v-col>
                    </v-row>
                </v-col>
            </v-row>
        </v-col>
    </div>

    <!-- CERTIFICATION -->
    <h4 class="h4-header text-center white--text black py-1">PART IV - CERTIFICATION OF CONSUMPTION OF HEALTH CARE INSTITUTION</h4>
    <div class="wrap pa-2">
        <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center p-b-2 my-1"> <!--  Name of Health Care Institution: -->
            <h6 class="sub-header mb-3" style="position:relative;z-index:2"><i>I certify that services rendered were recorded in the patient’s chart and health care institution records and that the herein information given are true and correct</i></h6>
            <v-row wrap no-gutters align="center">
                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2" style="position:relative;z-index:1">
                    <!-- <h6 class="sub-header text-center text-uppercas grey--text text--darken-2">SIGNATURE HAS BEEN PROVIDED</h6> -->
                    <!-- <v-img :src="cf2_data_p2.SIGNATURE.hospital_date_signed" height="30" contain></v-img> -->
                    <h6 class="sub-header text-center border-bottom mt-2" style="position:relative;z-index:2">{{cf2_data_p2.provider_representative ? cf2_data_p2.provider_representative : 'N/A'}}</h6>
                    <h6 class="sub-header font-weight-regular pa-0 ma-0" style="z-index:2">Signature Over Printed Name of Employer/Authorized Representative</h6>
                </v-col>

                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="px-2">
                    <h6 class="sub-header text-center border-bottom">{{cf2_data_p2.provider_official_capacity ? cf2_data_p2.provider_official_capacity : 'N/A'}}</h6>
                    <h6 class="sub-header font-weight-regular pa-0 ma-0">Official Capacity/Designation</h6>
                </v-col>

                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="px-2 mt-2">
                    <v-row wrap justify="center">
                        <h6 class="sub-header text-center mr-2">Date Signed:</h6>
                        <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                            <v-row wrap>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p2.SIGNATURE.hospital_date_signed ? cf2_data_p2.SIGNATURE.hospital_date_signed.charAt(5) : ''}}</v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p2.SIGNATURE.hospital_date_signed ? cf2_data_p2.SIGNATURE.hospital_date_signed.charAt(6) : ''}}</v-col>
                                <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Month</label></v-col>
                            </v-row>
                        </v-col>
                        <h6 class="sub-header mx-1">-</h6>
                        <v-col cols="2" sm="2" md="2" lg="2" xl="2">
                            <v-row wrap>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p2.SIGNATURE.hospital_date_signed ? cf2_data_p2.SIGNATURE.hospital_date_signed.charAt(8) : ''}}</v-col>
                                <v-col cols="6" sm="6" md="6" lg="6" xl="6" class="box_no_top">{{cf2_data_p2.SIGNATURE.hospital_date_signed ? cf2_data_p2.SIGNATURE.hospital_date_signed.charAt(9) : ''}}</v-col>
                                <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Day</label></v-col>
                            </v-row>
                        </v-col>
                        <h6 class="sub-header mx-1">-</h6>
                        <v-col cols="5" sm="5" md="5" lg="5" xl="5">
                            <v-row wrap>
                                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p2.SIGNATURE.hospital_date_signed ? cf2_data_p2.SIGNATURE.hospital_date_signed.charAt(0) : ''}}</v-col>
                                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p2.SIGNATURE.hospital_date_signed ? cf2_data_p2.SIGNATURE.hospital_date_signed.charAt(1) : ''}}</v-col>
                                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p2.SIGNATURE.hospital_date_signed ? cf2_data_p2.SIGNATURE.hospital_date_signed.charAt(2) : ''}}</v-col>
                                <v-col cols="3" sm="3" md="3" lg="3" xl="3" class="box_no_top">{{cf2_data_p2.SIGNATURE.hospital_date_signed ? cf2_data_p2.SIGNATURE.hospital_date_signed.charAt(3) : ''}}</v-col>
                                <v-col cols="12" sm="12" md="12" lg="12" xl="12" class="text-center line-height-sub"><label class="sub-header-subtitle">Year</label></v-col>
                            </v-row>
                        </v-col>
                    </v-row>
                </v-col>
            </v-row>
        </v-col>
    </div>
     
 
  </div>
</template>

<script>

export default {
    props:["menu","cf2_data_p2", "cf2_data_p1"],
    data:()=>({
        patient_img_loader : true,  
        provider_img_loader: true,
        doctor_img_loader:true,
        sign_status:[],
    }),
    computed:{
        doctor_info(){
            return  this.cf2_data_p2.doctor_info
        }
    }
}
</script>

<style scoped>
.border-bottom{border-bottom:1px solid black}
.border-right{border-right:1px solid black}
.border-top{border-top:1px solid black}
.box_no_top_pan{
  border-left:1px solid black;
  border-right:1px solid black;
  border-bottom:1px solid black;
  font-size:10pt;
  text-align: center;
  width:3%;
}
.box_no_top{
  border-left:1px solid black;
  border-right:1px solid black;
  border-bottom:1px solid black;
  font-size:10pt;
  text-align: center;
}
.cf2_test2{
  padding-top:3em ;
  padding-left:2.35em !important;
  padding-right:2.55em !important;
}
.font-label, .table-subtitle{ font-size:10pt}
.h4-header{font-size:11.5pt}
.h5-header{font-size:9pt}

.line-height-sub{line-height: 0.8;}
.signature{
  position:absolute;
  margin-left: auto;
  margin-right:auto;
  top:-50px;
  left:0;
  right:0;
  z-index:1
}
.signature_prov{
  position: absolute;
  margin-left: auto;
  margin-right:auto;
  top:-55px;
  left:0;
  right:0;
  z-index:1
}
.sub-header, .small{font-size:8pt}
.sub-header-subtitle{font-size:7pt}

.m-t-10{margin-top:2.5em}
.m-t-12{margin-top:2.5em}
.p-b-2{padding-bottom:0.5em}

.sign_err{visibility: hidden;}
.wrap {
    display: flex;
    flex-wrap: wrap !important;
}

@media print{
  
  .box_no_top, .small, .table-subtitle{font-size:6pt;}
  .box_no_top_pan{font-size:6pt;width:4%}
  .cf2_test2{
    padding:0!important
  }

  .h4-header, .font-label{font-size:7pt !important}
  .line-height-sub{line-height: 0.4;}
  .signature{ margin-left:-50px }
  .signature_prov{margin-left:70px}
  .sub-header, .sub-header-subtitle{font-size:5pt}
  .doc_cf2_id{display: none}
  #patient_id{display:none}

  .wrap {
        flex-wrap: wrap !important;
    }
 
  /* #patient_signature,#provider_signature{height:20px;width:100px;border: none !important;} */

  #provider_id{display:none}
  
  .m-t-10{margin-top:1.5em}
/* 
  [id^="doc_image"] {
      position: relative;
      height:50px;
      background:red;
  }  */

}
</style>