<template>
    <div>
        <v-form :readonly="!trans_detail.editable">
            <!-- CERTIFICATION OF CONSUMPTION OF BENEFITS -->
            <v-row wrap>
                <v-col cols="6" sm="6" md="6" lg="6">
                    <h1 class="section-title">
                        CERTIFICATION OF CONSUMPTION OF BENEFITS
                        <v-btn v-if="trans_detail.editable && !!ctf_data.phic_ben_is_enough" @click="ctf_data.phic_ben_is_enough = null, checkDataStatus('certification')" class="ml-2" width="60" height="25" small>Clear</v-btn>
                    </h1>
                </v-col>
                <v-col cols="6" sm="6" md="6" lg="6" class="text-right">
                    <v-btn v-if="trans_detail.crd_claims_status === 'Screening Rejected' && !!comment_data.cf2_part3_lettera" @click="displayCommentData('consumption')" color="primary" tile depressed small>CHECK COMMENTS 
                        <v-badge content="!" color="red">
                            <v-icon class="pl-1" small>mdi-comment</v-icon>
                        </v-badge>
                    </v-btn>
                </v-col>
            </v-row>
            <v-divider></v-divider>

            <h2 class="my-3 pb-2 title" style="border-bottom: 1px solid black">Total amount of Procedure/s: {{ cert_data.total_cpt_amount }}</h2>
            
            <!-- PHILHEALTH BENEFIT IS ENOUGH -->
            <v-radio-group v-model="ctf_data.phic_ben_is_enough" @change="checkDataStatus('certification')" class="mt-2">
                <v-radio value="1" label="Philhealth benefit is enough to cover HCI and PF charges. No Purchase of drugs/medicines, supplies, diagnostics and co-pay for professional fees by the member/patient"></v-radio>
            </v-radio-group>
        
            <v-row :class="{'opacity' : ctf_data.phic_ben_is_enough !== '1'}" wrap>
                <v-col cols="1" sm="1" md="2" lg="2"></v-col>
                <v-col cols="11" sm="8" md="8" lg="7">
                    <v-row align="baseline" wrap>
                        <v-col cols="7" sm="7" md="5" lg="4"></v-col>
                        <v-col cols="5" sm="5" md="5" lg="6" class="text-center">
                            <label class="body-2">Total Actual Charges*</label>
                        </v-col>
                        <v-col cols="7" sm="7" md="5" lg="4">
                            <label class="body-2">Total Health Institution Fees:</label>
                        </v-col>
                        <v-col cols="5" sm="5" md="5" lg="6" class="text-center">
                            <label class="body-2">{{ ctf_data.total_health_inst_fees }}</label>
                        </v-col>
                        <v-col cols="7" sm="7" md="5" lg="4">
                            <label class="body-2">Total Professional Fees:</label>
                        </v-col>
                        <v-col cols="5" sm="5" md="5" lg="6" class="text-center">
                            <label class="body-2">{{ ctf_data.total_professional_fees }}</label>
                        </v-col>
                        <v-col cols="7" sm="7" md="5" lg="4">
                            <label class="body-2">Grand Total:</label>
                        </v-col>
                        <v-col cols="5" sm="5" md="5" lg="6" class="text-center">
                            <label class="body-2">{{ ctf_data.grand_total }}</label>
                        </v-col>
                    </v-row>
                </v-col>
            </v-row>
            
            <!-- PHILHEALTH BENEFIT IS CONSUMED -->
            <v-radio-group v-model="ctf_data.phic_ben_is_enough" @change="checkDataStatus('certification')">
                <v-radio value="2" disabled label="The benefit of the member/patient was completely consumed prior to co-pay OR the benefit of the member/patient is not completely consumed BUT with purchases/expenses for drugs/medicines, supplies, diagnostics and others"></v-radio>
            </v-radio-group>
            
            <div :class="{'opacity' : ctf_data.phic_ben_is_enough !== '2'}">
                <h5>a.) The total co-pay for the following are:</h5>

                <v-row class="text-center" justify="space-around" dense>
                    <v-col class="d-flex text-left" cols="12" sm="12" md="2" lg="2">
                        <label class="body-2 align-self-end pb-7">Total Health Institution Fees:</label>
                    </v-col>

                    <v-col class="d-flex flex-column" cols="6" sm="5" md="2" lg="2">
                        <label class="body-2">Total Actual Charges*</label>
                        <v-text-field v-model="ctf_data.co_hcf_total_actual_charges" v-on:keypress="numberOnly($event, ctf_data.co_hcf_total_actual_charges)" v-on:keyup="autoCompute('hif')" :readonly="this.ctf_data.phic_ben_is_enough !== '2'" @blur="addDecimal('hif_charges', ctf_data.co_hcf_total_actual_charges)" @input="ctf_data.co_hcf_amt_after_dsct = '0.00'" onpaste="return false" class="body-2 align-end">
                            <template v-slot:append>
                                <v-tooltip v-if="total_actual_charges_tooltip && ctf_data.co_hcf_total_actual_charges.charAt(0) !== '0'" bottom>
                                    <template #activator="{ on }">
                                        <v-icon v-on="on" class="mr-1" color="red" size="20">fas fa-exclamation-circle</v-icon>
                                    </template>
                                    {{ ctf_data.co_pf_total_actual_charges.charAt(0) === '0' ? 'Amount should not exceed the total amount of procedures' : 'Total HCI Fee and Professional fee should not exceed the total amount of procedure.' }}
                                </v-tooltip>
                            </template>
                        </v-text-field>
                    </v-col>

                    <v-col class="d-flex flex-column justify-space-between" cols="6" sm="5" md="2" lg="2">
                        <label class="body-2">PhilHealth Benefit</label>
                        <label class="body-2 font-weight-medium pb-7">{{ ctf_data.co_hcf_phic_benefit }}</label>
                    </v-col>

                    <v-col cols="6" sm="5" md="2" lg="2">
                        <label class="body-2">Amount after application of discount (i.e. Personal Discount, Senior Citizen, PWD)</label>
                        <v-text-field v-model="ctf_data.co_hcf_amt_after_dsct"  v-on:keypress="numberOnly($event, ctf_data.co_hcf_amt_after_dsct)" v-on:keyup="autoCompute('hif')" :readonly="this.ctf_data.phic_ben_is_enough !== '2'" @blur="addDecimal('hif_discount', ctf_data.co_hcf_amt_after_dsct)" onpaste="return false" class="body-2"></v-text-field>
                    </v-col>

                    <v-col class="d-flex flex-column justify-space-between" cols="6" sm="5" md="4" lg="4">                
                        <label class="body-2">Amount after Philhealth Deduction</label>
                        <label class="body-2 font-weight-medium pb-7 text-left">Amount: {{ ctf_data.co_hcf_amt_after_phic_deduc }}</label>
                    </v-col>
                    <!-- RADIO BUTTONS -->
                    <v-col offset-sm="7" offset-md="7" offset-lg="9" cols="12" sm="5" md="5" lg="3">
                        <label class="body-2">Paid by: (check all that applies):</label>
                        <v-checkbox v-model="selected_hif_paid_by" :readonly="ctf_data.phic_ben_is_enough !== '2'" @change="addSelectedHIF('Member/Patient', $event)" class="ma-0 pa-0" label="Member/Patient" value="Member/Patient" hide-details multiple dense></v-checkbox>
                        <v-checkbox v-model="selected_hif_paid_by" :readonly="ctf_data.phic_ben_is_enough !== '2'" @change="addSelectedHIF('HMO', $event)" class="ma-0 pa-0" label="HMO" value="HMO" hide-details multiple dense></v-checkbox>
                        <v-checkbox v-model="selected_hif_paid_by" :readonly="ctf_data.phic_ben_is_enough !== '2'" @change="addSelectedHIF('Other', $event)" class="ma-0 pa-0" label="Other (i.e PCSO, Promissory Note, etc.)" value="Other" hide-details multiple dense></v-checkbox>
                    </v-col>
                </v-row>

                <v-divider class="mt-5 mb-6"></v-divider> 
                <v-row class="text-center mb-4" justify="space-around" dense>
                    <v-col class="text-left" cols="12" sm="12" md="2" lg="2">
                        <label class="body-2">Total Professional Fees (For accredited and non-accredited professionals):</label>
                    </v-col>

                    <v-col class="d-flex flex-column" cols="6" sm="5" md="2" lg="2">
                        <label class="body-2 d-inline d-md-none">Total Actual Charges*</label>
                        <v-text-field v-model="ctf_data.co_pf_total_actual_charges" v-on:keypress="numberOnly($event, ctf_data.co_pf_total_actual_charges)" v-on:keyup="autoCompute('pf')" :readonly="ctf_data.phic_ben_is_enough !== '2'" @blur="addDecimal('pf_charges', ctf_data.co_pf_total_actual_charges)" @input="ctf_data.co_pf_amt_after_dsct = '0.00'" onpaste="return false" class="body-2">
                            <template v-slot:append>
                                <v-tooltip v-if="total_actual_charges_tooltip && ctf_data.co_pf_total_actual_charges.charAt(0) !== '0'" bottom>
                                    <template #activator="{ on }">
                                        <v-icon v-on="on" class="mr-1" color="red" size="20">fas fa-exclamation-circle</v-icon>
                                    </template>
                                    {{ ctf_data.co_hcf_total_actual_charges.charAt(0) === '0' ? 'Amount should not exceed the total amount of procedures' : 'Total HCI Fee and Professional fee should not exceed the total amount of procedure.' }}
                                </v-tooltip>
                            </template>
                        </v-text-field>
                    </v-col>

                    <v-col class="d-flex flex-column justify-space-between" cols="6" sm="5" md="2" lg="2">
                        <label class="body-2 d-inline d-md-none">PhilHealth Benefit</label>
                        <label class="body-2 font-weight-medium pb-7 pt-0 pt-md-6">{{ ctf_data.co_pf_phic_benefit }}</label>
                    </v-col>

                    <v-col cols="6" sm="5" md="2" lg="2">
                        <label class="body-2 d-inline d-md-none">Amount after application of discount (i.e. Personal Discount, Senior Citizen, PWD)</label>
                        <v-text-field v-model="ctf_data.co_pf_amt_after_dsct" v-on:keypress="numberOnly($event, ctf_data.co_pf_amt_after_dsct)" v-on:keyup="autoCompute('pf')" :readonly="ctf_data.phic_ben_is_enough !== '2'" @blur="addDecimal('pf_discount', ctf_data.co_pf_amt_after_dsct)"  onpaste="return false" class="body-2"></v-text-field>
                    </v-col>

                    <v-col class="d-flex flex-column justify-space-between" cols="6" sm="5" md="4" lg="4">                
                        <label class="body-2 d-inline d-md-none">Amount after Philhealth Deduction</label>
                        <label class="body-2 font-weight-medium pb-7 text-left pt-0 pt-md-6">Amount: {{ ctf_data.co_pf_amt_after_phic_deduc }}</label>
                    </v-col>
                    <!-- RADIO BUTTONS -->
                    <v-col offset-sm="7" offset-md="7" offset-lg="9" cols="12" sm="5" md="5" lg="3">
                        <label class="body-2">Paid by: (check all that applies):</label>
                        <v-checkbox v-model="selected_pf_paid_by" :readonly="ctf_data.phic_ben_is_enough !== '2'" @change="addSelectedPF('Member/Patient', $event)" class="ma-0 pa-0" label="Member/Patient" value="Member/Patient" hide-details multiple dense></v-checkbox>
                        <v-checkbox v-model="selected_pf_paid_by" :readonly="ctf_data.phic_ben_is_enough !== '2'" @change="addSelectedPF('HMO', $event)" class="ma-0 pa-0" label="HMO" value="HMO" hide-details multiple dense></v-checkbox>
                        <v-checkbox v-model="selected_pf_paid_by" :readonly="ctf_data.phic_ben_is_enough !== '2'" @change="addSelectedPF('Other', $event)" class="ma-0 pa-0" label="Other (i.e PCSO, Promissory Note, etc.)" value="Other" hide-details multiple dense></v-checkbox>
                    </v-col>
                </v-row>
             
        
                <h5>b.) Purchase/Expenses NOT included in the Health Care Institution Charges</h5>
                <v-row wrap>
                    <v-col cols="5" sm="5" md="5" lg="5" class="pt-4 pr-4">
                        <label>Total cost of purchase/s for drugs/medicines and/or medical supplies bought by the patient/member within/outside the HCI during confinement.</label>
                    </v-col>
                    <v-col cols="7" sm="7" md="7" lg="7">
                        <v-row wrap>
                            <v-col cols="12" sm="3" md="3" lg="4">
                                <v-radio-group v-model="ctf_data.nco_total_cost_med_sup" :readonly="ctf_data.phic_ben_is_enough !== '2'" @change="checkDataStatus('certification'), total_purchase_amount = ''" dense>
                                    <v-radio value="None" label="None"></v-radio>
                                </v-radio-group>
                            </v-col>
                            <v-col cols="4" sm="3" md="3" lg="3">
                                <v-radio-group v-model="total_purchase_amount" :readonly="ctf_data.phic_ben_is_enough !== '2'" @change="ctf_data.nco_total_cost_med_sup = ''" dense>
                                    <v-radio value="Total" label="Total Amount:"></v-radio>
                                </v-radio-group>
                            </v-col>
                            <v-col cols="8" sm="6" md="6" lg="5">
                                <v-text-field v-if="total_purchase_amount === 'Total'" v-model="ctf_data.nco_total_cost_med_sup" v-on:keypress="numberOnly($event, ctf_data.nco_total_cost_med_sup)" v-on:keyup="autoCompute('purchase')" :readonly="ctf_data.phic_ben_is_enough !== '2'" @change="checkDataStatus('certification')" @blur="addDecimal('purchase', ctf_data.nco_total_cost_med_sup)" onpaste="return false" class="body-2"></v-text-field>
                                <v-text-field v-else class="body-2" readonly></v-text-field>
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>

                <v-row wrap mt-6>
                    <v-col cols="5" sm="5" md="5" lg="5" class="pt-4 pr-4">
                        <label>Total cost of diagnostic/laboratory examinations paid by the patient/member done within/outside the HCI during confinement.</label>
                    </v-col>
                    <v-col cols="7" sm="7" md="7" lg="7">
                        <v-row wrap>
                            <v-col cols="12" sm="3" md="3" lg="4">
                                <v-radio-group v-model="ctf_data.nco_total_cost_diagnostic_laboratory" :readonly="ctf_data.phic_ben_is_enough !== '2'" @change="checkDataStatus('certification'), total_diagnostic_amount = ''" dense>
                                    <v-radio value="None" label="None"></v-radio>
                                </v-radio-group>
                            </v-col>
                            <v-col cols="4" sm="3" md="3" lg="3">
                                <v-radio-group v-model="total_diagnostic_amount" :readonly="ctf_data.phic_ben_is_enough !== '2'" @change="ctf_data.nco_total_cost_diagnostic_laboratory = ''" dense>
                                    <v-radio value="Total" label="Total Amount:"></v-radio>
                                </v-radio-group>
                            </v-col>
                            <v-col cols="8" sm="6" md="6" lg="5">
                                <v-text-field v-if="total_diagnostic_amount === 'Total'" v-model="ctf_data.nco_total_cost_diagnostic_laboratory" v-on:keypress="numberOnly($event, ctf_data.nco_total_cost_diagnostic_laboratory)" v-on:keyup="autoCompute('diagnostic')" :readonly="ctf_data.phic_ben_is_enough !== '2'" @change="checkDataStatus('certification')" @blur="addDecimal('diagnostic', ctf_data.nco_total_cost_diagnostic_laboratory)" onpaste="return false" class="body-2"></v-text-field>
                                <v-text-field v-else class="body-2" readonly></v-text-field>
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>
            </div>
            
            <!-- CONSENT TO ACCESS PATIENT RECORD/S -->
            <v-row class="mt-5" wrap>
                <h1 class="subtitle-1 grey--text text--darken-3 font-weight-medium">CONSENT TO ACCESS PATIENT RECORD</h1>
                <v-spacer></v-spacer>
                <v-btn v-if="trans_detail.crd_claims_status === 'Screening Rejected' && !!comment_data.cf2_part3_letterb" @click="displayCommentData('consent')" class="ml-2" color="primary" tile depressed small>CHECK COMMENTS 
                    <v-badge content="!" color="red">
                        <v-icon class="pl-1" small>mdi-comment</v-icon>
                    </v-badge>
                </v-btn>
            </v-row>
            <v-divider></v-divider>
            <p class="font-italic body-2 mt-2">I hereby consent to the submission and examination of the patient's pertinent medical records for the purpose of verifying the veracity of this claim to effect efficient processing of benefit payment. I hereby hold Philhealth or any of its officers, employees and/or representatives free from any and all legal liabilities relative to the herein-mentioned consent which I have voluntarily and willingly given in connection with this claim for reimbursement before Philhealth.</p>
            
            <v-row justify="center" align="center">
                <v-col cols="12" md="6" class="text-center">
                    <div class="mb-4">
                        <img v-if="trans_detail.patient_sign_path" :src="trans_detail.patient_sign_path" alt="Signature" width="150" height="auto" />
                    </div>
                    <div class="mt-1 pt-1">
                        <strong>{{ this.patient_name }}</strong>
                    </div>
                    <div class="mt-1 pt-1">
                        <label class="body-2 border-top">Signature over Printed Name / Patient / Authorized Representative</label>
                    </div>
                </v-col>

                <v-col cols="12" md="4" class="text-center">
                    <v-spacer v-if="trans_detail.patient_sign_path" class="mt-10 pt-10"></v-spacer>
                    <v-spacer v-else></v-spacer>
                    <div class="mt-6 mb-2">
                        <strong>{{ signatures.patient }}</strong>
                    </div>
                    <div class="border-top mt-1 pt-1"></div>
                    
                    <label class="body-2">Date Signed</label>
                </v-col>
            </v-row>

            <v-row class="mt-3" wrap>
                <v-col cols="5" sm="5" md="5" lg="5" class="pt-4">
                    <label>
                        Relationship of the representative to the member/patient:
                        <v-btn v-show="trans_detail.editable" v-if="!!relation_reason.rel_to_patient || relationship" @click="relation_reason.rel_to_patient = '', relationship = '', checkDataStatus('other')" width="60" height="25" small>Clear</v-btn>
                    </label>
                </v-col>
                <v-col cols="12" sm="12" md="7" lg="7">
                        <v-radio-group v-model="relation_reason.rel_to_patient" @change="checkDataStatus('other'), relationship = ''" hide-details dense>
                            <v-row wrap>
                                <v-col cols="12" sm="3" md="3" lg="3" class="pb-2">
                                    <v-radio value="Spouse" label="Spouse"></v-radio>
                                </v-col>
                                <v-col cols="12" sm="3" md="3" lg="3" class="pb-2">
                                    <v-radio value="Sibling" label="Sibling"></v-radio>
                                </v-col>
                                <v-col cols="12" sm="2" md="2" lg="2" class="pb-2">
                                    <v-radio value="Child" label="Child"></v-radio>
                                </v-col>
                            </v-row>
                        </v-radio-group>
                        <v-row align="baseline" wrap>
                                <v-col cols="12" sm="3" md="3" lg="3" class="pt-sm-1">
                                    <v-radio-group v-model="relation_reason.rel_to_patient" @change="checkDataStatus('other'), relationship = ''" class="ma-0" hide-details dense>
                                        <v-radio value="Parent" label="Parent"></v-radio>
                                    </v-radio-group>
                                </v-col>
                                <v-col cols="5" sm="3" md="3" lg="3" class="py-1">
                                    <v-radio-group v-model="relationship" @change="relation_reason.rel_to_patient = ''" class="ma-0" hide-details dense>
                                        <v-radio value="Others" label="Others, Specify"></v-radio>
                                    </v-radio-group>
                                </v-col>
                                <v-col :class="{'opacity' : relationship !== 'Others'}" cols="7" sm="3" md="3" lg="3">
                                    <v-text-field v-if="relationship === 'Others'" v-model="relation_reason.rel_to_patient" @change="checkDataStatus('other')" class="ma-0 body-2" dense hide-details></v-text-field>
                                    <v-text-field v-else readonly class="ma-0 body-2" dense hide-details></v-text-field>
                                </v-col>
                        </v-row>
                </v-col>
            </v-row>

            <v-row wrap>
                <v-col cols="5" sm="5" md="5" lg="5" class="pt-4">
                    <label>
                        Reason for signing on behalf of the member/patient:
                        <v-btn v-show="trans_detail.editable" v-if="!!relation_reason.reason_for_signing_onbehalf || reason_for_signing" @click="relation_reason.reason_for_signing_onbehalf = '', reason_for_signing = '', checkDataStatus('other')" width="60" height="25" small>Clear</v-btn>
                    </label>
                </v-col>
                <v-col cols="12" sm="12" md="7" lg="7">
                    <v-radio-group v-model="relation_reason.reason_for_signing_onbehalf" @change="checkDataStatus('other'), reason_for_signing = ''" hide-details dense>
                        <v-row wrap>
                            <v-col cols="12" sm="4" md="4" lg="4" class="pb-2">   
                                <v-radio value="Incapacitated" label="Patient is incapacitated"></v-radio>
                            </v-col>
                            <v-col cols="12" sm="4" md="3" lg="3">
                                <v-radio value="Representative" label="Representative"></v-radio>
                            </v-col>
                        </v-row>
                    </v-radio-group>
                    <v-row align="baseline" wrap>
                        <v-col cols="12" sm="4" md="4" lg="4" class="pt-1">
                            <v-radio-group v-model="relation_reason.reason_for_signing_onbehalf" @change="checkDataStatus('other'), reason_for_signing = ''" class="ma-0" hide-details dense>
                                <v-radio value="Patient" label="Patient"></v-radio>
                            </v-radio-group>
                        </v-col>
                        <v-col cols="5" sm="3" md="3" lg="3" class="py-1">
                            <v-radio-group v-model="reason_for_signing" @change="relation_reason.reason_for_signing_onbehalf = ''" class="ma-0" hide-details dense>
                                <v-radio value="Others" label="Other Reason"></v-radio>
                            </v-radio-group>
                        </v-col>
                        <v-col :class="{'opacity' : reason_for_signing !== 'Others'}" cols="7" sm="3" md="3" lg="3">
                            <v-text-field v-if="reason_for_signing === 'Others'" v-model="relation_reason.reason_for_signing_onbehalf" @change="checkDataStatus('other')" class="ma-0 body-2" hide-details dense></v-text-field>
                            <v-text-field v-else readonly class="ma-0 body-2" hide-details dense></v-text-field>
                        </v-col>
                    </v-row>
                </v-col>
            </v-row>

            <!-- CERTIFICATION OF HEALTH CARE INSTITUTION -->
            <v-row class="mt-3" wrap>
                <h1 class="subtitle-1 grey--text text--darken-3 font-weight-medium">CERTIFICATION OF HEALTH CARE INSTITUTION</h1>
                <v-spacer></v-spacer>
                <v-btn v-if="trans_detail.crd_claims_status === 'Screening Rejected' && !!comment_data.cf2_part4" @click="displayCommentData('hci')" class="ml-2" color="primary" tile depressed small>CHECK COMMENTS 
                    <v-badge content="!" color="red">
                        <v-icon class="pl-1" small>mdi-comment</v-icon>
                    </v-badge>
                </v-btn>
            </v-row>
            <v-divider class="mb-4"></v-divider>
            
            <!-- FILE ATTACHMENT FOR ADDITIONAL ATTACHMENTS -->
            <label>Attach additional documents (SOA , MDR etc.):</label>
            <v-row justify="center" class="mt-4 pb-2" wrap>
                <v-col cols="12" sm="6" md="4" lg="4" class="pr-1">
                    <label for="attached-certification" class="file-attachment">Choose File</label> 
                    <span class="ml-1" v-if="cert_data.section3.length === 0">No file chosen</span>
                    <span class="ml-1" v-else>{{ cert_data.section3.length }} files</span>
                    <input :disabled="!trans_detail.editable || new_additional_status === 'Processing'" @change="addAttachedAdditional" id="attached-certification" class="mt-4 d-none" type="file" ref="additional" accept=".pdf" multiple><br>
                    <v-divider class="mt-3"></v-divider>

                    <div v-for="(attached, i) in cert_data.section3" :key="i" class="text-left">
                        <h5 class="font-weight-medium grey lighten-3 text-left pl-2 py-1 mt-2">
                            <v-icon color="success" size="20">mdi-check</v-icon>
                            {{ attached.name }} 
                            <v-icon v-show="attached.loader === false || attached.loader === undefined" :disabled="!trans_detail.editable || new_additional_status === 'Processing'" @click="removeAttachedAdditional(i, 'old')" class="remove-attachment" size="20">mdi-close</v-icon>
                            <label v-show="attached.loader" class="remove-attachment font-italic">Deleting...</label>
                        </h5>
                    </div>

                    <div v-for="(view, i) in view_attached_additional" :key="'view'+i" class="text-left">
                        <h5 class="font-weight-medium grey lighten-3 text-left pl-2 py-1 mt-2">
                            <template v-if="view.file_size > 30">
                                <v-tooltip bottom color="red">
                                    <template #activator="{ on }">
                                        <v-icon v-on="on" class="pr-1" color="red" size="20">mdi-alert-circle-outline</v-icon>
                                    </template>
                                    File size exceeds 30 MB
                                </v-tooltip>
                            </template>
                            <template v-else>
                                <v-progress-circular v-if="new_additional_status === true || new_additional_status === 'Processing'" class="mr-2" color="red" size="13" width="1.4" :indeterminate="new_additional_status === 'Processing'"></v-progress-circular>
                                <v-icon v-else color="success" size="20">mdi-check</v-icon>
                            </template>
                            {{ view.name }} <span class="text--secondary">- {{ view.file_size }} MB</span>
                            <v-icon v-show="new_additional_status !== 'Processing'" @click="removeAttachedAdditional(i, 'new')" class="remove-attachment" size="20">mdi-close</v-icon>
                        </h5>
                    </div>

                    <div class="text-center">
                        <v-btn :disabled="!trans_detail.editable || file_size_exceeds" :loading="loading_additional_attachment" @click="postFileOfAdditional" class="mt-4" small tile>UPLOAD FILE</v-btn>
                        <v-btn v-if="cert_data.section3.length > 0 || view_attached_additional.length > 0" @click="view_file_additional = true" class="mt-4 ml-2" small tile>VIEW FILE</v-btn>
                        <span class="d-block mt-3">Maximum upload size: 30 MB.</span>
                    </div>
                </v-col>
                <v-col cols="1" sm="1" md="1" lg="1"></v-col>
            </v-row>

            <v-row v-show="loading_additional_attachment" justify-center text-center wrap mt-2>
                <v-col cols="12" sm="6" md="4" lg="4">
                    <div class="yellow lighten-3 pa-5">
                        <h5 class="font-weight-regular grey--text text--darken-3">Please wait while we upload your file. <br>Do not click next or other category to finish uploading.</h5>
                    </div>
                </v-col>
                <v-col cols="1" sm="1" md="1" lg="1"></v-col>
            </v-row>

            <v-divider class="mt-7 mb-3"></v-divider>
            <p class="font-italic body-1">I certify that service rendered in the patient's chart and health are institution records and that the herein information given are true and correct.</p>
            
            <v-row justify="center" align="center">
                <v-col cols="12" sm="12" md="4" lg="4"  class="text-center">
                    <div class="mb-4">
                        <img v-if="trans_detail.hci_sign_path" :src="trans_detail.hci_sign_path" alt="Signature" width="150" height="auto" />
                    </div>
                    <div class="mt-1 pt-1">
                        <strong>{{ this.hci_name }}</strong>
                    </div>
                    <div class="mt-1 pt-1">
                        <label class="body-2 border-top">Signature Over Printed name of Authorized HCI Representative</label>
                    </div>
                </v-col>

                <v-col cols="6" sm="6" md="3" lg="3"  class="text-center">
                    <v-spacer v-if="trans_detail.hci_sign_path" class="mt-10 pt-10"></v-spacer>
                    <v-spacer v-else></v-spacer>
                    <div class="mt-6 mb-2">
                        <strong>{{ signatures.hospital ? '.' : '' }}</strong>
                    </div>
                    <div class="border-top mt-1 pt-1"></div>
                    
                    <label class="body-2">Official Capacity/Designation</label>
                </v-col>

                <v-col cols="6" sm="6" md="3" lg="3"  class="text-center">
                    <v-spacer v-if="trans_detail.hci_sign_path" class="mt-10 pt-10"></v-spacer>
                    <v-spacer v-else></v-spacer>
                    <div class="mt-6 mb-2">
                        <strong>{{ signatures.hospital }}</strong>
                    </div>
                    <div class="border-top mt-1 pt-1"></div>
                    
                    <label class="body-2">Date Signed</label>
                </v-col>
            </v-row>

            <!-- CERTIFICATION OF ATTENDING PHYSICIAN/MIDWIFE -->
            <v-row class="mt-5 mb-1" wrap>
                <h1 class="subtitle-1 grey--text text--darken-3 font-weight-medium">CERTIFICATION OF ATTENDING PHYSICIAN/MIDWIFE</h1>
                <v-spacer></v-spacer>
                <v-btn v-if="trans_detail.crd_claims_status === 'Screening Rejected' && !!comment_data.cf3_part2_number19" @click="displayCommentData('certification')" class="ml-2" color="primary" tile depressed small>CHECK COMMENTS 
                <v-badge content="!" color="red">
                    <v-icon class="pl-1" small>mdi-comment</v-icon>
                </v-badge>
                </v-btn>
            </v-row>
            <v-divider></v-divider>
            <p class="font-italic body-1 mt-2">I certify that the above information given in this form are true and correct.</p>

            <v-row justify="center" align="center">
                <v-col cols="12" md="6" class="text-center">
                    <div class="mb-4">
                        <img v-if="trans_detail.doctor_sign_path" :src="trans_detail.doctor_sign_path" alt="Signature" width="150" height="auto" />
                    </div>
                    <div class="mt-1 pt-1">
                        <strong>{{ this.doctor_name }}</strong>
                    </div>
                    <div class="mt-1 pt-1">
                        <label class="body-2 border-top">Signature over printed Name of Attending Physician</label>
                    </div>
                </v-col>

                <v-col cols="12" md="4" class="text-center">
                    <v-spacer v-if="trans_detail.doctor_sign_path" class="mt-10 pt-10"></v-spacer>
                    <v-spacer v-else></v-spacer>
                    <div class="mt-6 mb-2">
                        <strong>{{ signatures.doctor }}</strong>
                    </div>
                    <div class="border-top mt-1 pt-1"></div>
                    
                    <label class="body-2">Date Signed</label>
                </v-col>
            </v-row>

            <!-- VIEW FILE DIALOG FOR ADDITIONAL -->
            <v-dialog v-model="view_file_additional" width="1100" persistent>
                <v-card>
                    <v-card-title class="light-blue darken-3 white--text py-2 justify-center">
                        <v-spacer></v-spacer>CERTIFICATION {{ $vuetify.breakpoint.smAndUp ? 'ATTACHMENT' : '' }}<v-spacer></v-spacer>
                        <v-btn @click="view_file_additional = false" dark icon>
                            <v-icon>mdi-close</v-icon>
                        </v-btn>
                    </v-card-title>
                    <v-divider></v-divider>

                    <div v-for="(attached, i) in cert_data.section3" :key="i" class="px-4 mt-2">
                        <h4>{{ i+1 }}) {{ attached.name }}</h4>
                        <embed :src="attached.file_path+'#toolbar=0&view=FitH'" width="100%" height="600px" />
                        <v-divider class="mt-4"></v-divider>
                    </div>

                    <div v-for="(view, i) in view_attached_additional" :key="'view'+i" class="px-4 mt-2">
                        <h4>{{ i+cert_data.section3.length+1 }}) {{ view.name }}</h4>
                        <embed :src="view.file_path+'#toolbar=0&view=FitH'" width="100%" height="600px" />
                        <v-divider class="mt-4"></v-divider>
                    </div>

                    <v-row justify="center" class="mt-3 pb-3" wrap>
                        <v-btn @click="view_file_additional = false" class="ml-1" color="primary">CLOSE</v-btn>
                    </v-row>
                </v-card>
            </v-dialog>

            <!-- COMMENT DIALOG -->
            <v-dialog v-model="comment_dialog" width="600" persistent>
                <v-card>
                    <h3 class="grey--text text--darken-3 font-weight-medium py-1 text-center">{{ comment_title }}</h3>
                    <v-divider></v-divider>
                    <div class="px-4 mt-2">
                        <label class="body-2">Comment:</label>
                        <v-textarea v-model="comment_content" rows="4" outlined readonly hide-details></v-textarea>
                    </div>
                    <v-row justify="center" class="mt-3 pb-3" wrap>
                        <v-btn @click="comment_dialog = false" class="ml-1" color="primary" small>CLOSE</v-btn>
                    </v-row>
                </v-card>
            </v-dialog>

            <!-- NAVIGATION BUTTON -->
            <v-divider class="my-5"></v-divider>
            <v-row justify="space-between" wrap>
                <v-col cols="5" sm="5" md="5" lg="5">
                    <v-btn @click="$router.push('/input-forms/accreditation-and-signature')" color="primary"><i class="fas fa-arrow-left mr-1"></i>PREVIOUS</v-btn> 
                </v-col>
                <v-col cols="5" sm="5" md="5" lg="5" class="text-right">
                    <div v-if="!trans_detail.editable">
                        <v-btn @click="$router.push('/patient-list')" color="primary"><i class="fas fa-home mr-1"></i>BACK TO HOME</v-btn>
                    </div>
                </v-col>
            </v-row>
            
            <Alert :alert="alert" />
        </v-form>
    </div>
</template>

<script>
import Alert from '../../Alert.vue'

export default {
    props: ['trans_detail', 'comment_data'],

    components: {
        Alert
    },

    created(){
        this.getCertificationData();
    },

    data(){
        return{
            ctf_data: {
                phic_ben_is_enough: '',
                total_health_inst_fees: '',
                total_professional_fees: '',
                grand_total: '',

                co_hcf_total_actual_charges: '',
                co_hcf_phic_benefit: '',
                co_hcf_amt_after_dsct: '',
                co_hcf_amt_after_phic_deduc: '',
                co_hcf_paid_by: '',

                co_pf_total_actual_charges: '',
                co_pf_phic_benefit: '',
                co_pf_amt_after_dsct: '',
                co_pf_amt_after_phic_deduc: '',
                co_pf_paid_by: '',
                
                nco_total_cost_med_sup: '',
                nco_total_cost_diagnostic_laboratory: '',

                status: {
                    certification: false,
                    co_hcf_paid_by: false,
                    co_pf_paid_by: false
                }
            },

            // DATA
            cert_data: {
                total_cpt_amount: '',

                section2: {
                    rel_to_patient: '',
                    reason_for_signing_onbehalf: ''
                },
                
                section3: []
            },

            relation_reason: {
                rel_to_patient: '',
                reason_for_signing_onbehalf: '',
                status: false
            },

            signatures: {
                doctor: '',
                patient: '',
                hospital: ''
            },

            // OTHERS
            total_actual_charges_tooltip: false,
            total_purchase_amount: '',
            total_diagnostic_amount: '',
            selected_hif_paid_by: [],
            selected_pf_paid_by: [],
            relationship: '',
            reason_for_signing: '',
            alert: {},

            // ATTACHMENTS
            new_additional_status: true,
            view_attached_additional: [],
            post_attached_additional: [],
            view_file_additional: false,
            loading_additional_attachment: false,
            file_size_exceeds: false,

            // COMMENTS
            comment_dialog: false,
            comment_title: '',
            comment_content: '',

            // SIGANTURE NAMES
            doctor_name:'',
            patient_name:'',
            hci_name:''
        }
    },

    computed: {        
        hif_amount_deduct(){
            return this.ctf_data.co_hcf_amt_after_phic_deduc
        },

        pf_amount_deduct(){
            return this.ctf_data.co_pf_amt_after_phic_deduc
        }
    },

    watch: {
        // PREVENT NAVIGATE IF THERE IS UNSAVED ATTACHMENT
        view_attached_additional(value){
            let total = 0

            value.forEach(element => {
                total += parseFloat(element.file_size)
            })

            if(total > 30){
                this.file_size_exceeds = true
            }else{
                this.file_size_exceeds = false
            }
            
            if(value.length > 0){
                this.unsaved_attachment = 'unsaved_attachment'
            }else{
                this.unsaved_attachment = ''
            }
        },
        
        hif_amount_deduct(value){
            if(value === 'NaN'){
                this.ctf_data.co_hcf_amt_after_phic_deduc = '0.00'
            }
        },

        pf_amount_deduct(value){
            if(value === 'NaN'){
                this.ctf_data.co_pf_amt_after_phic_deduc = '0.00'
            }
        }
    },

    methods: {
        // GET CERTFICATION DATA
        // getCertificationData(){
        //     setTimeout(() => {
        //         let total_fees = sessionStorage.getItem('49SFL4') ? this.$crypto.AES.decrypt(sessionStorage.getItem('49SFL4'), 'FoelR42s').toString(this.$crypto.enc.Utf8) : null
        //         this.total_fees = JSON.parse(total_fees)
        //         this.ctf_data = JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('rtYIWs4'), 'pfdFxg44').toString(this.$crypto.enc.Utf8))

        //         this.ctf_data.phic_ben_is_enough = this.ctf_data.phic_ben_is_enough ? this.ctf_data.phic_ben_is_enough : null
        //         this.ctf_data.total_health_inst_fees = this.checkFormat(this.total_fees ? this.total_fees.hci_fee : (this.ctf_data.total_health_inst_fees ? this.ctf_data.total_health_inst_fees : '0'))
        //         this.ctf_data.total_professional_fees = this.checkFormat(this.total_fees ? this.total_fees.pf_fee : (this.ctf_data.total_professional_fees ? this.ctf_data.total_professional_fees : '0'))
        //         this.ctf_data.grand_total = this.checkFormat(this.total_fees ? this.total_fees.grand_total : (this.ctf_data.grand_total ? this.ctf_data.grand_total : '0'))

        //         this.ctf_data.co_hcf_total_actual_charges = this.checkFormat(this.ctf_data.co_hcf_total_actual_charges)
        //         this.ctf_data.co_hcf_phic_benefit = this.checkFormat(this.total_fees ? this.total_fees.hci_fee : (this.ctf_data.co_hcf_phic_benefit ? this.ctf_data.co_hcf_phic_benefit : '0'))
        //         this.ctf_data.co_hcf_amt_after_dsct = this.checkFormat(this.ctf_data.co_hcf_amt_after_dsct)
        //         this.ctf_data.co_hcf_amt_after_phic_deduc = this.checkFormat(this.ctf_data.co_hcf_amt_after_phic_deduc)
        //         this.ctf_data.co_hcf_paid_by = this.ctf_data.co_hcf_paid_by.length === 0 ? [] : this.ctf_data.co_hcf_paid_by

        //         this.ctf_data.co_pf_total_actual_charges = this.checkFormat(this.ctf_data.co_pf_total_actual_charges)
        //         this.ctf_data.co_pf_phic_benefit = this.checkFormat(this.total_fees ? this.total_fees.pf_fee : (this.ctf_data.co_pf_phic_benefit ? this.ctf_data.co_pf_phic_benefit : '0'))
        //         this.ctf_data.co_pf_amt_after_dsct = this.checkFormat(this.ctf_data.co_pf_amt_after_dsct)
        //         this.ctf_data.co_pf_amt_after_phic_deduc = this.checkFormat(this.ctf_data.co_pf_amt_after_phic_deduc)
        //         this.ctf_data.co_pf_paid_by = this.ctf_data.co_pf_paid_by.length === 0 ? [] : this.ctf_data.co_pf_paid_by
                
        //         this.ctf_data.nco_total_cost_med_sup = this.ctf_data.nco_total_cost_med_sup === 'None' ? this.ctf_data.nco_total_cost_med_sup : this.checkFormat(this.ctf_data.nco_total_cost_med_sup)
        //         this.ctf_data.nco_total_cost_diagnostic_laboratory = this.ctf_data.nco_total_cost_diagnostic_laboratory === 'None' ? this.ctf_data.nco_total_cost_diagnostic_laboratory : this.checkFormat(this.ctf_data.nco_total_cost_diagnostic_laboratory)
                
        //         if(this.total_fees !== null){
        //             this.ctf_data.total_health_inst_fees = this.checkFormat(this.total_fees.hci_fee)
        //             this.ctf_data.total_professional_fees = this.checkFormat(this.total_fees.pf_fee)
        //             this.ctf_data.grand_total = this.checkFormat(this.total_fees.grand_total)

        //             this.ctf_data.co_hcf_phic_benefit = this.checkFormat(this.total_fees.hci_fee)
        //             this.ctf_data.co_pf_phic_benefit = this.checkFormat(this.total_fees.pf_fee)
        //         } 
                
        //         this.ctf_data.co_hcf_paid_by.forEach(element => {
        //             this.selected_hif_paid_by.push(element.co_hcf_paid_by)
        //         })

        //         this.ctf_data.co_pf_paid_by.forEach(element => {
        //             this.selected_pf_paid_by.push(element.co_pf_paid_by)
        //         })

        //         if(this.ctf_data.nco_total_cost_med_sup === 'None' || !this.ctf_data.nco_total_cost_med_sup){
        //             this.total_purchase_amount = ''
        //         }else{
        //             this.total_purchase_amount = 'Total'
        //         }

        //         if(this.ctf_data.nco_total_cost_diagnostic_laboratory === 'None' || !this.ctf_data.nco_total_cost_diagnostic_laboratory){
        //             this.total_diagnostic_amount = ''
        //         }else{
        //             this.total_diagnostic_amount = 'Total'
        //         }
                

        //         let cert_data = sessionStorage.getItem('CLD5Y8') ? this.$crypto.AES.decrypt(sessionStorage.getItem('CLD5Y8'), 'GOre24x5').toString(this.$crypto.enc.Utf8) : null
        //         let relation_reason = sessionStorage.getItem('PDFG5F') ? JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('PDFG5F'), 'XCdx3F9D').toString(this.$crypto.enc.Utf8)) : null
        //         let signatures = sessionStorage.getItem('LMNSP2') ? JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('LMNSP2'), 'MndeXf9d').toString(this.$crypto.enc.Utf8)) : null
                
        //         if(cert_data === null){
        //             this.$axios.post(this.$tms_url+'resources/api/_get_transaction_ip_ctf.php', this.$qs.stringify({
        //                 post_data: this.wsDataEncryption(JSON.stringify({
        //                     phic_tracking_number: this.trans_detail.phic_tracking_number,
        //                     transaction_number: this.trans_detail.transaction_number,
        //                     transaction_type: this.trans_detail.transaction_type
        //                 }))
        //             }))
        //             .then(response => {
        //                 response.data = this.responseDataDecryption(response.data)
        //                 this.cert_data.total_cpt_amount = this.checkFormat(this.total_fees ? this.total_fees.total_cpt_amount : response.data.TOTAL_CPT_AMOUNT)

        //                 this.cert_data.section3 = response.data.ATTACHMENT ? response.data.ATTACHMENT : []
                            
        //                 this.relation_reason = {
        //                     rel_to_patient: relation_reason ? relation_reason.rel_to_patient : response.data.PATIENT_DATA.rel_to_patient,
        //                     reason_for_signing_onbehalf: relation_reason ? relation_reason.reason_for_signing_onbehalf : response.data.PATIENT_DATA.rel_for_signing_on_behalf,
        //                     status: relation_reason ? relation_reason.status : false
        //                 }

        //                 if(signatures){
        //                     this.signatures = signatures
        //                 }else{
        //                     this.signatures = {
        //                         doctor: response.data.SIGNATURE.doctor_date_signed ? this.formatDate(response.data.SIGNATURE.doctor_date_signed.substring(0, 10)) : '',
        //                         hospital: response.data.SIGNATURE.hospital_date_signed ? this.formatDate(response.data.SIGNATURE.hospital_date_signed.substring(0, 10)) : '',
        //                         patient: response.data.SIGNATURE.patient_date_signed ? this.formatDate(response.data.SIGNATURE.patient_date_signed.substring(0, 10)) : ''
        //                     }
        //                 }

        //                 if(this.cert_data.section3.length !== 0){
        //                     this.cert_data.section3.forEach(element => {
        //                         let no_of_file = element.file_name.split('_')[0]
        //                         let provider = this.$store.state.prv_data.provider_tin ? this.$store.state.prv_data.provider_tin : this.$store.state.prv_data.provider_code
        //                         let sum = no_of_file.length + 8 + provider.length + this.trans_detail.transaction_number.length + 4

        //                         element.name = element.file_name.substring(sum)
        //                         element.loader = false
        //                     })
        //                 }

        //                 if(this.relation_reason.rel_to_patient === 'Spouse' || this.relation_reason.rel_to_patient === 'Sibling' || this.relation_reason.rel_to_patient === 'Child' || this.relation_reason.rel_to_patient === 'Parent' || !this.relation_reason.rel_to_patient){
        //                     this.relationship = ''
        //                 }else{
        //                     this.relationship = 'Others'
        //                 }
                        
        //                 if(this.relation_reason.reason_for_signing_onbehalf === 'Incapacitated' || this.relation_reason.reason_for_signing_onbehalf === 'Representative' || this.relation_reason.reason_for_signing_onbehalf === 'Patient' || !this.relation_reason.reason_for_signing_onbehalf){
        //                     this.reason_for_signing = ''
        //                 }else{
        //                     this.reason_for_signing = 'Others'
        //                 }

        //                 sessionStorage.setItem('LMNSP2', this.$crypto.AES.encrypt(JSON.stringify(this.signatures), 'MndeXf9d'))
        //                 this.saveData();
        //                 this.$store.commit('set_loading_category', false)
        //             })
        //             .catch(error => {
        //                 this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
        //             })
        //         }else{
        //             this.cert_data = JSON.parse(cert_data)
        //             this.relation_reason = relation_reason
        //             this.signatures = signatures
                    
        //             if(this.total_fees){
        //                 this.cert_data.total_cpt_amount = this.checkFormat(this.total_fees.total_cpt_amount)
        //             }

        //             if(this.relation_reason.rel_to_patient === 'Spouse' || this.relation_reason.rel_to_patient === 'Sibling' || this.relation_reason.rel_to_patient === 'Child' || this.relation_reason.rel_to_patient === 'Parent' || this.relation_reason.rel_to_patient === '' || this.relation_reason.rel_to_patient === null){
        //                 this.relationship = ''
        //             }else{
        //                 this.relationship = 'Others'
        //             }

        //             if(this.relation_reason.reason_for_signing_onbehalf === 'Incapacitated' || this.relation_reason.reason_for_signing_onbehalf === 'Representative' || this.relation_reason.reason_for_signing_onbehalf === 'Patient' || this.relation_reason.reason_for_signing_onbehalf === '' || this.relation_reason.reason_for_signing_onbehalf === null){
        //                 this.reason_for_signing = ''
        //             }else{
        //                 this.reason_for_signing = 'Others'
        //             }
                    
        //             this.$store.commit('set_loading_category', false)
        //         }
        //      }, 200)
        // },

        getCertificationData(){
            let patient_data = this.getDataInStorage('ET534D', 'fgXSd45d');
            let ass = this.getDataInStorage('GLORS6', 'dspof43S') 
            this.doctor_name = ass.section1[0].doc_fullname
            this.patient_name = patient_data.pat_fname + ' ' + patient_data.pat_mname + ' ' + patient_data.pat_lname
            this.hci_name = patient_data.hci_name
            setTimeout(async () => {
                let total_fees = sessionStorage.getItem('49SFL4') ? this.$crypto.AES.decrypt(sessionStorage.getItem('49SFL4'), 'FoelR42s').toString(this.$crypto.enc.Utf8) : null
                this.total_fees = JSON.parse(total_fees)
                this.ctf_data = JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('rtYIWs4'), 'pfdFxg44').toString(this.$crypto.enc.Utf8))
                // this.ctf_data.phic_ben_is_enough = this.ctf_data.phic_ben_is_enough ? this.ctf_data.phic_ben_is_enough : null
                this.ctf_data.phic_ben_is_enough = '1'
                this.ctf_data.total_health_inst_fees = this.checkFormat(this.total_fees ? this.total_fees.hci_fee : (this.ctf_data.total_health_inst_fees ? this.ctf_data.total_health_inst_fees : '0'))
                this.ctf_data.total_professional_fees = this.checkFormat(this.total_fees ? this.total_fees.pf_fee : (this.ctf_data.total_professional_fees ? this.ctf_data.total_professional_fees : '0'))
                this.ctf_data.grand_total = this.checkFormat(this.total_fees ? this.total_fees.grand_total : (this.ctf_data.grand_total ? this.ctf_data.grand_total : '0'))

                this.ctf_data.co_hcf_total_actual_charges = this.checkFormat(this.ctf_data.co_hcf_total_actual_charges)
                this.ctf_data.co_hcf_phic_benefit = this.checkFormat(this.total_fees ? this.total_fees.hci_fee : (this.ctf_data.co_hcf_phic_benefit ? this.ctf_data.co_hcf_phic_benefit : '0'))
                this.ctf_data.co_hcf_amt_after_dsct = this.checkFormat(this.ctf_data.co_hcf_amt_after_dsct)
                this.ctf_data.co_hcf_amt_after_phic_deduc = this.checkFormat(this.ctf_data.co_hcf_amt_after_phic_deduc)
                this.ctf_data.co_hcf_paid_by = this.ctf_data.co_hcf_paid_by.length === 0 ? [] : this.ctf_data.co_hcf_paid_by

                this.ctf_data.co_pf_total_actual_charges = this.checkFormat(this.ctf_data.co_pf_total_actual_charges)
                this.ctf_data.co_pf_phic_benefit = this.checkFormat(this.total_fees ? this.total_fees.pf_fee : (this.ctf_data.co_pf_phic_benefit ? this.ctf_data.co_pf_phic_benefit : '0'))
                this.ctf_data.co_pf_amt_after_dsct = this.checkFormat(this.ctf_data.co_pf_amt_after_dsct)
                this.ctf_data.co_pf_amt_after_phic_deduc = this.checkFormat(this.ctf_data.co_pf_amt_after_phic_deduc)
                this.ctf_data.co_pf_paid_by = this.ctf_data.co_pf_paid_by.length === 0 ? [] : this.ctf_data.co_pf_paid_by
                
                this.ctf_data.nco_total_cost_med_sup = this.ctf_data.nco_total_cost_med_sup === 'None' ? this.ctf_data.nco_total_cost_med_sup : this.checkFormat(this.ctf_data.nco_total_cost_med_sup)
                this.ctf_data.nco_total_cost_diagnostic_laboratory = this.ctf_data.nco_total_cost_diagnostic_laboratory === 'None' ? this.ctf_data.nco_total_cost_diagnostic_laboratory : this.checkFormat(this.ctf_data.nco_total_cost_diagnostic_laboratory)

                if(this.total_fees !== null){
                    this.ctf_data.total_health_inst_fees = this.checkFormat(this.total_fees.hci_fee)
                    this.ctf_data.total_professional_fees = this.checkFormat(this.total_fees.pf_fee)
                    this.ctf_data.grand_total = this.checkFormat(this.total_fees.grand_total)

                    this.ctf_data.co_hcf_phic_benefit = this.checkFormat(this.total_fees.hci_fee)
                    this.ctf_data.co_pf_phic_benefit = this.checkFormat(this.total_fees.pf_fee)
                } 
                
                this.ctf_data.co_hcf_paid_by.forEach(element => {
                    this.selected_hif_paid_by.push(element.co_hcf_paid_by)
                })

                this.ctf_data.co_pf_paid_by.forEach(element => {
                    this.selected_pf_paid_by.push(element.co_pf_paid_by)
                })

                if(this.ctf_data.nco_total_cost_med_sup === 'None' || !this.ctf_data.nco_total_cost_med_sup){
                    this.total_purchase_amount = ''
                }else{
                    this.total_purchase_amount = 'Total'
                }

                if(this.ctf_data.nco_total_cost_diagnostic_laboratory === 'None' || !this.ctf_data.nco_total_cost_diagnostic_laboratory){
                    this.total_diagnostic_amount = ''
                }else{
                    this.total_diagnostic_amount = 'Total'
                }
                

                let cert_data = sessionStorage.getItem('CLD5Y8') ? this.$crypto.AES.decrypt(sessionStorage.getItem('CLD5Y8'), 'GOre24x5').toString(this.$crypto.enc.Utf8) : null
                let relation_reason = sessionStorage.getItem('PDFG5F') ? JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('PDFG5F'), 'XCdx3F9D').toString(this.$crypto.enc.Utf8)) : null
                let signatures = sessionStorage.getItem('LMNSP2') ? JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('LMNSP2'), 'MndeXf9d').toString(this.$crypto.enc.Utf8)) : null
                
                if(cert_data === null){
                    let response = await this.$services.getEclaims({
                        request_key: 'certification',
                        provider_code: this.$store.state.prv_data.provider_code,
                        ek_lgu_id: this.trans_detail.ek_lgu_id,
                        transaction_number: this.trans_detail.transaction_number,
                        migrated_to_eclaim_table: this.trans_detail.migrated_to_eclaim_table,
                        claim_no: this.trans_detail.claim_no
                    });

                    if (response.status === 200) {
                        response.data = this.responseDataDecryption(response.data)
                        this.cert_data.total_cpt_amount = this.checkFormat(this.total_fees ? this.total_fees.total_cpt_amount : response.data.TOTAL_CPT_AMOUNT)

                        this.cert_data.section3 = response.data.ATTACHMENT ? response.data.ATTACHMENT : []
                            
                        this.relation_reason = {
                            rel_to_patient: relation_reason ? relation_reason.rel_to_patient : response.data.PATIENT_DATA.rel_to_patient,
                            reason_for_signing_onbehalf: relation_reason ? relation_reason.reason_for_signing_onbehalf : response.data.PATIENT_DATA.rel_for_signing_on_behalf,
                            status: relation_reason ? relation_reason.status : false
                        }

                        if(signatures){
                            this.signatures = signatures
                        }else{
                            this.signatures = {
                                doctor: response.data.SIGNATURE.doctor_date_signed ? this.formatDate(response.data.SIGNATURE.doctor_date_signed.substring(0, 10)) : '',
                                hospital: response.data.SIGNATURE.hospital_date_signed ? this.formatDate(response.data.SIGNATURE.hospital_date_signed.substring(0, 10)) : '',
                                patient: response.data.SIGNATURE.patient_date_signed ? this.formatDate(response.data.SIGNATURE.patient_date_signed.substring(0, 10)) : ''
                            }
                        }

                        if(this.cert_data.section3.length !== 0){
                            this.cert_data.section3.forEach(element => {
                                let no_of_file = element.file_name.split('_')[0]
                                let provider = this.$store.state.prv_data.provider_tin ? this.$store.state.prv_data.provider_tin : this.$store.state.prv_data.provider_code
                                let sum = no_of_file.length + 8 + provider.length + this.trans_detail.transaction_number.length + 4

                                element.name = element.file_name.substring(sum)
                                element.loader = false
                            })
                        }

                        if(this.relation_reason.rel_to_patient === 'Spouse' || this.relation_reason.rel_to_patient === 'Sibling' || this.relation_reason.rel_to_patient === 'Child' || this.relation_reason.rel_to_patient === 'Parent' || !this.relation_reason.rel_to_patient){
                            this.relationship = ''
                        }else{
                            this.relationship = 'Others'
                        }
                        
                        if(this.relation_reason.reason_for_signing_onbehalf === 'Incapacitated' || this.relation_reason.reason_for_signing_onbehalf === 'Representative' || this.relation_reason.reason_for_signing_onbehalf === 'Patient' || !this.relation_reason.reason_for_signing_onbehalf){
                            this.reason_for_signing = ''
                        }else{
                            this.reason_for_signing = 'Others'
                        }

                        sessionStorage.setItem('LMNSP2', this.$crypto.AES.encrypt(JSON.stringify(this.signatures), 'MndeXf9d'))
                        this.saveData();
                        this.$store.commit('set_loading_category', false) 
                    } else {
                        this.alert = response.error;
                    }
                }else{
                    this.cert_data = JSON.parse(cert_data)
                    this.relation_reason = relation_reason
                    this.signatures = signatures
                    
                    if(this.total_fees){
                        this.cert_data.total_cpt_amount = this.checkFormat(this.total_fees.total_cpt_amount)
                    }

                    if(this.relation_reason.rel_to_patient === 'Spouse' || this.relation_reason.rel_to_patient === 'Sibling' || this.relation_reason.rel_to_patient === 'Child' || this.relation_reason.rel_to_patient === 'Parent' || this.relation_reason.rel_to_patient === '' || this.relation_reason.rel_to_patient === null){
                        this.relationship = ''
                    }else{
                        this.relationship = 'Others'
                    }

                    if(this.relation_reason.reason_for_signing_onbehalf === 'Incapacitated' || this.relation_reason.reason_for_signing_onbehalf === 'Representative' || this.relation_reason.reason_for_signing_onbehalf === 'Patient' || this.relation_reason.reason_for_signing_onbehalf === '' || this.relation_reason.reason_for_signing_onbehalf === null){
                        this.reason_for_signing = ''
                    }else{
                        this.reason_for_signing = 'Others'
                    }
                    
                    this.$store.commit('set_loading_category', false)
                }
             }, 200)
        },

        // ADD SELECTED HIF_PAID_BY
        addSelectedHIF(value, event){
            if(event.includes(value)){
                this.ctf_data.co_hcf_paid_by.push({
                    co_hcf_paid_by: value
                })
                
                this.selected_hif_paid_by.push(value)
            }else{
                this.ctf_data.co_hcf_paid_by.forEach((element, index) => {
                    if(element.co_hcf_paid_by === value){
                        this.ctf_data.co_hcf_paid_by.splice(index, 1)
                    }
                })

                this.selected_hif_paid_by.forEach((element, index) => {
                    if(element === value){
                        this.selected_hif_paid_by.splice(index, 1)
                    }
                })
            }
            this.checkDataStatus('health');
        },

        // ADD SELECTED PF_PAID_BY
        addSelectedPF(value, event){
            if(event.includes(value)){
                this.ctf_data.co_pf_paid_by.push({
                    co_pf_paid_by: value
                })
                
                this.selected_pf_paid_by.push(value)
            }else{
                this.ctf_data.co_pf_paid_by.forEach((element, index) => {
                    if(element.co_pf_paid_by === value){
                        this.ctf_data.co_pf_paid_by.splice(index, 1)
                    }
                })

                this.selected_pf_paid_by.forEach((element, index) => {
                    if(element === value){
                        this.selected_pf_paid_by.splice(index, 1)
                    }
                })
            }
            this.checkDataStatus('professional');
        },

        // ADD ATTACHED FILE FOR ADDITIONAL
        addAttachedAdditional(){
            let attached_files = []
            let re_attached_files = []
            this.new_additional_status = true

            this.cert_data.section3.forEach(element => {
                attached_files.push(element.name)
            })

            this.view_attached_additional.forEach(element => {
                attached_files.push(element.name)
            })

            Object.values(this.$refs.additional.files).forEach(element => {
                if(attached_files.includes(element.name)){
                    re_attached_files.push('<br>'+element.name)
                }else{    
                    this.post_attached_additional.push(element)
                    this.view_attached_additional.push({
                        name: element.name,
                        file_size: Number(element.size * 0.00000095367432).toFixed(2),
                        file_path: window.URL.createObjectURL(element)
                    })
                }
            })

            if(re_attached_files.length > 0){
                let title = 'This file already exist and cannot be attached again.<b>' + re_attached_files + ' </b>'
                this.alert = { display: true, type: 'standard', width: '500', icon: 'mdi-close-circle', color: 'red', title: title, btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'closeAlert' }
            }
        },

        // REMOVE ATTACHED FILE FOR ADDITIONAL
        removeAttachedAdditional(index, status){
            if(status === 'old'){
                this.cert_data.section3[index].loader = true

                this.$axios.post(this.$tms_url+'resources/controller/trn_del_attachment.php', this.$qs.stringify({
                    post_data: this.wsDataEncryption(JSON.stringify({
                        phic_tracking_number: this.trans_detail.phic_tracking_number,
                        transaction_number: this.trans_detail.transaction_number,
                        attachment_category: 'ADDITIONAL ATTACHMENT',
                        file_name: this.cert_data.section3[index].file_name
                    }))
                }))
                .then(response => {
                    if(response.data.success){
                        this.cert_data.section3.splice(index, 1)
                        this.saveData();
                    }else{
                        this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: 'Something Went Wrong', body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
                    }
                })
                .catch(error => {
                    this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
                })
            }else{
                this.post_attached_additional.splice(index - this.post_attached_additional.length, 1)
                this.view_attached_additional.splice(index - this.view_attached_additional.length, 1)
            }
            document.getElementById("attached-certification").value = "";
        },

        // POST ATTACHED FILE TO SERVER OF ADDITIONAL ATTACHMENT
        // postFileOfAdditional(){
        //     if(this.post_attached_additional.length === 0){
        //         this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-close-circle', color: 'red', title: 'No file chosen. Please attach file', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'closeAlert' }
        //     }else{
        //         this.$store.commit('set_prevent_navigation', false)
        //         this.loading_additional_attachment = true
        //         this.new_additional_status = 'Processing'

        //         let formData = new FormData();
        //         let total_count = this.post_attached_additional.length
        //         for( var i = 0; i < this.post_attached_additional.length; i++ ){
        //             let file = this.post_attached_additional[i];
        //             formData.append('file'+ i +'', file);
        //         }

        //         formData.append('post_data', this.wsDataEncryption(JSON.stringify({
        //             phic_tracking_number: this.trans_detail.phic_tracking_number,
        //             transaction_number: this.trans_detail.transaction_number,
        //             provider_user: this.$store.state.usr_credentials.user_name,
        //             department: this.$store.state.usr_credentials.department,
        //             provider_code: this.$store.state.prv_data.provider_code,
        //             provider_tin: this.$store.state.prv_data.provider_tin,
        //             attachment_category: 'ADDITIONAL ATTACHMENT',
        //             request_key: 'phic_patient_prov_attachments',
        //             total_count: total_count
        //         })))

        //         this.$axios.post(this.$tms_url+'resources/controller/trn_upd_inpatient_ctf.php', 
        //             formData,
        //             {
        //                 headers: {
        //                     'Content-Type': 'multipart/form-data'
        //                 }
        //             }
        //         )
        //         .then(response => {
        //             if(response.data.success){         
        //                 this.responseDataDecryption(response.data.file_path).forEach(element => {
        //                     let no_of_file = element.file_name.split('_')[0]
        //                     let provider = this.$store.state.prv_data.provider_tin ? this.$store.state.prv_data.provider_tin : this.$store.state.prv_data.provider_code
        //                     let sum = no_of_file.length + 8 + provider.length + this.trans_detail.transaction_number.length + 4

        //                     element.name = element.file_name.substring(sum)
        //                     element.loader = false
    
        //                     this.cert_data.section3.push(element)
        //                 })
                        
        //                 this.new_additional_status = false
        //                 this.post_attached_additional = []
        //                 this.view_attached_additional = []
        //                 this.loading_additional_attachment = false
        //                 this.$store.commit('set_prevent_navigation', true)
        //                 this.saveData();
        //             }else{
        //                 this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: 'Something Went Wrong', body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
        //             }
        //         })
        //         .catch(error => {
        //             this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
        //         })
        //     }
        // },

        postFileOfAdditional(){
            if(this.post_attached_additional.length === 0){
                this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-close-circle', color: 'red', title: 'No file chosen. Please attach file', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'closeAlert' }
            }else{
                this.$store.commit('set_prevent_navigation', false)
                this.loading_additional_attachment = true
                this.new_additional_status = 'Processing'

                let formData = new FormData();
                let total_count = this.post_attached_additional.length
                for( var i = 0; i < this.post_attached_additional.length; i++ ){
                    let file = this.post_attached_additional[i];
                    formData.append('file'+ i +'', file);
                }

                formData.append('post_data', this.wsDataEncryption(JSON.stringify({
                    request_key: "additional_attachment",
                    transaction_number: this.trans_detail.transaction_number,
                    created_by: this.$store.state.usr_credentials.user_name,
                    provider_code: this.$store.state.prv_data.provider_code,
                    attachment_category: 'ADDITIONAL ATTACHMENT',
                    total_count: total_count
                })))

                this.$axios.post(this.$tms_url+'resources/controller/trn_add_eclaims_attached_files.php', 
                    formData,
                    {
                        headers: {
                            'Content-Type': 'multipart/form-data'
                        }
                    }
                )
                .then(response => {
                    if(response.data.success){         
                        this.responseDataDecryption(response.data.file_path).forEach(element => {
                            let no_of_file = element.file_name.split('_')[0]
                            let provider = this.$store.state.prv_data.provider_tin ? this.$store.state.prv_data.provider_tin : this.$store.state.prv_data.provider_code
                            let sum = no_of_file.length + 8 + provider.length + this.trans_detail.transaction_number.length + 4

                            element.name = element.file_name.substring(sum)
                            element.loader = false
    
                            this.cert_data.section3.push(element)
                        })
                        
                        this.new_additional_status = false
                        this.post_attached_additional = []
                        this.view_attached_additional = []
                        this.loading_additional_attachment = false
                        this.$store.commit('set_prevent_navigation', true)
                        this.saveData();
                    }else{
                        this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: 'Something Went Wrong', body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
                    }
                })
                .catch(error => {
                    this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
                })
            }
        },

        // AUTO-COMPUTATION
        autoCompute(item){
            let hif_total_charges = parseFloat(this.ctf_data.co_hcf_total_actual_charges.toString().replace(/,/g, ''))
            let hif_amount_discount = parseFloat(this.ctf_data.co_hcf_amt_after_dsct.toString().replace(/,/g, ''))
            let hif_phic_benefit = parseFloat(this.ctf_data.co_hcf_phic_benefit.toString().replace(/,/g, ''))
            let pf_total_charges = parseFloat(this.ctf_data.co_pf_total_actual_charges.toString().replace(/,/g, ''))
            let pf_amount_discount = parseFloat(this.ctf_data.co_pf_amt_after_dsct.toString().replace(/,/g, ''))
            let pf_phic_benefit = parseFloat(this.ctf_data.co_pf_phic_benefit.toString().replace(/,/g, ''))
            let total_cpt_amount = parseFloat(this.cert_data.total_cpt_amount.toString().replace(/,/g, ''))

            if(item === 'hif'){
                let hif_amount_deduct = ''

                if(this.ctf_data.co_hcf_total_actual_charges !== '0.00' && this.ctf_data.co_hcf_amt_after_dsct === '0.00'){
                    this.ctf_data.co_hcf_amt_after_dsct = '0.00'
                    this.ctf_data.co_hcf_total_actual_charges = this.ctf_data.co_hcf_total_actual_charges.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                    hif_amount_deduct = hif_total_charges - hif_phic_benefit

                    if(hif_total_charges < hif_phic_benefit){
                        hif_amount_deduct = '0.00'
                    }
                }else{
                    this.ctf_data.co_hcf_total_actual_charges = '0.00'
                    this.ctf_data.co_hcf_amt_after_dsct = this.ctf_data.co_hcf_amt_after_dsct.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                    hif_amount_deduct = hif_amount_discount - hif_phic_benefit

                    if(hif_amount_discount < hif_phic_benefit){
                        hif_amount_deduct = '0.00'
                    }
                }

                if(hif_amount_deduct < 0){
                    this.ctf_data.co_hcf_amt_after_phic_deduc = '0.00'
                }else{
                    this.ctf_data.co_hcf_amt_after_phic_deduc = Number(hif_amount_deduct).toFixed(2).toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                }
            }else if(item === 'pf'){
                let pf_amount_deduct = ''

                if(this.ctf_data.co_pf_total_actual_charges !== '0.00' && this.ctf_data.co_pf_amt_after_dsct === '0.00'){
                    this.ctf_data.co_pf_amt_after_dsct = '0.00'
                    this.ctf_data.co_pf_total_actual_charges = this.ctf_data.co_pf_total_actual_charges.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                    pf_amount_deduct = pf_total_charges - pf_phic_benefit

                    if(pf_total_charges < pf_phic_benefit){
                        pf_amount_deduct = '0.00'
                    }
                }else{
                    this.ctf_data.co_pf_total_actual_charges = '0.00'
                    this.ctf_data.co_pf_amt_after_dsct = this.ctf_data.co_pf_amt_after_dsct.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                    pf_amount_deduct = pf_amount_discount - pf_phic_benefit

                    if(pf_amount_discount < pf_phic_benefit){
                        pf_amount_deduct = '0.00'
                    }
                }

                if(pf_amount_deduct < 0){
                    this.ctf_data.co_pf_amt_after_phic_deduc = '0.00'
                }else{
                    this.ctf_data.co_pf_amt_after_phic_deduc = Number(pf_amount_deduct).toFixed(2).toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                }
            }else if(item === 'purchase'){
                this.ctf_data.nco_total_cost_med_sup = this.ctf_data.nco_total_cost_med_sup.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
            }else{
                this.ctf_data.nco_total_cost_diagnostic_laboratory = this.ctf_data.nco_total_cost_diagnostic_laboratory.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
            }

            if((hif_total_charges + pf_total_charges) > total_cpt_amount){
                this.total_actual_charges_tooltip = true
                this.exceed_total_charges = 'exceed_total_charges'
            }else if(hif_total_charges > total_cpt_amount || pf_total_charges > total_cpt_amount){
                this.total_actual_charges_tooltip = true
                this.exceed_total_charges = 'exceed_total_charges'
            }else{
                this.total_actual_charges_tooltip = false
                this.exceed_total_charges = ''
            }
            
            this.checkDataStatus('certification');
        },

        // ADD DECIMAL ON BLUR
        addDecimal(item, value){
            if(item === 'hif_charges'){
                this.ctf_data.co_hcf_total_actual_charges = this.checkFormat(value)
            }else if(item === 'hif_discount'){
                this.ctf_data.co_hcf_amt_after_dsct = this.checkFormat(value)
            }else if(item === 'pf_charges'){
                this.ctf_data.co_pf_total_actual_charges = this.checkFormat(value)
            }else if(item === 'pf_discount'){
                this.ctf_data.co_pf_amt_after_dsct = this.checkFormat(value)
            }else if(item === 'purchase'){
                this.ctf_data.nco_total_cost_med_sup = this.checkFormat(value)
            }else if(item === 'diagnostic'){
                this.ctf_data.nco_total_cost_diagnostic_laboratory = this.checkFormat(value)
            }
        },

        // CHECK FORMAT
        checkFormat(value){
            if(value){
                value = parseFloat(value.toString().replace(/,/g, ''))
                value = value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                if(!value.includes('.')) value = value + '.00'
                
                return value
            }else{
                return '0.00'
            }
        },

        // PREVENT USER FROM TYPING LETTERS IN TEXT FIELD
        numberOnly(event, value){
            if (((event.which != 46 || (event.which == 46 && value == '')) || value.indexOf('.') != -1) && (event.which < 48 || event.which > 57)){
                event.preventDefault();
            }
        },

        // DISPLAY COMMENT DATA
        displayCommentData(data){
            if(data === 'consumption'){
                this.comment_title = 'CERTIFICATION OF CONSUMPTION OF BENEFITS'
                this.comment_content = this.comment_data.cf2_part3_lettera
            }else if(data === 'consent'){
                this.comment_title = 'CONSENT TO ACCESS PATIENT RECORD'
                this.comment_content = this.comment_data.cf2_part3_letterb
            }else if(data === 'hci'){
                this.comment_title = 'CERTIFICATION OF HEALTH CARE INSTITUTION'
                this.comment_content = this.comment_data.cf2_part4
            }else{
                this.comment_title = 'CERTIFICATION OF ATTENDING PHYSICIAN/MIDWIFE'
                this.comment_content = this.comment_data.cf3_part2_number19
            }
            
            this.comment_dialog = true
        },

        // CHECK IF DATA HAS BEEN CHANGED
        checkDataStatus(data){
            this.$emit('change-status')

            if(data === 'certification'){
                this.ctf_data.status.certification = true

                if(this.ctf_data.phic_ben_is_enough === null || this.ctf_data.phic_ben_is_enough === '1'){
                    this.ctf_data.co_hcf_amt_after_dsct = '0.00'
                    this.ctf_data.co_hcf_amt_after_phic_deduc = '0.00'
                    this.ctf_data.co_hcf_total_actual_charges = '0.00'
                    if(this.ctf_data.co_hcf_paid_by.length > 0){
                        this.ctf_data.co_hcf_paid_by = []
                        this.selected_hif_paid_by = []
                        this.ctf_data.status.co_hcf_paid_by = true
                    }

                    this.ctf_data.co_pf_amt_after_dsct = '0.00'
                    this.ctf_data.co_pf_amt_after_phic_deduc = '0.00'
                    this.ctf_data.co_pf_total_actual_charges = '0.00' 
                    if(this.ctf_data.co_pf_paid_by.length > 0){
                        this.ctf_data.co_pf_paid_by = []
                        this.selected_pf_paid_by = []
                        this.ctf_data.status.co_pf_paid_by = true
                    }

                    this.total_purchase_amount = 'Total'
                    this.total_diagnostic_amount = 'Total'
                    this.ctf_data.nco_total_cost_diagnostic_laboratory = '0.00'
                    this.ctf_data.nco_total_cost_med_sup = '0.00'
                    this.exceed_total_charges = ''

                    this.ctf_data.total_health_inst_fees = this.checkFormat(this.ctf_data.total_health_inst_fees)
                    this.ctf_data.total_professional_fees = this.checkFormat(this.ctf_data.total_professional_fees)
                    this.ctf_data.grand_total = this.checkFormat(this.ctf_data.grand_total)

                    sessionStorage.setItem('rtYIWs4', this.$crypto.AES.encrypt(JSON.stringify(this.tf_data), 'pfdFxg44'))
                }

                let philhealth_certification = {
                    co_hcf_total_actual_charges: parseFloat(this.ctf_data.co_hcf_total_actual_charges.toString().replace(/,/g, '')),
                    co_pf_total_actual_charges:  parseFloat(this.ctf_data.co_pf_total_actual_charges.toString().replace(/,/g, '')),
                    phic_ben_is_enough: this.ctf_data.phic_ben_is_enough
                }
                
                sessionStorage.setItem('kgdlDt', this.$crypto.AES.encrypt(JSON.stringify(philhealth_certification), 'vcoF535f'))
            }else if(data === 'health'){
                this.ctf_data.status.co_hcf_paid_by = true
            }else if(data === 'professional'){
                this.ctf_data.status.co_pf_paid_by = true
            }else if(data === 'other'){
                this.relation_reason.status = true
            }

            this.$emit('input', [this.unsaved_attachment, this.exceed_total_charges])
            this.saveData();
        },

        // SAVE DATA TO SESSION STORAGE
        saveData(){
            sessionStorage.setItem('rtYIWs4', this.$crypto.AES.encrypt(JSON.stringify(this.ctf_data), 'pfdFxg44'))
            
            sessionStorage.setItem('CLD5Y8', this.$crypto.AES.encrypt(JSON.stringify(this.cert_data), 'GOre24x5'))
            sessionStorage.setItem('PDFG5F', this.$crypto.AES.encrypt(JSON.stringify(this.relation_reason), 'XCdx3F9D'))
        }
    },

    destroyed(){
        this.saveData();
    }
}
</script>

<style scoped>
.border-top{
    border-top: 1px solid grey;
    display: block;
}
.signature-line{
    border-top: 1px solid rgb(0, 0, 0);
}
</style>