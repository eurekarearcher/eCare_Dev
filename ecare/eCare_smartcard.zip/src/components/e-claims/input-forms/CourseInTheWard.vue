<template>
  <div>
    <v-form :readonly="!trans_detail.editable">
      <!-- COURSE IN THE WARD -->
      <v-row wrap>
        <v-col cols="6" sm="6" md="6" lg="6">
          <h1 class="section-title">COURSE IN THE WARD</h1>
        </v-col>
        <v-col cols="6" sm="6" md="6" lg="6" class="text-right">
          <v-btn v-if="trans_detail.crd_claims_status === 'Screening Rejected' && !!comment_data.cf4_part4" @click="displayCommentData('ciw')" color="primary" tile depressed small>CHECK COMMENTS 
            <v-badge content="!" color="red">
              <v-icon class="pl-1" small>mdi-comment</v-icon>
            </v-badge>
          </v-btn>
        </v-col>
      </v-row>
      <v-divider></v-divider>

      <v-row class="d-none d-sm-flex mt-5 text-center" justify="center" wrap>
        <v-col cols="7" sm="8" md="8" lg="8">
          <label class="body-2 font-weight-medium">DOCTOR'S ORDER/ACTION</label>
        </v-col>
        <v-col cols="5" sm="4" md="4" lg="4">
          <label class="body-2 font-weight-medium">DATE</label>
        </v-col>
      </v-row>

      <!-- PROCEDURES -->
      <v-row v-for="(cpt, i) in displayCptProcedures()" :key="'cpt'+i" class="mt-4 mt-sm-n2" dense>
        <v-col class="pl-7 pl-sm-0" cols="12" sm="8" md="8" lg="8">
          <v-text-field v-model="cpt.cpt_description" :label="$vuetify.breakpoint.smAndUp ? '' : 'Doctor\'s Order / Action'" class="body-2 ma-0 pa-0" hide-details readonly dense>
            <template v-slot:prepend>
              <label class="body-2 pt-1 black--text">{{ i+1 }})</label>
            </template>
          </v-text-field>
        </v-col> 
        <v-col class="pl-12 pl-sm-0" cols="12" sm="4" md="4" lg="4">
          <v-text-field v-model="cpt.date" :label="$vuetify.breakpoint.smAndUp ? '' : 'Date'" class="body-2 ma-0 pa-0" hide-details readonly dense>
            <template v-if="trans_detail.editable" v-slot:append-outer>
              <v-icon @click="confirmRemoveProcedure(cpt.icd_index, cpt.icd_description, cpt.cpt_index)" class="pr-1" size="26">mdi-delete</v-icon>
            </template>
          </v-text-field>
        </v-col>
      </v-row>
    
      <!-- DOCTORS ORDER -->
      <v-row v-for="(add, i) in doctors_order.data" :key="i" class="mt-4 mt-sm-n2" dense>
        <v-col class="pl-7 pl-sm-0" cols="12" sm="8" md="8" lg="8">
          <v-text-field v-model="add.doctors_order" :label="$vuetify.breakpoint.smAndUp ? '' : 'Doctor\'s Order / Action'" @change="checkDataStatus('doctors')" class="body-2 ma-0 pa-0" hide-details dense>
            <template v-slot:prepend>
              <label class="body-2 pt-1 black--text">{{ procedures_length+i+1 }})</label>
            </template>
          </v-text-field>
        </v-col> 

        <v-col class="pl-12 pl-sm-0" cols="12" sm="4" md="4" lg="4">
          <v-menu :disabled="!trans_detail.editable" :close-on-content-click="false" transition="scale-transition" max-width="290px" min-width="290px" offset-y>
            <template v-slot:activator="{ on }">
              <v-text-field v-model="add.date" v-on="on" @change="checkDataStatus('doctors')" :label="$vuetify.breakpoint.smAndUp ? '' : 'Date'" class="body-2 ma-0 pa-0" hide-details readonly dense>
                <template v-if="trans_detail.editable" v-slot:append-outer>
                  <v-icon @click="removeAddedDoctorsOrder(i)" class="icon-pl pr-1" size="26">mdi-delete</v-icon>
                </template>
                <template v-if="required && !add.date" v-slot:append>
                  <v-icon class="mt-1" color="red" title="Field is required" small>fas fa-exclamation-circle</v-icon>
                </template>
              </v-text-field>
            </template>
            <v-date-picker v-model="add.date_date" :max="confinement_date.date_discharged" :min="confinement_date.date_admitted" @input="add.date = formatDate(add.date_date)" @change="checkDataStatus('doctors')" no-title></v-date-picker>
          </v-menu>
        </v-col>
      </v-row>

      <v-row class="pr-10 mt-2" wrap>
        <v-spacer></v-spacer>
        <v-btn v-if="trans_detail.editable" @click="addDoctorsOrder" tile><v-icon class="pr-1" small>mdi-plus</v-icon>ADD DOCTORS ORDER</v-btn>
      </v-row>
      
      <!-- SURGICAL PROCEDURES -->
      <v-row class="mt-6" wrap>
        <v-col cols="6" sm="6" md="6" lg="6">
          <h1 class="section-title">SURGICAL PROCEDURE</h1>
        </v-col>
        <v-col cols="6" sm="6" md="6" lg="6" class="text-right">
          <v-btn v-if="trans_detail.crd_claims_status === 'Screening Rejected' && !!comment_data.cf4_part4_1" @click="displayCommentData('surgical')" color="primary" tile depressed small>CHECK COMMENTS 
            <v-badge content="!" color="red">
              <v-icon class="pl-1" small>mdi-comment</v-icon>
            </v-badge>
          </v-btn>
        </v-col>
      </v-row>
      <v-divider></v-divider>
      
      <!-- FILE ATTACHMENT FOR SURGICAL PROCEDURES -->
      <v-row justify="center" class="mt-10" wrap>
        <v-col cols="12" sm="6" md="4" lg="4" class="pr-1">
          <label for="attached-surgical" class="file-attachment">Choose File</label> 
          <span class="ml-1" v-if="ciw_data.section2.length === 0">No file chosen</span>
          <span class="ml-1" v-else>{{ ciw_data.section2.length }} files</span>
          <input :disabled="!trans_detail.editable || new_surgical_status === 'Processing'" @change="addAttachedSurgical" id="attached-surgical" class="mt-4 d-none" type="file" ref="surgical" accept=".pdf" multiple><br>
          <v-divider class="mt-3"></v-divider>

          <div v-for="(attached, i) in ciw_data.section2" :key="i" class="text-left">
            <h5 class="font-weight-medium grey lighten-3 text-left pl-2 py-1 mt-2">
              <v-icon color="success" size="20">mdi-check</v-icon>
              {{ attached.name }} 
              <v-icon v-show="attached.loader === false || attached.loader === undefined" :disabled="!trans_detail.editable || new_surgical_status === 'Processing'" @click="removeAttachedSurgical(i, 'old')" class="remove-attachment" size="20">mdi-close</v-icon>
              <label v-show="attached.loader" class="remove-attachment font-italic">Deleting...</label>
            </h5>
          </div>

          <div v-for="(view, i) in view_attached_surgical" :key="'view'+i" class="text-left">
            <h5 class="font-weight-medium grey lighten-3 text-left pl-2 py-1 mt-2">
              <template v-if="view.file_size > 30">
                <v-tooltip bottom color="red">
                  <template #activator="{ on }">
                    <v-icon v-on="on" class="pr-1" color="red" size="20">mdi-alert-circle-outline</v-icon>
                  </template>
                  File size exceeds 30 MB
                </v-tooltip>
              </template>
              <template v-else>
                <v-progress-circular v-if="new_surgical_status === true || new_surgical_status === 'Processing'" class="mr-2" color="red" size="13" width="1.4" :indeterminate="new_surgical_status === 'Processing'"></v-progress-circular>
                <v-icon v-else color="success" size="20">mdi-check</v-icon>
              </template>
              {{ view.name }} <span class="text--secondary">- {{ view.file_size }} MB</span>
              <v-icon v-show="new_surgical_status !== 'Processing'" @click="removeAttachedSurgical(i, 'new')" class="remove-attachment" size="20">mdi-close</v-icon>
            </h5>
          </div>

          <div class="text-center">
            <v-btn :disabled="!trans_detail.editable || surgical_size_exceeds" :loading="loading_surgical_attachment" @click="postFileOfSurgical" class="mt-4" small tile>UPLOAD FILE</v-btn>
            <v-btn v-if="ciw_data.section2.length > 0 || view_attached_surgical.length > 0" @click="view_file_surgical = true" class="mt-4 ml-2" small tile>VIEW FILE</v-btn>
            <span class="d-block mt-3">Maximum upload size: 30 MB.</span>
          </div>
        </v-col>
        <v-col cols="1" sm="1" md="1" lg="1"></v-col>
      </v-row>

      <v-row v-if="loading_surgical_attachment" justify="center" class="text-center mt-2" wrap>
        <v-col cols="12" sm="6" md="4" lg="4">
          <div class="yellow lighten-3 pa-5">
            <h5 class="font-weight-regular grey--text text--darken-3">Please wait while we upload your file. <br>Do not click next or other category to finish uploading.</h5>
          </div>
        </v-col>
        <v-col cols="1" sm="1" md="1" lg="1"></v-col>
      </v-row>
      <v-divider class="my-8"></v-divider>

      <!-- DRUGS/MEDICINE -->
      <v-row wrap>
        <v-col cols="6" sm="6" md="6" lg="6">
          <h1 class="section-title">DRUGS/MEDICINE</h1>
        </v-col>
        <v-col cols="6" sm="6" md="6" lg="6" class="text-right">
          <v-btn v-if="trans_detail.crd_claims_status === 'Screening Rejected' && !!comment_data.cf4_part5" @click="displayCommentData('medicine')" color="primary" tile depressed small>CHECK COMMENTS 
            <v-badge content="!" color="red">
              <v-icon class="pl-1" small>mdi-comment</v-icon>
            </v-badge>
          </v-btn>
        </v-col>
      </v-row>
      <v-divider></v-divider>

      <v-autocomplete v-model="selected_medicine_holder" :items="medicine_items" :loading="load_medicine" @change="selected_medicine_holder = {}" item-text="generic_name_text" class="body-2 mt-2" placeholder="Search for Generic/Brand Name" return-object hide-no-data hide-details outlined>
        <template v-slot:item="{ item }">
          <v-row @click="addDrugsMedicine(item)">
            <v-list-item-avatar color="indigo" class="font-weight-light white--text">{{ item.medicine_code }}</v-list-item-avatar>
            <v-row class="pt-3" wrap pt-3>
              <v-col cols="12" sm="8" md="7" lg="5">
                <v-row wrap>
                  <v-col cols="5" sm="4" md="4" lg="3">
                    <h6 class="body-2 font-weight-regular">Generic Name:</h6>
                  </v-col>
                  <v-col cols="7" sm="8" md="8" lg="9">
                    <h6 class="body-2 font-weight-regular">{{ item.generic_name }}</h6>
                  </v-col>
                </v-row>
              </v-col>
              <v-col cols="12" sm="4" md="5" lg="7">
                <v-row wrap>
                  <v-col cols="5" sm="6" md="4" lg="2">
                    <h6 class="body-2 font-weight-regular">Preparation:</h6>
                  </v-col>
                  <v-col cols="7" md="8" lg="10">
                    <h6 class="body-2 font-weight-regular">{{ item.preparation }}</h6>
                  </v-col>
                </v-row>
              </v-col>

              <v-col cols="12" sm="8" md="7" lg="5">
                <v-row wrap>
                  <v-col cols="5" sm="4" md="4" lg="3">
                    <h6 class="body-2 font-weight-regular">Brand Name:</h6>
                  </v-col>
                  <v-col cols="7" md="8" lg="9">
                    <h6 class="body-2 font-weight-regular">{{ item.brand_name }}</h6>
                  </v-col>
                </v-row>
              </v-col>
              <v-col cols="12" sm="4" md="5" lg="7">
                <v-row wrap>
                  <v-col cols="5" sm="6" md="4" lg="2">
                    <h6 class="body-2 font-weight-regular">Route:</h6>
                  </v-col>
                  <v-col cols="7" md="8" lg="10">
                    <h6 class="body-2 font-weight-regular">{{ item.route }}</h6>
                  </v-col>
                </v-row>
              </v-col>

              <v-col cols="12" sm="8" md="7" lg="5">
                <v-row wrap>
                  <v-col cols="5" sm="4" md="4" lg="3">
                    <h6 class="body-2 font-weight-regular">Dosage:</h6>
                  </v-col>
                  <v-col cols="7" md="8" lg="9">
                    <h6 class="body-2 font-weight-regular">{{ item.dosage }}</h6>
                  </v-col>
                </v-row>
              </v-col>
              <v-col cols="12" sm="4" md="5" lg="7">
                <v-row wrap>
                  <v-col cols="5" sm="6" md="4" lg="2">
                    <h6 class="body-2 font-weight-regular">Amount:</h6>
                  </v-col>
                  <v-col cols="7" md="8" lg="10">
                    <h6 class="body-2 font-weight-regular">{{ item.amount }}</h6>
                  </v-col>
                </v-row>
              </v-col>
              <v-col cols="12" sm="12" md="12" lg="12">
                <v-divider class="mt-4"></v-divider>
              </v-col>
            </v-row>
          </v-row>
        </template>
        <template v-slot:selection></template>
      </v-autocomplete>
      
      <div v-if="ciw_data.section3.medicine.length > 0" :class="{'table-overflow-x' : $vuetify.breakpoint.mdAndDown}">
        <table class="mt-4" cellspacing="0" cellpadding="0">
          <tr>
            <th class="font-weight-medium body-2 text-uppercase">Qty.</th>
            <th class="font-weight-medium body-2 text-uppercase">Generic Name</th>
            <th class="font-weight-medium body-2 text-uppercase">Brand Name</th>
            <th class="font-weight-medium body-2 text-uppercase">Dosage</th>
            <th class="font-weight-medium body-2 text-uppercase">Preparation</th>
            <th class="font-weight-medium body-2 text-uppercase">Route</th>
            <th class="font-weight-medium body-2 text-uppercase">Amount</th>
            <th class="font-weight-medium body-2 text-uppercase">Total Cost</th>
          </tr>
          <tr v-for="(add, i) in ciw_data.section3.medicine" :key="i">
            <td style="width: 4%">
              <v-text-field v-model="add.quantity" v-on:keypress="numberOnly" v-on:keyup="autoComputeTotalCost(i, add.quantity, add.amount)" @click="autoComputeTotalCost(i, add.quantity, add.amount)" type="number" min="1" max="99" class="body-2" onpaste="return false" hide-details></v-text-field>
            </td> 
            <td style="width: 22%">
              <v-text-field v-model="add.generic_name" class="body-2" readonly hide-details></v-text-field>
            </td> 
            <td style="width: 18%">
              <v-text-field v-model="add.brand_name" class="body-2" readonly hide-details></v-text-field>
            </td>
            <td style="width: 12%">
              <v-text-field v-model="add.dosage" class="body-2" readonly hide-details></v-text-field>
            </td>
            <td style="width: 9%">
              <v-text-field v-model="add.preparation" class="body-2" readonly hide-details></v-text-field>
            </td>
            <td style="width: 8%">
              <v-text-field v-model="add.route" class="body-2" readonly hide-details></v-text-field>
            </td>
            <td style="width: 10%">
              <v-text-field v-model="add.amount" class="body-2" readonly hide-details></v-text-field>
            </td>
            <td style="width: 10%">
              <v-text-field v-model="add.total_cost_per_medicine" class="body-2" readonly hide-details></v-text-field>
            </td>
            <td v-if="trans_detail.editable" style="width: 1%">
              <v-icon :disabled="load_medicine" @click="removeAddedDrugsMedicine(i)">mdi-delete</v-icon>
            </td>
          </tr>
          <tr class="body-2">
            <td class="pa-2"></td>
            <td class="pa-2"></td>
            <td class="pa-2"></td>
            <td class="pa-2"></td>
            <td class="pa-2"></td>
            <td class="pa-2"></td>
            <td class="pa-2">{{ this.checkFormat(total_amount) }}</td>
            <td class="pa-2">{{ this.checkFormat(grand_total) }}</td>
          </tr>
        </table>
      </div>

      <!-- FILE ATTACHMENT FOR DRUGS/MEDICINE -->
      <v-row justify="center" class="mt-5" wrap>
        <v-col cols="12" sm="6" md="4" lg="4" class="pr-1">
          <label for="attached-medicine" class="file-attachment">Choose File</label> 
          <span class="ml-1" v-if="ciw_data.section3.attachments.length === 0">No file chosen</span>
          <span class="ml-1" v-else>{{ ciw_data.section3.attachments.length }} files</span>
          <input :disabled="!trans_detail.editable || new_medicine_status === 'Processing'" @change="addAttachedMedicine" id="attached-medicine" class="mt-4 d-none" type="file" ref="medicine" accept=".pdf" multiple><br>
          <v-divider class="mt-3"></v-divider>

          <div v-for="(attached, i) in ciw_data.section3.attachments" :key="i" class="text-left">
            <h5 class="font-weight-medium grey lighten-3 text-left pl-2 py-1 mt-2">
              <v-icon color="success" size="20">mdi-check</v-icon>
              {{ attached.name }} 
              <v-icon v-show="attached.loader === false || attached.loader === undefined" :disabled="!trans_detail.editable || new_medicine_status === 'Processing'" @click="removeAttachedMedicine(i, 'old')" class="remove-attachment" size="20">mdi-close</v-icon>
              <label v-show="attached.loader" class="remove-attachment font-italic">Deleting...</label>
            </h5>
          </div>

          <div v-for="(view, i) in view_attached_medicine" :key="'view'+i" class="text-left">
            <h5 class="font-weight-medium grey lighten-3 text-left pl-2 py-1 mt-2">
              <template v-if="view.file_size > 30">
                <v-tooltip bottom color="red">
                  <template #activator="{ on }">
                    <v-icon v-on="on" class="pr-1" color="red" size="20">mdi-alert-circle-outline</v-icon>
                  </template>
                  File size exceeds 30 MB
                </v-tooltip>
              </template>
              <template v-else>
                <v-progress-circular v-if="new_medicine_status === true || new_medicine_status === 'Processing'" class="mr-2" color="red" size="13" width="1.4" :indeterminate="new_medicine_status === 'Processing'"></v-progress-circular>
                <v-icon v-else color="success" size="20">mdi-check</v-icon>
              </template>
              {{ view.name }} <span class="text--secondary">- {{ view.file_size }} MB</span>
              <v-icon v-show="new_medicine_status !== 'Processing'" @click="removeAttachedMedicine(i, 'new')" class="remove-attachment" size="20">mdi-close</v-icon>
            </h5>
          </div>

          <div class="text-center">
            <v-btn :disabled="!trans_detail.editable || medicine_size_exceeds" :loading="loading_medicine_attachment" @click="postFileOfMedicine" class="mt-4" small tile>UPLOAD FILE</v-btn>
            <v-btn v-if="ciw_data.section3.attachments.length > 0 || view_attached_medicine.length > 0" @click="view_file_medicine = true" class="mt-4 ml-2" small tile>VIEW FILE</v-btn>
            <span class="d-block mt-3">Maximum upload size: 30 MB.</span>
          </div>
        </v-col>
        <v-col cols="1" sm="1" md="1" lg="1"></v-col>
      </v-row>

      <v-row v-if="loading_medicine_attachment" justify="center" class="text-center mt-2" wrap>
        <v-col cols="12" sm="6" md="4" lg="4">
          <div class="yellow lighten-3 pa-5">
            <h5 class="font-weight-regular grey--text text--darken-3">Please wait while we upload your file. <br>Do not click next or other category to finish uploading.</h5>
          </div>
        </v-col>
        <v-col cols="1" sm="1" md="1" lg="1"></v-col>
      </v-row>
      <v-divider class="mb-5 mt-8"></v-divider>

      <!-- OUTCOME OF TREATMENT -->
      <v-row class="mt-6" wrap mt-6>
        <v-col cols="6" sm="6" md="6" lg="6">
          <h1 class="section-title">
            OUTCOME OF TREATMENT
            <v-btn v-if="trans_detail.editable && !!ciw_data.section4.outcome_treatment" @click="ciw_data.section4.outcome_treatment = '', ciw_data.section4.outcome_treatment_reason = '', checkDataStatus('outcome')" class="ml-2" width="60" height="25" small>Clear</v-btn>
          </h1>
        </v-col>
        <v-col cols="6" sm="6" md="6" lg="6" class="text-right">
          <v-btn v-if="trans_detail.crd_claims_status === 'Screening Rejected' && !!comment_data.cf4_part6" @click="displayCommentData('outcome')" color="primary" tile depressed small>CHECK COMMENTS 
            <v-badge content="!" color="red">
              <v-icon class="pl-1" small>mdi-comment</v-icon>
            </v-badge>
          </v-btn>
        </v-col>
      </v-row>
      <v-divider></v-divider>

      <v-row justify="center" wrap>
        <v-col cols="12" sm="12" md="12" lg="11" xl="10">
          <v-radio-group v-model="ciw_data.section4.outcome_treatment" :column="$vuetify.breakpoint.xsOnly" @change="checkDataStatus('outcome')" class="pl-5 pl-sm-0" hide-details>
            <v-radio class="outcome-treatment" value="IMPROVED" label="IMPROVED"></v-radio>
            <v-radio class="outcome-treatment" value="HAMA" label="HAMA"></v-radio>
            <v-radio class="outcome-treatment" value="EXPIRED" label="EXPIRED"></v-radio>
            <v-radio class="outcome-treatment" value="ABSCONDED" label="ABSCONDED"></v-radio>
            <v-radio class="outcome-treatment" value="TRANSFERRED" label="TRANSFERRED"></v-radio>
          </v-radio-group>
        </v-col>
      </v-row>
      
      <v-row :class="{'opacity' : !ciw_data.section4.outcome_treatment}" align="baseline" class="mt-2" wrap>
        <v-col cols="3" sm="3" md="2" lg="2" xl="1" class="text-right pr-2">
          <label class="body-2">SPECIFY REASON</label>
        </v-col>
        <v-col cols="9" sm="9" md="9" lg="9" xl="10">
          <v-text-field v-model="ciw_data.section4.outcome_treatment_reason" :readonly="!ciw_data.section4.outcome_treatment" @change="checkDataStatus('outcome')" class="body-2" hide-details></v-text-field>
        </v-col>
      </v-row>

      <!-- VIEW FILE DIALOG FOR SURGICAL -->
      <v-dialog v-model="view_file_surgical" width="1100" persistent>
        <v-card>
          <v-card-title class="light-blue darken-3 white--text py-2 justify-center">
            <v-spacer></v-spacer>SURGICAL PROCEDURE {{ $vuetify.breakpoint.smAndUp ? 'ATTACHMENT' : '' }}<v-spacer></v-spacer>
            <v-btn @click="view_file_surgical = false" dark icon>
              <v-icon>mdi-close</v-icon>
            </v-btn>
          </v-card-title>
          <v-divider></v-divider>

          <div v-for="(attached, i) in ciw_data.section2" :key="i" class="px-4 mt-2">
            <h4>{{ i+1 }}) {{ attached.name }}</h4>
            <embed :src="attached.file_path+'#toolbar=0&view=FitH'" width="100%" height="600px" />
            <v-divider class="mt-4"></v-divider>
          </div>

          <div v-for="(attached, i) in view_attached_surgical" :key="'view'+i" class="px-4 mt-2">
            <h4>{{ i+ciw_data.section2.length+1 }}) {{ attached.name }}</h4>
            <embed :src="attached.file_path+'#toolbar=0&view=FitH'" width="100%" height="600px" />
            <v-divider class="mt-4"></v-divider>
          </div>

          <v-row justify="center" class="mt-3 pb-3" wrap>
            <v-btn @click="view_file_surgical = false" class="ml-1" color="primary">CLOSE</v-btn>
          </v-row>
        </v-card>
      </v-dialog>

      <!-- VIEW FILE DIALOG FOR MEDICINE -->
      <v-dialog v-model="view_file_medicine" width="1100" persistent>
        <v-card>
          <v-card-title class="light-blue darken-3 white--text py-2 justify-center">
            <v-spacer></v-spacer>DRUGS/MEDICINE {{ $vuetify.breakpoint.smAndUp ? 'ATTACHMENT' : '' }}<v-spacer></v-spacer>
            <v-btn @click="view_file_medicine = false" dark icon>
              <v-icon>mdi-close</v-icon>
            </v-btn>
          </v-card-title>
          <v-divider></v-divider>

          <div v-for="(attached, i) in ciw_data.section3.attachments" :key="i" class="px-4 mt-2">
            <h4>{{ i+1 }}) {{ attached.name }}</h4>
            <embed :src="attached.file_path+'#toolbar=0&view=FitH'" width="100%" height="600px" />
            <v-divider class="mt-4"></v-divider>
          </div>

          <div v-for="(attached, i) in view_attached_medicine" :key="'view'+i" class="px-4 mt-2">
            <h4>{{ i+ciw_data.section3.attachments.length+1 }}) {{ attached.name }}</h4>
            <embed :src="attached.file_path+'#toolbar=0&view=FitH'" width="100%" height="600px" />
            <v-divider class="mt-4"></v-divider>
          </div>

          <v-row justify="center" class="mt-3 pb-3" wrap>
            <v-btn @click="view_file_medicine = false" class="ml-1" color="primary">CLOSE</v-btn>
          </v-row>
        </v-card>
      </v-dialog>

      <!-- COMMENT DIALOG -->
      <v-dialog v-model="comment_dialog" width="600" persistent>
        <v-card>
          <h3 class="grey--text text--darken-3 font-weight-medium py-1 text-center">{{ comment_title }}</h3>
          <v-divider></v-divider>

          <div class="px-4 mt-2">
            <label class="body-2">Comment:</label>
            <v-textarea v-model="comment_content" rows="4" outlined readonly hide-details></v-textarea>
          </div>
          
          <v-row justify="center" class="mt-3 pb-3" wrap>
            <v-btn @click="comment_dialog = false" class="ml-1" color="primary" small>CLOSE</v-btn>
          </v-row>
        </v-card>
      </v-dialog>

      <!-- NAVIGATION BUTTON -->
      <v-divider class="my-5"></v-divider>
      <v-row justify="space-between" wrap>
        <v-col cols="5" sm="5" md="5" lg="5">
          <v-btn @click="trans_detail.gender === 'MALE' || trans_detail.gender === 'M' ? $router.push('/input-forms/physical-examination') : $router.push('/input-forms/maternity')" color="primary"><i class="fas fa-arrow-left mr-1"></i>PREVIOUS</v-btn> 
        </v-col>
        <v-col cols="5" sm="5" md="5" lg="5" class="text-right">
          <v-btn @click="$router.push('/input-forms/accreditation-and-signature')" color="primary">NEXT<i class="fas fa-arrow-right ml-1"></i></v-btn>
        </v-col>
      </v-row>
      
      <Alert :alert="alert" @removeProcedure="removeProcedure" />
    </v-form>
  </div>
</template>

<script>
import Alert from '../../Alert.vue'

export default {
  props: ['trans_detail', 'required', 'comment_data'],

  components: {
    Alert
  },
  
  created(){
    setTimeout(() => {
      this.getCourseInTheWard();

      this.confinement_date = sessionStorage.getItem('VKI55S') === null ? null : JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('VKI55S'), 'flag423D').toString(this.$crypto.enc.Utf8))
    }, 200)
  },

  data(){
    return{
      // DATA
      ciw_data: {
        section2: [],
        section3: {
          medicine: [],
          attachments: []
        },
        section4: {
          outcome_treatment: '',
          outcome_treatment_reason: ''
        }
      },

      pci_data: {
        data: [{
          selected_icd: [],
          procedures: [],
        }],
        old_data: [],
        status: false
      },
      
      doctors_order: {
        data: [],
        status: false
      },

      // OTHERS
      confinement_date: '',
      medicine_placeholder: true,
      selected_medicine: [],
      total_fees: {
        hci_fee: '',
        pf_fee: '',
        grand_total: '',
        status: false
      },
      alert: {},
     
      // SURGICAL ATTACHMENT
      new_surgical_status: true,
      view_attached_surgical: [],
      post_attached_surgical: [],
      view_file_surgical: false,
      loading_surgical_attachment: false,
      surgical_size_exceeds: false,

      // MEDICINE ATTACHMENT
      new_medicine_status: true,
      view_attached_medicine: [],
      post_attached_medicine: [],
      view_file_medicine: false,
      loading_medicine_attachment: false,
      medicine_size_exceeds: false,

      // REFERENCE DATA
      medicine_list: [],
      selected_medicine_holder: {},

      // LOADER
      load_medicine: true,

      // COMMENTS
      comment_dialog: false,
      comment_title: '',
      comment_content: ''
    }
  },

  computed: {
    // COMPUTATION FOR TOTAL AMOUNT
    total_amount(){
      return this.ciw_data.section3.medicine.reduce(function (sum, item) {
        return sum + parseFloat(item.amount)
      }, 0)
    },

    // COMPUTATION FOR GRAND TOTAL COST
    grand_total(){
      return this.ciw_data.section3.medicine.reduce(function (sum, item) {
        return sum + (parseInt(item.quantity) * parseFloat(item.amount))
      }, 0)
    },
    
    // GET MEDICINE ITEMS
    medicine_items(){
      const medicine_list = this.medicine_list.filter(item => {
        return !this.selected_medicine.includes(item.generic_name_text)
      })

      return medicine_list
    }
  },

  watch: {
    // PREVENT NAVIGATE IF THERE IS UNSAVED ATTACHMENT
    view_attached_surgical(value){
      let total = 0

      value.forEach(element => {
        total += parseFloat(element.file_size)
      })

      if(total > 30){
        this.surgical_size_exceeds = true
      }else{
        this.surgical_size_exceeds = false
      }

      if(value.length > 0){
        this.unsaved_surgical = 'unsaved_attachment'
      }else{
        this.unsaved_surgical = ''
      }
      this.checkDataStatus('doctors');
    },
    
    // PREVENT NAVIGATE IF THERE IS UNSAVED ATTACHMENT
    view_attached_medicine(value){
      let total = 0

      value.forEach(element => {
        total += parseFloat(element.file_size)
      })

      if(total > 30){
        this.medicine_size_exceeds = true
      }else{
        this.medicine_size_exceeds = false
      }

      if(value.length > 0){
        this.unsaved_medicine = 'unsaved_attachment'
      }else{
        this.unsaved_medicine = ''
      }
      this.checkDataStatus('doctors');
    }
  },

  methods: {
    // GET COURSE IN WARD DATA
    // getCourseInTheWard(){
    //   this.doctors_order = JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('LG4S04'), '5s05SLFI').toString(this.$crypto.enc.Utf8))
    //   let ciw_data = sessionStorage.getItem('PORT4D') ? this.$crypto.AES.decrypt(sessionStorage.getItem('PORT4D'), 'X4d3r5fS').toString(this.$crypto.enc.Utf8) : null
    //   let pci_data = sessionStorage.getItem('LYK56D') ? this.$crypto.AES.decrypt(sessionStorage.getItem('LYK56D'), 'XLgopi4x').toString(this.$crypto.enc.Utf8) : null

    //   if(ciw_data === null){
    //     this.$axios.post(this.$tms_url+'resources/api/_get_transaction_ip_ciw.php', this.$qs.stringify({
    //       post_data: this.wsDataEncryption(JSON.stringify({
    //         phic_tracking_number: this.trans_detail.phic_tracking_number,
    //         transaction_number: this.trans_detail.transaction_number
    //       }))
    //     }))
    //     .then(response => {
    //       response.data = this.responseDataDecryption(response.data)
    //       this.ciw_data = {
    //         section2: [],
    //         section3: {
    //           medicine: response.data.MEDICINE,
    //           attachments: [],
    //         },
    //         section4: {
    //           outcome_treatment: response.data.TRANSACTION.outcome_of_treatment,
    //           outcome_treatment_reason: response.data.TRANSACTION.outcome_of_treatment_reason
    //         },
    //         status: {
    //           doctors: false,
    //           medicine: false,
    //           outcome: false
    //         }
    //       }

    //       if(pci_data === null){
    //         let discharged_diagnosis = response.data.DISCHARGED_DIAGNOSIS
            
    //         if(discharged_diagnosis){
    //           let diagnosis_code = []
    //           let selected_discharged_diagnosis = []

    //           discharged_diagnosis.forEach(element => {
    //             if(!diagnosis_code.includes(element.icd_code)){
    //               diagnosis_code.push(element.icd_code)
    //             }
    //           })
              
    //           diagnosis_code.forEach((element, index) => {
    //             selected_discharged_diagnosis.push({
    //               transaction_cpt_no: null,
    //               icd_tag: 'NEW',
    //               icd_code: null,
    //               icd_description: null,
    //               procedures: [],
    //               old_procedures: []
    //             })
                
    //             discharged_diagnosis.forEach(diagnosis => {
    //               if(element === diagnosis.icd_code){
    //                 if(diagnosis.cpt_code && diagnosis.cpt_code !== 'N/A' && diagnosis.cpt_tag !== 'OLD'){
    //                   selected_discharged_diagnosis[index].procedures.push({
    //                     tag: diagnosis.tag,
    //                     category: diagnosis.rvs_category,

    //                     transaction_cpt_no: diagnosis.transaction_cpt_no,
    //                     cpt_tag: 'NEW',
    //                     cpt_code: diagnosis.cpt_code,
    //                     cpt_description: diagnosis.cpt_description,
    //                     cpt_amount: this.checkFormat(Number(diagnosis.cpt_amount).toFixed(2)),
    //                     original_date: diagnosis.cpt_original_date_of_proc,
    //                     date: diagnosis.cpt_current_date_of_proc ? this.formatDate(diagnosis.cpt_current_date_of_proc) : diagnosis.cpt_original_date_of_proc,
    //                     date_date: diagnosis.cpt_current_date_of_proc ? diagnosis.cpt_current_date_of_proc : diagnosis.cpt_original_date_of_proc,
    //                     hmo_cpt_status: diagnosis.hmo_cpt_status,
    //                     phic_cpt_status: diagnosis.phic_cpt_status,
    //                     lgu_cpt_status: diagnosis.lgu_cpt_status,

    //                     phic_patient_discharged_diagnosis_id: diagnosis.phic_patient_discharged_diagnosis_id,
    //                     rvs_tag: 'NEW',
    //                     rvs_code: diagnosis.rvs_code,
    //                     rvs_description: diagnosis.rvs_description,
    //                     rvs_case_rate: diagnosis.rvs_case_rate,
    //                     rvs_hci_fee: diagnosis.rvs_hci_fee,
    //                     rvs_professional_fee: diagnosis.rvs_professional_fee,
    //                     laterality: diagnosis.phic_laterality_check
    //                   })
    //                 }

    //                 selected_discharged_diagnosis[index].transaction_cpt_no = diagnosis.transaction_cpt_no
    //                 selected_discharged_diagnosis[index].icd_tag = 'NEW'
    //                 selected_discharged_diagnosis[index].icd_code = diagnosis.icd_code
    //                 selected_discharged_diagnosis[index].icd_description = diagnosis.icd_description
    //                 selected_discharged_diagnosis[index].hmo_icd_status = diagnosis.hmo_icd_status
    //                 selected_discharged_diagnosis[index].phic_icd_status = diagnosis.phic_icd_status
    //                 selected_discharged_diagnosis[index].lgu_icd_status = diagnosis.lgu_icd_status
    //               }
    //             })
    //           })

    //           this.pci_data.data = selected_discharged_diagnosis
    //           this.pci_data.old_data = []
    //         }
    //       }else{
    //         this.pci_data = JSON.parse(pci_data)
    //       }

    //       let primary_secondary = [
    //         this.pci_data.data[0] ? this.pci_data.data[0] : null,
    //         this.pci_data.data[1] ? this.pci_data.data[1] : null
    //       ]

    //       sessionStorage.setItem('lDsjrkd', this.$crypto.AES.encrypt(JSON.stringify(primary_secondary), 'pfdFxg44'))

    //       if(sessionStorage.getItem('49SFL4')){
    //         this.total_fees = JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('49SFL4'), 'FoelR42s').toString(this.$crypto.enc.Utf8))
    //       }else{
    //         let rvs_hci_fee = 0
    //         let rvs_professional_fee = 0
    //         let total_cpt_amount = 0
    //         let first_case_rate = 0
    //         let first_case_pf = '0'
    //         let first_case_hci = '0'
    //         let second_case_rate = 0
    //         let second_case_pf = '0'
    //         let second_case_hci = '0'


    //         this.pci_data.data.forEach(diagnosis => {
    //           diagnosis.procedures.forEach(procedure => {
    //             if(procedure.rvs_hci_fee){
    //               total_cpt_amount += parseFloat(procedure.cpt_amount.replace(/,/g, ''))
    //               rvs_hci_fee += parseFloat(procedure.rvs_hci_fee.replace(/,/g, ''))
    //               rvs_professional_fee += parseFloat(procedure.rvs_professional_fee.replace(/,/g, ''))
    //             }
    //           })
    //         })

    //         let first_case = response.data.FIRST_CASE_RATES
    //         let second_case = response.data.SECOND_CASE_RATES

    //         if(this.trans_detail.transaction_type === 'INPATIENT'){
    //           first_case_rate = first_case.first_case_rate ? parseFloat(first_case.first_case_rate.replace(/,/g, '')) : 0
    //           first_case_pf = first_case.first_case_professional_fee ? first_case.first_case_professional_fee : '0'
    //           first_case_hci = first_case.first_case_hci_fee ? first_case.first_case_hci_fee : '0'

    //           second_case_rate = second_case.second_case_rate ? parseFloat(second_case.second_case_rate.replace(/,/g, '')) : 0
    //           second_case_pf = second_case.second_case_professional_fee ? second_case.second_case_professional_fee : '0'
    //           second_case_hci = second_case.second_case_hci_fee ? second_case.second_case_hci_fee : '0'

    //           total_cpt_amount = parseFloat(total_cpt_amount + first_case_rate + second_case_rate)
    //         }

    //         let total_professional_fee = parseFloat(first_case_pf.replace(/,/g, '')) + parseFloat(second_case_pf.replace(/,/g, '')) + rvs_professional_fee
    //         let total_hci_fee = parseFloat(first_case_hci.replace(/,/g, '')) + parseFloat(second_case_hci.replace(/,/g, '')) + rvs_hci_fee
    //         let grand_total = total_professional_fee + total_hci_fee

    //         this.total_fees.hci_fee = total_hci_fee
    //         this.total_fees.pf_fee = total_professional_fee
    //         this.total_fees.grand_total = grand_total
    //         this.total_fees.total_cpt_amount = total_cpt_amount

    //         sessionStorage.setItem('49SFL4', this.$crypto.AES.encrypt(JSON.stringify(this.total_fees), 'FoelR42s'))
    //       }

    //       if(response.data.MEDICINE){
    //         this.ciw_data.section3.medicine.forEach(element => {
    //           element.generic_name_text = element.generic_name + element.brand_name + element.dosage
    //           this.selected_medicine.push(element.generic_name_text)
    //         })
    //       }

    //       if(response.data.ATTACHMENT){
    //         response.data.ATTACHMENT.forEach(item => {
    //           if(item.attachment_category === 'SURGICAL PROCEDURE'){
    //             this.ciw_data.section2.push(item)
    //             this.ciw_data.section2.forEach(element => {
    //               let no_of_file = element.file_name.split('_')[0]
    //               let provider = this.$store.state.prv_data.provider_tin ? this.$store.state.prv_data.provider_tin : this.$store.state.prv_data.provider_code
    //               let sum = no_of_file.length + 8 + provider.length + this.trans_detail.transaction_number.length + 4

    //               element.name = element.file_name.substring(sum)
    //               element.loader = false
    //             })
    //           }else{
    //             this.ciw_data.section3.attachments.push(item)
    //             this.ciw_data.section3.attachments.forEach(element => {
    //               let no_of_file = element.file_name.split('_')[0]
    //               let provider = this.$store.state.prv_data.provider_tin ? this.$store.state.prv_data.provider_tin : this.$store.state.prv_data.provider_code
    //               let sum = no_of_file.length + 8 + provider.length + this.trans_detail.transaction_number.length + 4

    //               element.name = element.file_name.substring(sum)
    //               element.loader = false
    //             })
    //           }
    //         })
    //       }

    //       this.saveData();
    //       this.$store.commit('set_loading_category', false)
    //       this.getDrugsMedicine();
    //     })
    //     .catch(error => {
    //        this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
    //     })
    //   }else{
    //     this.ciw_data = JSON.parse(ciw_data)
    //     this.pci_data = JSON.parse(pci_data)
    //     this.total_fees = JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('49SFL4'), 'FoelR42s').toString(this.$crypto.enc.Utf8))

    //     this.$store.commit('set_loading_category', false)
    //     this.getDrugsMedicine();
    //   }
    // },

    async getCourseInTheWard(){
      this.doctors_order = JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('LG4S04'), '5s05SLFI').toString(this.$crypto.enc.Utf8))
      let ciw_data = sessionStorage.getItem('PORT4D') ? this.$crypto.AES.decrypt(sessionStorage.getItem('PORT4D'), 'X4d3r5fS').toString(this.$crypto.enc.Utf8) : null
      let pci_data = sessionStorage.getItem('LYK56D') ? this.$crypto.AES.decrypt(sessionStorage.getItem('LYK56D'), 'XLgopi4x').toString(this.$crypto.enc.Utf8) : null

      if(ciw_data === null){
        let response = await this.$services.getEclaims({
              request_key: 'physical_exam',
              // provider_code: this.$store.state.prv_data.provider_code,
              // ek_lgu_id: this.trans_detail.ek_lgu_id,
              // transaction_number: this.trans_detail.transaction_number
              provider_code:'EK8BE7221CB09A2221',
              ek_lgu_id:'EK-NRF3U1999H518-2635',
              transaction_number:'HEY412FD5WKB',
              migrated_to_eclaim_table: this.trans_detail.migrated_to_eclaim_table,
              claim_no: this.trans_detail.claim_no
        });

        if (response.status === 200) {
          response.data = this.responseDataDecryption(response.data)
          this.ciw_data = {
            section2: [],
            section3: {
              medicine: response.data.MEDICINE,
              attachments: [],
            },
            section4: {
              outcome_treatment: response.data.TRANSACTION.outcome_of_treatment,
              outcome_treatment_reason: response.data.TRANSACTION.outcome_of_treatment_reason
            },
            status: {
              doctors: false,
              medicine: false,
              outcome: false
            }
          }

          if(pci_data === null){
            let discharged_diagnosis = response.data.DISCHARGED_DIAGNOSIS
            
            if(discharged_diagnosis){
              let diagnosis_code = []
              let selected_discharged_diagnosis = []

              discharged_diagnosis.forEach(element => {
                if(!diagnosis_code.includes(element.icd_code)){
                  diagnosis_code.push(element.icd_code)
                }
              })
              
              diagnosis_code.forEach((element, index) => {
                selected_discharged_diagnosis.push({
                  transaction_cpt_no: null,
                  icd_tag: 'NEW',
                  icd_code: null,
                  icd_description: null,
                  procedures: [],
                  old_procedures: []
                })
                
                discharged_diagnosis.forEach(diagnosis => {
                  if(element === diagnosis.icd_code){
                    if(diagnosis.cpt_code && diagnosis.cpt_code !== 'N/A' && diagnosis.cpt_tag !== 'OLD'){
                      selected_discharged_diagnosis[index].procedures.push({
                        tag: diagnosis.tag,
                        category: diagnosis.rvs_category,

                        transaction_cpt_no: diagnosis.transaction_cpt_no,
                        cpt_tag: 'NEW',
                        cpt_code: diagnosis.cpt_code,
                        cpt_description: diagnosis.cpt_description,
                        cpt_amount: this.checkFormat(Number(diagnosis.cpt_amount).toFixed(2)),
                        original_date: diagnosis.cpt_original_date_of_proc,
                        date: diagnosis.cpt_current_date_of_proc ? this.formatDate(diagnosis.cpt_current_date_of_proc) : diagnosis.cpt_original_date_of_proc,
                        date_date: diagnosis.cpt_current_date_of_proc ? diagnosis.cpt_current_date_of_proc : diagnosis.cpt_original_date_of_proc,
                        hmo_cpt_status: diagnosis.hmo_cpt_status,
                        phic_cpt_status: diagnosis.phic_cpt_status,
                        lgu_cpt_status: diagnosis.lgu_cpt_status,

                        phic_patient_discharged_diagnosis_id: diagnosis.phic_patient_discharged_diagnosis_id,
                        rvs_tag: 'NEW',
                        rvs_code: diagnosis.rvs_code,
                        rvs_description: diagnosis.rvs_description,
                        rvs_case_rate: diagnosis.rvs_case_rate,
                        rvs_hci_fee: diagnosis.rvs_hci_fee,
                        rvs_professional_fee: diagnosis.rvs_professional_fee,
                        laterality: diagnosis.phic_laterality_check
                      })
                    }

                    selected_discharged_diagnosis[index].transaction_cpt_no = diagnosis.transaction_cpt_no
                    selected_discharged_diagnosis[index].icd_tag = 'NEW'
                    selected_discharged_diagnosis[index].icd_code = diagnosis.icd_code
                    selected_discharged_diagnosis[index].icd_description = diagnosis.icd_description
                    selected_discharged_diagnosis[index].hmo_icd_status = diagnosis.hmo_icd_status
                    selected_discharged_diagnosis[index].phic_icd_status = diagnosis.phic_icd_status
                    selected_discharged_diagnosis[index].lgu_icd_status = diagnosis.lgu_icd_status
                  }
                })
              })

              this.pci_data.data = selected_discharged_diagnosis
              this.pci_data.old_data = []
            }
          }else{
            this.pci_data = JSON.parse(pci_data)
          }

          let primary_secondary = [
            this.pci_data.data[0] ? this.pci_data.data[0] : null,
            this.pci_data.data[1] ? this.pci_data.data[1] : null
          ]

          sessionStorage.setItem('lDsjrkd', this.$crypto.AES.encrypt(JSON.stringify(primary_secondary), 'pfdFxg44'))

          if(sessionStorage.getItem('49SFL4')){
            this.total_fees = JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('49SFL4'), 'FoelR42s').toString(this.$crypto.enc.Utf8))
          }else{
            let rvs_hci_fee = 0
            let rvs_professional_fee = 0
            let total_cpt_amount = 0
            let first_case_rate = 0
            let first_case_pf = '0'
            let first_case_hci = '0'
            let second_case_rate = 0
            let second_case_pf = '0'
            let second_case_hci = '0'


            this.pci_data.data.forEach(diagnosis => {
              diagnosis.procedures.forEach(procedure => {
                if(procedure.rvs_hci_fee){
                  total_cpt_amount += parseFloat(procedure.cpt_amount.replace(/,/g, ''))
                  rvs_hci_fee += parseFloat(procedure.rvs_hci_fee.replace(/,/g, ''))
                  rvs_professional_fee += parseFloat(procedure.rvs_professional_fee.replace(/,/g, ''))
                }
              })
            })

            let first_case = response.data.FIRST_CASE_RATES
            let second_case = response.data.SECOND_CASE_RATES

            if(this.trans_detail.transaction_type === 'INPATIENT'){
              first_case_rate = first_case.first_case_rate ? parseFloat(first_case.first_case_rate.replace(/,/g, '')) : 0
              first_case_pf = first_case.first_case_professional_fee ? first_case.first_case_professional_fee : '0'
              first_case_hci = first_case.first_case_hci_fee ? first_case.first_case_hci_fee : '0'

              second_case_rate = second_case.second_case_rate ? parseFloat(second_case.second_case_rate.replace(/,/g, '')) : 0
              second_case_pf = second_case.second_case_professional_fee ? second_case.second_case_professional_fee : '0'
              second_case_hci = second_case.second_case_hci_fee ? second_case.second_case_hci_fee : '0'

              total_cpt_amount = parseFloat(total_cpt_amount + first_case_rate + second_case_rate)
            }

            let total_professional_fee = parseFloat(first_case_pf.replace(/,/g, '')) + parseFloat(second_case_pf.replace(/,/g, '')) + rvs_professional_fee
            let total_hci_fee = parseFloat(first_case_hci.replace(/,/g, '')) + parseFloat(second_case_hci.replace(/,/g, '')) + rvs_hci_fee
            let grand_total = total_professional_fee + total_hci_fee

            this.total_fees.hci_fee = total_hci_fee
            this.total_fees.pf_fee = total_professional_fee
            this.total_fees.grand_total = grand_total
            this.total_fees.total_cpt_amount = total_cpt_amount

            sessionStorage.setItem('49SFL4', this.$crypto.AES.encrypt(JSON.stringify(this.total_fees), 'FoelR42s'))
          }

          if(response.data.MEDICINE){
            this.ciw_data.section3.medicine.forEach(element => {
              element.generic_name_text = element.generic_name + element.brand_name + element.dosage
              this.selected_medicine.push(element.generic_name_text)
            })
          }

          if(response.data.ATTACHMENT){
            response.data.ATTACHMENT.forEach(item => {
              if(item.attachment_category === 'SURGICAL PROCEDURE'){
                this.ciw_data.section2.push(item)
                this.ciw_data.section2.forEach(element => {
                  let no_of_file = element.file_name.split('_')[0]
                  let provider = this.$store.state.prv_data.provider_tin ? this.$store.state.prv_data.provider_tin : this.$store.state.prv_data.provider_code
                  let sum = no_of_file.length + 8 + provider.length + this.trans_detail.transaction_number.length + 4

                  element.name = element.file_name.substring(sum)
                  element.loader = false
                })
              }else{
                this.ciw_data.section3.attachments.push(item)
                this.ciw_data.section3.attachments.forEach(element => {
                  let no_of_file = element.file_name.split('_')[0]
                  let provider = this.$store.state.prv_data.provider_tin ? this.$store.state.prv_data.provider_tin : this.$store.state.prv_data.provider_code
                  let sum = no_of_file.length + 8 + provider.length + this.trans_detail.transaction_number.length + 4

                  element.name = element.file_name.substring(sum)
                  element.loader = false
                })
              }
            })
          }

          this.saveData();
          this.$store.commit('set_loading_category', false)
          this.getDrugsMedicine(); 
        } else {
            this.alert = response.error;
        }
      } else {
        this.ciw_data = JSON.parse(ciw_data)
        this.pci_data = JSON.parse(pci_data)
        this.total_fees = JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('49SFL4'), 'FoelR42s').toString(this.$crypto.enc.Utf8))

        this.$store.commit('set_loading_category', false)
        this.getDrugsMedicine();
      }
    },

    // GET DRUGS/MEDICINE
    getDrugsMedicine(){
      if(this.trans_detail.editable){
        if(localStorage.getItem('FGG536')){
          this.medicine_list = localStorage.getItem('FGG536') ? JSON.parse(this.$crypto.AES.decrypt(localStorage.getItem('FGG536'), 'puuioGDt').toString(this.$crypto.enc.Utf8)) : null
          this.load_medicine = false
        }else{
          this.$axios.post(this.$cms_url+'resources/api/_get_transaction_ip_ref_data.php', this.$qs.stringify({
            post_data: this.wsDataEncryption(JSON.stringify({
              request_key: 'medicine'
            }))
          }))
          .then(response => {
            //response.data = this.responseDataDecryption(response.data)
            this.medicine_list = response.data.map(item => {
              let medicine = {
                quantity: 1,
                brand_name: item.brand_name,
                dosage: item.dosage,
                route: item.route,
                preparation: item.preparation,
                medicine_no: item.medicine_no,
                medicine_code: item.medicine_code,
                amount: Number(item.amount).toFixed(2),
                total_cost_per_medicine: item.amount,
                generic_name: item.generic_name,
                generic_name_text: item.generic_name + item.brand_name + item.dosage
              }
              
              return medicine
            })

            localStorage.setItem('FGG536', this.$crypto.AES.encrypt(JSON.stringify(this.medicine_list), 'puuioGDt'))
            this.load_medicine = false
          })
          .catch(error => {
             this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
          })
        }
      }else{
        this.load_medicine = false
      }
    },

    // DISPLAY CPT PROCEDURES
    displayCptProcedures(){
      let procedures = []

      this.pci_data.data.forEach((icd, icd_index) => {
        icd.procedures.forEach((cpt, cpt_index) => {
          cpt.icd_index = icd_index
          cpt.icd_description = icd.icd_description
          cpt.cpt_index = cpt_index
          procedures.push(cpt)
        })
      })

      this.procedures_length = procedures.length
      return procedures
    },

    // CONFIRM REMOVE OF PROCEDURES
    confirmRemoveProcedure(icd_index, icd_description, cpt_index){
      this.class_data = {
        index: icd_index,
        data: cpt_index
      }

      let title = 'This procedure will also be removed in Discharged Diagnosis under ICD: <h4 class="my-3 font-weight-regular">'+icd_description+'</h4>'
      this.alert = { display: true, type: 'standard', width: '600', icon: 'mdi-alert-circle', color: 'red', title: title, body: 'Click OKAY to continue', btn_pry_txt: 'OKAY', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'loadingBtn', btn_pry_emt: 'removeProcedure', btn_sec_txt: 'CANCEL', btn_sec_color: 'grey darken-2', btn_sec_otl: true, btn_sec_act: 'closeAlert' }
    },

    // REMOVE PROCEDURE
    removeProcedure(){
      let procedure = this.pci_data.data[this.class_data.index].procedures[this.class_data.data]

      let hci_fee = parseFloat(procedure.rvs_hci_fee ? procedure.rvs_hci_fee.replace(/,/g, '') : 0)
      let pf_fee = parseFloat(procedure.rvs_professional_fee ? procedure.rvs_professional_fee.replace(/,/g, '') : 0)

      if(procedure.rvs_case_rate){
        let total_cpt_amount = parseFloat(procedure.cpt_amount ? procedure.cpt_amount.replace(/,/g, '') : 0)
        this.total_fees.total_cpt_amount -= total_cpt_amount
      }

      this.total_fees.hci_fee -= hci_fee
      this.total_fees.pf_fee -= pf_fee
      this.total_fees.grand_total = this.total_fees.pf_fee + this.total_fees.hci_fee
      this.total_fees.status = true 
      sessionStorage.setItem('49SFL4', this.$crypto.AES.encrypt(JSON.stringify(this.total_fees), 'FoelR42s'))

      if(procedure.transaction_cpt_no){
        procedure.cpt_tag = 'OLD'
        this.pci_data.data[this.class_data.index].old_procedures.push(procedure)
      }

      let philhealth_certification = JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('kgdlDt'), 'vcoF535f').toString(this.$crypto.enc.Utf8))
      philhealth_certification.total_cpt_amount = this.total_fees.total_cpt_amount

      sessionStorage.setItem('kgdlDt', this.$crypto.AES.encrypt(JSON.stringify(philhealth_certification), 'vcoF535f'))
      
      this.pci_data.data[this.class_data.index].procedures.splice(this.class_data.data, 1)
      this.alert = {}
      this.pci_data.status = true
      this.$emit('change-status')
    },

    // ADD DOCTORS ORDER/ACTION
    addDoctorsOrder(){
      this.doctors_order.data.push({
        date: '',
        doctors_order: ''
      })
    },

    // REMOVE ADDED DOCTORS ORDER/ACTION
    removeAddedDoctorsOrder(index){
      this.doctors_order.data.splice(index, 1)
      this.checkDataStatus('doctors')
      this.$emit('change-status')
    },

    // ADD ATTACHED FILE FOR SURGICAL PROCEDURES
    addAttachedSurgical(){
      let attached_files = []
      let re_attached_files = []
      this.new_surgical_status = true

      this.ciw_data.section2.forEach(element => {
        attached_files.push(element.name)
      })

      this.view_attached_surgical.forEach(element => {
        attached_files.push(element.name)
      })

      Object.values(this.$refs.surgical.files).forEach(element => {
        if(attached_files.includes(element.name)){
          re_attached_files.push('<br>'+element.name)
        }else{
          this.post_attached_surgical.push(element)
          this.view_attached_surgical.push({
            name: element.name,
            file_size: Number(element.size * 0.00000095367432).toFixed(2),
            file_path: window.URL.createObjectURL(element)
          })
        }
      })

      if(re_attached_files.length > 0){
        let title = 'This file already exist and cannot be attached again.<b>' + re_attached_files + ' </b>'
        this.alert = { display: true, type: 'standard', width: '500', icon: 'mdi-close-circle', color: 'red', title: title, btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'closeAlert' }
      }
    },

    // REMOVE ATTACHED FILE FOR SURGICAL PROCEDURES
    removeAttachedSurgical(index, status){
      if(status === 'old'){
        this.ciw_data.section2[index].loader = true
        this.$axios.post(this.$tms_url+'resources/controller/trn_del_attachment.php', this.$qs.stringify({
          post_data: this.wsDataEncryption(JSON.stringify({
            phic_tracking_number: this.trans_detail.phic_tracking_number,
            transaction_number: this.trans_detail.transaction_number,
            attachment_category: 'SURGICAL PROCEDURE',
            file_name: this.ciw_data.section2[index].file_name
          }))
        }))
        .then(response => {
          if(response.data.success){
            this.ciw_data.section2.splice(index, 1)
            this.saveData();
          }else{
            this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: 'Something Went Wrong', body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
          }
        })
        .catch(error => {
           this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
        })
      }else{
        this.post_attached_surgical.splice(index - this.post_attached_surgical.length, 1)
        this.view_attached_surgical.splice(index - this.view_attached_surgical.length, 1)
      }
      document.getElementById("attached-surgical").value = "";
    },

    // POST ATTACHED FILE TO SERVER OF SURGICAL PROCEDURE
    postFileOfSurgical(){
      if(this.post_attached_surgical.length === 0){
        this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-close-circle', color: 'red', title: 'No file chosen. Please attach file', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'closeAlert' }
      }else{
        this.$store.commit('set_prevent_navigation', false)
        this.loading_surgical_attachment = true
        this.new_surgical_status = 'Processing'

        let formData = new FormData();
        let total_count = this.post_attached_surgical.length
        for( var i = 0; i < this.post_attached_surgical.length; i++ ){
          let file = this.post_attached_surgical[i];
          formData.append('file'+ i +'', file);
        }

        formData.append('post_data', this.wsDataEncryption(JSON.stringify({
          phic_tracking_number: this.trans_detail.phic_tracking_number,
          transaction_number: this.trans_detail.transaction_number,
          provider_user: this.$store.state.usr_credentials.user_name,
          department: this.$store.state.usr_credentials.department,
          provider_code: this.$store.state.prv_data.provider_code,
          provider_tin: this.$store.state.prv_data.provider_tin,
          hmo_host_code: this.trans_detail.hmo_host_code,
          attachment_category: 'SURGICAL PROCEDURE',
          request_key: 'phic_patient_prov_attachments',
          total_count: total_count
        })))

        this.$axios.post(this.$tms_url+'resources/controller/trn_upd_inpatient_ciw.php', 
          formData,
          {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
        )
        .then(response => {
          if(response.data.success){         
            this.responseDataDecryption(response.data.file_path).forEach(element => {
              let no_of_file = element.file_name.split('_')[0]
              let provider = this.$store.state.prv_data.provider_tin ? this.$store.state.prv_data.provider_tin : this.$store.state.prv_data.provider_code
              let sum = no_of_file.length + 8 + provider.length + this.trans_detail.transaction_number.length + 4

              element.name = element.file_name.substring(sum)
              element.loader = false
  
              this.ciw_data.section2.push(element)
            })
  
            this.new_surgical_status = false
            this.post_attached_surgical = []
            this.view_attached_surgical = []
            this.loading_surgical_attachment = false
            this.$store.commit('set_prevent_navigation', true)
            this.saveData();
          }else{
            this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: 'Something Went Wrong', body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
          }
        })
        .catch(error => {
           this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
        })
      }
    },

    // ADD DRUGS/MEDICINE
    addDrugsMedicine(data){
      this.ciw_data.section3.medicine.push({...data, quantity: 1})
      this.ciw_data.status.medicine = true
      this.selected_medicine.push(data.generic_name_text)
      this.$emit('change-status')
    },

    // REMOVE ADDED DRUGS OR MEDICINE
    removeAddedDrugsMedicine(index){
      this.selected_medicine.forEach((element, index) => {
        if(element === this.ciw_data.section3.medicine[index].generic_name_text){
          this.selected_medicine.splice(index, 1)
        }
      })
      this.ciw_data.section3.medicine.splice(index, 1)
      this.ciw_data.status.medicine = true
      this.$emit('change-status')
    },

    // AUTO-COMPUTE FOR TOTAL COST PER MEDICINE
    autoComputeTotalCost(index, quantity, amount){
      this.ciw_data.section3.medicine[index].total_cost_per_medicine = this.checkFormat(quantity * amount)
      this.ciw_data.status.medicine = true
      this.$forceUpdate(); 
      this.$emit('change-status')
    },

    // ADD ATTACHED FILE FOR MEDICINE
    addAttachedMedicine(){
      let attached_files = []
      let re_attached_files = []
      this.new_medicine_status = true

      this.ciw_data.section3.attachments.forEach(element => {
        attached_files.push(element.name)
      })

      this.view_attached_medicine.forEach(element => {
        attached_files.push(element.name)
      })

      Object.values(this.$refs.medicine.files).forEach(element => {
        if(attached_files.includes(element.name)){
          re_attached_files.push('<br>'+element.name)
        }else{
          this.post_attached_medicine.push(element)
          this.view_attached_medicine.push({
            name: element.name,
            file_size: Number(element.size * 0.00000095367432).toFixed(2),
            file_path: window.URL.createObjectURL(element)
          })
        }
      })

      if(re_attached_files.length > 0){
        let title = 'This file already exist and cannot be attached again.<b>' + re_attached_files + ' </b>'
        this.alert = { display: true, type: 'standard', width: '500', icon: 'mdi-close-circle', color: 'red', title: title, btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'closeAlert' }
      }
    },

    // REMOVE ATTACHED FILE FOR MEDICINE
    removeAttachedMedicine(index, status){
      if(status === 'old'){
        this.ciw_data.section3.attachments[index].loader = true

        this.$axios.post(this.$tms_url+'resources/controller/trn_del_attachment.php', this.$qs.stringify({
          post_data: this.wsDataEncryption(JSON.stringify({
            phic_tracking_number: this.trans_detail.phic_tracking_number,
            transaction_number: this.trans_detail.transaction_number,
            attachment_category: 'MEDICINE',
            file_name: this.ciw_data.section3.attachments[index].file_name
          }))
        }))
        .then(response => {
          if(response.data.success){
            this.ciw_data.section3.attachments.splice(index, 1)
            this.saveData();
          }else{
            this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: 'Something Went Wrong', body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
          }
        })
        .catch(error => {
           this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
        })
      }else{
        this.post_attached_medicine.splice(index - this.post_attached_medicine.length, 1)
        this.view_attached_medicine.splice(index - this.view_attached_medicine.length, 1)
      }
      document.getElementById("attached-medicine").value = "";
    },
    
    // POST ATTACHED FILE TO SERVER OF DRUGS/MEDICINE
    postFileOfMedicine(){
      if(this.post_attached_medicine.length === 0){
        this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-close-circle', color: 'red', title: 'No file chosen. Please attach file', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'closeAlert' }
      }else{
        this.$store.commit('set_prevent_navigation', false)
        this.loading_medicine_attachment = true
        this.new_medicine_status = 'Processing'

        let formData = new FormData()
        let total_count = this.post_attached_medicine.length
        for( var i = 0; i < this.post_attached_medicine.length; i++ ){
          let file = this.post_attached_medicine[i]
          formData.append('file'+ i +'', file)
        }

        formData.append('post_data', this.wsDataEncryption(JSON.stringify({
          phic_tracking_number: this.trans_detail.phic_tracking_number,
          transaction_number: this.trans_detail.transaction_number,
          provider_user: this.$store.state.usr_credentials.user_name,
          department: this.$store.state.usr_credentials.department,
          provider_code: this.$store.state.prv_data.provider_code,
          provider_tin: this.$store.state.prv_data.provider_tin,
          attachment_category: 'MEDICINE',
          request_key: 'phic_patient_prov_attachments',
          hmo_host_code: this.trans_detail.hmo_host_code,
          total_count: total_count
        })))

        this.$axios.post(this.$tms_url+'resources/controller/trn_upd_inpatient_ciw.php', 
          formData,
          {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
        )
        .then(response => {
          if(response.data.success){         
            this.responseDataDecryption(response.data.file_path).forEach(element => {
              let no_of_file = element.file_name.split('_')[0]
              let provider = this.$store.state.prv_data.provider_tin ? this.$store.state.prv_data.provider_tin : this.$store.state.prv_data.provider_code
              let sum = no_of_file.length + 8 + provider.length + this.trans_detail.transaction_number.length + 4

              element.name = element.file_name.substring(sum)
              element.loader = false
  
              this.ciw_data.section3.attachments.push(element)
            })
            
            this.new_medicine_status = false
            this.post_attached_medicine = []
            this.view_attached_medicine = []
            this.loading_medicine_attachment = false
            this.$store.commit('set_prevent_navigation', true)
            this.saveData();
          }else{
            this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: 'Something Went Wrong', body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
          }
        })
        .catch(error => {
           this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
        })
      }
    },

    // CHECK FORMAT
    checkFormat(value){
      if(value){
        value = value.toLocaleString()

        if(value.toLocaleString().includes('.')){
          if(value.toLocaleString().includes(',')){
            return value
          }else{
            return value.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
          }
        }else{
          if(value.toLocaleString().includes(',')){
            return value+'.00'
          }else{
            return value.toString().replace(/,/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")+'.00'
          }
        }
      }else{
        return '0.00'
      }
    },

    // PREVENT USER FROM TYPING LETTERS IN TEXT FIELD
    numberOnly(event){
      if ((event.which < 48 || event.which > 57) && event.which !== 45){
        event.preventDefault();
      }
    },

    // DISPLAY COMMENT DATA
    displayCommentData(data){
      if(data === 'ciw'){
        this.comment_title = 'COURSE IN THE WARD'
        this.comment_content = this.comment_data.cf4_part4
      }else if(data === 'surgical'){
        this.comment_title = 'SURGICAL PROCEDURE'
        this.comment_content = this.comment_data.cf4_part4_1
      }else if(data === 'medicine'){
        this.comment_title = 'DRUGS/MEDICINE'
        this.comment_content = this.comment_data.cf4_part5
      }else{
        this.comment_title = 'OUTCOME OF TREATMENT'
        this.comment_content = this.comment_data.cf4_part6
      }
      this.comment_dialog = true
    },

    // CHECK IF DATA HAS BEEN CHANGED
    checkDataStatus(data){
      this.$emit('change-status')
      if(data === 'doctors'){
        this.doctors_order.status = true
        this.empty_doctors = ''

        this.doctors_order.data.forEach(element => {
          if(element.date === '' && element.doctors_order !== ''){
            this.empty_doctors = 'empty'
          }
        })
      }else{
        this.ciw_data.status.outcome = true
      }

      this.$emit('input', [this.empty_doctors, this.unsaved_surgical, this.unsaved_medicine])
    },

    // SAVE DATA TO SESSION STORAGE
    saveData(){
      sessionStorage.setItem('LG4S04', this.$crypto.AES.encrypt(JSON.stringify(this.doctors_order), '5s05SLFI'))
      sessionStorage.setItem('PORT4D', this.$crypto.AES.encrypt(JSON.stringify(this.ciw_data), 'X4d3r5fS'))
      sessionStorage.setItem('LYK56D', this.$crypto.AES.encrypt(JSON.stringify(this.pci_data), 'XLgopi4x'))
    }
  },

  destroyed(){
    this.saveData();
  }
}
</script>

<style scoped>
th{
  border: 0;
}
td{
  cursor: default;
  padding: 0 3px;
  text-align: left;  
  border: 0px;  
}
.outcome-treatment{
  width: 20%;
}
.table-overflow-x{
  border: 2px solid #dedede; 
  border-radius: 4px;
  margin-top: 4px;
  overflow-x: auto; 
  overflow-y: hidden; 
  padding: 0 6px;
}
.table-overflow-x table{
  min-width: 1000px;
  width: 100%; 
}
</style>