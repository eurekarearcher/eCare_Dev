<template>
  <div v-resize="onResize" id="print">
    <v-layout wrap justify-center>
      <v-row v-if="show_content"> 
        <v-col cols="12" sm="12" md="8" lg="8" offset-md="2" offset-lg="2"> 
            <v-card>
              <v-card-title class="primary white--text justify-center d-print-none">
                  <span v-if="process == 'ISSUE CARD'"><v-icon size="25" left dark>mdi-card-account-details</v-icon>Generated Card</span>
                  <span v-else><v-icon size="25" left dark>mdi-qrcode</v-icon>Generate QR</span>
              </v-card-title>

              <v-layout wrap class="space-around" >
                <v-sheet :width="384" :max-width="384" class="relative elevation-3 mx-auto" id="front" >
                  <v-img src="@/assets/front-card.png" lazy-src="@/assets/front-card.png"></v-img>
                  <div class="mt-2 absolute" style="top: 10px; left: 22px; width: 85%;">
                    <div class="d-flex align-start justify-space-between">
                      <h3 class="health-card-title text-center mt-1 ml-n2" style="width: 200px;"> {{ getCardTitle(this.$store.state.prv_data.healthcard_id) }} </h3>
                      <div class="d-flex justify-center align-center mt-n2"> 
                        <v-img v-if="this.$store.state.prv_config.card_logo" :src="this.$store.state.prv_config.card_logo" :lazy-src="this.$store.state.prv_config.card_logo" class="mx-2" height="42" width="42" id="card-logo" contain> </v-img>
                        <v-img v-if="this.$store.state.prv_config.provider_logo" :src="this.$store.state.prv_config.provider_logo" :lazy-src="this.$store.state.prv_config.provider_logo" class="mx-2" height="42" width="42" id="provider-logo" contain> </v-img>
                      </div>
                    </div> 
                  </div>  

                  <v-layout wrap :class="['position-card-view','absolute']" style="width:100%">
                    <div class="d-flex justify-space-between align-start" style="width: 92%;"> 
                      <div>
                          <v-img v-if="!member_data.mem_photo.includes('null') && member_data.mem_photo.length != 0" :src="member_data.mem_photo" alt="Avatar" :width="150" :height="180"  style="border-right:4px solid #312f2f; border-bottom:4px solid #312f2f" ></v-img>
                          <v-img v-else src="@/assets/no-image.jpg" alt="Avatar" :width="150" :height="180"  style="border-right:4px solid #312f2f; border-bottom:4px solid #312f2f" ></v-img>
                      </div>
                      <div class="text-center" :class="validate_member_name" style="width: 50%;"> 
                          <h6 :class="['font-title-view', 'patient-name text-uppercase font-weight-bold mb-1 pr-1']">{{member_data.full_name}}</h6>
                          <h6 :class="['font-subtitle-view', 'font-weight-regular']">{{member_data.ek_lgu_id}}</h6>
                          <h6 :class="['font-subtitle-view', 'font-weight-regular']">{{ get_provider_type }}</h6>
                      </div>
                    </div>
                  </v-layout>
                  <div v-if="this.$store.state.prv_data.municipality === 'PAGBILAO'" class="absolute" style="bottom: 0; right: 0; padding: 5px;"> 
                    <v-img src="@/assets/card-logo/quezon/pagbilao/footer-icon.png" alt="footer-icon" width="55"></v-img>
                  </div>
                </v-sheet>
                <v-sheet :width="384" :max-width="384" class="relative elevation-3 mx-auto" id="back">
                  <div class="mt-3 absolute" style="top: 4px; left: 22px; z-index: 1;">
                      <h3 class="health-card-title" style="width: 200px;"> {{ getCardTitle(this.$store.state.prv_data.healthcard_id) }} </h3>
                  </div>
                  <h6 :class="['font-subtitle-view', 'font-italic', 'date-released']"> Released Date: {{ formatDate(date_released) }} </h6>
                  <v-img src="@/assets/back-card.png" lazy-src="@/assets/back-card.png"></v-img>
                  <div class="mt-4 absolute" style="top: 38px; left: 162px; z-index: 1; width: 214px;"> 
                    <div class="card-back-text font-weight-medium d-flex justify-start">
                      <span class="pr-1"> 1. </span> 
                      <div> 
                        Presenting your {{ getCardTitle(this.$store.state.prv_data.healthcard_id) }} with QR code
                        to be scanned provides consent for authorized
                        government personnel or an accredited healthcard
                        provider to access your personal information and
                        medical records.
                      </div>
                    </div>
                    <div class="card-back-text font-weight-medium d-flex justify-start"> 
                      <span class="pr-1"> 2. </span> 
                      This {{ getCardTitle(this.$store.state.prv_data.healthcard_id) }} with QR Code are
                      non transferable.
                    </div>  
                    <div class="card-back-text font-weight-medium d-flex justify-start"> 
                      <span class="pr-1"> 3. </span> 
                      Maintain cleanliness of the card. Do not fold.
                    </div>
                    <div class="card-back-text font-weight-medium d-flex justify-start"> 
                      <span class="pr-1"> 4. </span> 
                      If found, please return to the nearest Barangay Health Station, Rural Health Unit, or Municipal Health Office.
                    </div>
                  </div>
                  <QrcodeVue v-if="qr_value" :value="qr_value" :size="130" :class="['position-card-view', 'absolute']" renderAs="svg" id="qrCode"/>
                </v-sheet>
              </v-layout>
            </v-card>
            <v-layout wrap class="d-print-none justify-end mt-5 mb-3">
              <v-btn v-if="process === 'REGISTRATION' || process === 'ADD HOUSEHOLD'" @click="validateSaveSelected" color="#367c9d" :loading="save_pdf_loader"  class=" px-5 mr-3" tile dark  small> SAVE CARD  <v-icon small right>mdi-download-circle</v-icon></v-btn>
              <v-btn @click="printQr" color="#367c9d"  class="white--text px-5" :disabled="save_pdf_loader" tile small> PRINT CARD  <v-icon small right>mdi-printer</v-icon></v-btn>
            </v-layout>

            <div :class="[{'fixed' : is_fixed}, 'd-print-none']">
              <v-divider></v-divider>
              <v-layout wrap class="justify-end mt-2 mb-3" >
                <div v-if="process === 'ISSUE CARD'">
                  <v-btn :disabled="loading_release" @click="$router.push('/code-scanning')" class="mr-3" color="primary" outlined tile>CANCEL</v-btn>
                  <v-btn :loading="loading_release" @click="isCardPrintedAlready" color="primary" tile>ISSUE CARD <v-icon right>mdi-arrow-right</v-icon> </v-btn>
                </div>
                <v-btn v-else-if="process === 'REPORT LOST CARD'" @click="confirmationAlert('lost_card')" class="px-6" color="primary">ISSUE NEW CARD<v-icon right>mdi-card-account-details</v-icon> </v-btn>
                <v-btn v-else @click="confirmationAlert('registration')" class="px-6 mr-2" color="primary">PROCEED<v-icon right>mdi-arrow-right</v-icon> </v-btn>
              </v-layout>
            </div>
        </v-col>
      </v-row>
  
      <v-row v-else>
        <v-col cols="12" sm="12" md="8" lg="8" offset-md="2" offset-lg="2"> 
          <v-card  class="my-2 mx-2">
              <v-skeleton-loader   type="card-heading, divider, card-actions"></v-skeleton-loader>
              <v-layout wrap class="py-4">
                <v-row v-for="item in 2" :key="item" id="front" dense no-gutters> 
                  <v-col col="6"  class="pa-4"> 
                    <v-skeleton-loader type="image"></v-skeleton-loader>
                  </v-col>
                </v-row>
              </v-layout>
              <v-skeleton-loader type="actions"></v-skeleton-loader>
          </v-card>
        </v-col>
      </v-row>
    </v-layout>

     <!-- CONFIRMATION -->
    <v-dialog v-if="confirmation_alert" v-model="confirmation_alert"  width="450" persistent>
      <v-card class="text-center py-5 px-8">
        <v-form @submit.prevent="validateCardSelection" v-model="form_is_valid" ref="form">
          <v-card-title class="justify-center">
            <v-icon color="primary" size="80">mdi-help-circle</v-icon>
          </v-card-title>
          <h3 class="grey--text text--darken-2 font-weight-regular mb-5">Has the card been Printed / Issued?</h3>

          <v-sheet class="ml-10">
              <v-radio-group v-model="selection_group" :disabled="confirmation_loader" :rules="field_rules">
                <v-radio label="Printed and Issued" value="1"></v-radio>
                <v-radio label="Printed but Not Issued" value="2"></v-radio>
                <v-radio label="Not yet Printed" value="3"></v-radio>
              </v-radio-group>
          </v-sheet>
        
          <v-card-actions class="justify-center mt-5">
              <v-btn @click="confirmation_alert = false, selection_group = ''" type="button" :disabled="confirmation_loader" color="primary" outlined class="pa-5 px-5 mr-5" >Cancel</v-btn>
              <v-btn type="submit" :loading="confirmation_loader" color="primary" class="pa-5 px-7 ml-5">SUBMIT</v-btn>
          </v-card-actions>
        </v-form>
      </v-card>
      
    </v-dialog>


    <Alert :alert="alert" @homepage="homepage" @changeSessionData="changeSessionData" @confirmReleaseCard="confirmReleaseCard" @printBeforeReleasing="printBeforeReleasing" @releaseCard="releaseCard" @redirectUser="$emit('redirect')" @lostCardEndProcess="lostCardEndProcess"/>
  </div>
</template>

<script>
import html2canvas from 'html2canvas'
import jsPDF from 'jspdf'

import QrcodeVue from 'qrcode.vue'
import Alert from '@/components/Alert.vue'

export default {
  components: {Alert, QrcodeVue},
  props: ['process'],
  data() {
    return {
      member_data: sessionStorage.getItem("9xgF732sfgh") ? JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem("9xgF732sfgh"), "njGHDdd").toString(this.$crypto.enc.Utf8) ) : {},

      qr_value: '',
      alert:'',
      show_content: false,
      confirmation_alert:false,

      selection_group: '',
      confirmation_loader: false,
      loading_release: false,

      save_pdf_loader: false,

      form_is_valid: false,
      field_rules: [v => !!v && !/^ *$/.test(v) || 'Field is required.'],

      //FOR RESIZE
      windowSize: {x: 0,y: 0},
      is_fixed: true,
      date_released: Date.now(),
      card_ratio: '',
      provider_logo: ''
    }
  },
  
  mounted() {
    this.checkProcess()
  },
  
  computed: {
    validate_member_name() {
      if (this.member_data.full_name.length >= 34 ) return 'name_position'
      return ''
    },

    get_provider_type() {
      if(this.$store.state.usr_credentials.lgu_host_code === 'BT') {
        return 'Dinalupihan, Bataan'
      } else if(this.$store.state.usr_credentials.lgu_host_code === 'AT') {
        return 'Antipolo'
      } else {
        return ''
      }
    }
  },

  methods: {
    checkProcess() {
      if (this.process === 'REPORT LOST CARD') {
        if (this.member_data.has_alert_clicked) return this.encryptUserData(true)
        let alert_title = `<h4 class="font-weight-light body-1">Previous Card Has Been <br/><span class="text-capitalize font-weight-medium text-h6">DEACTIVATED</span></h4>`
        return this.alert = {display: true, type: 'standard', width: '650',icon: 'mdi-alert-circle',color: 'primary',title: alert_title,body: 'A New QR Code has been generated for this member.', btn_pry_txt: 'Proceed in Card Printing',btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'closeAlert',btn_pry_emt: 'changeSessionData', btn_pry_params: 'for_lost_card',}
      }
      return this.encryptUserData();
    },

    changeSessionData(action) {
      let session_data = {}
      if (action == 'for_lost_card') session_data = {...this.member_data, ...{has_alert_clicked: true}}
      
      this.member_data = session_data
      sessionStorage.setItem('9xgF732sfgh', this.$crypto.AES.encrypt(JSON.stringify(session_data), 'njGHDdd'))
      this.encryptUserData()
    },
    
    encryptUserData() {
      this.qr_value = this.wsDataEncryption(`EKSYSTEM>${this.member_data.ek_lgu_id}-${this.member_data.current_card_key}-W`)
      this.show_content = true
    },

    confirmationAlert(type) {
      if (type == 'lost_card')return this.alert = {display: true,  type: 'standard', width: '450',  icon: 'mdi-help-circle',  color: 'primary',  title: 'Is the card printed already?',  body: '',  btn_pry_txt: 'No',  btn_pry_color: 'primary',  btn_pry_otl: true, btn_pry_act: 'closeAlert',  btn_sec_txt: 'Yes',  btn_sec_color: 'primary',  btn_sec_otl: false,  btn_sec_act: 'closeAlert', btn_sec_emt:'lostCardEndProcess'}
      this.confirmation_alert = true
    },

    lostCardEndProcess() {
      let alert_title = `<h4 class="font-weight-light body-1">New Card for <br/><span class="text-capitalize font-weight-medium text-h6">${this.member_data.full_name.toLowerCase()} / ${this.member_data.birthdate}</span> <br/>has been issued and activated</h4>`
      return this.alert = {
        display: true,
        type: 'standard',
        width: '600',
        icon: 'mdi-check-circle',
         color: 'success',
         title: alert_title,
         body: '',
         btn_pry_txt: 'Proceed to Homepage',
         btn_pry_color: 'success',
         btn_pry_otl: false,
         btn_pry_act: 'closeAlert',
         btn_pry_emt: 'redirectUser'
        }
    },

    async validateCardSelection() {
      if (!this.form_is_valid)  return this.$refs.form.validate()

      this.confirmation_loader = true
      let card_released = '0', is_card_ready = '2'
      if (this.selection_group == '1') is_card_ready = '1', card_released = '1'
      if (this.selection_group == '2') is_card_ready = '1', card_released = '0'

      // CREATE FUNCTION FOR CALLING A CONTROLLER
      let response = await this.$services.wsMemberWeb({
        key:"eurekare_key_web",
        data: {
            command: "322101005",
            data: {
              ek_lgu_id:this.member_data.ek_lgu_id,
              current_card_key: this.member_data.current_card_key,
              is_card_ready: is_card_ready,
              is_card_released: card_released,
              updated_by: this.$store.state.usr_credentials.user_name
          }
        }
      })

      if(response.status === 200) {
        if (!response.data.status) {
          return this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: 'Something Went Wrong', body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' } 
        }
        this.member_data.step = this.process === 'REGISTRATION'? 6 : 5
        sessionStorage.setItem('9xgF732sfgh', this.$crypto.AES.encrypt(JSON.stringify(this.member_data), 'njGHDdd'))
        this.$emit('change-step', this.member_data.step)
      } else {
        this.alert = response.error
      }
    },

    isCardPrintedAlready(){
      this.alert = { display: true, type: 'standard', width: '450', icon: 'mdi-help-circle', color: 'primary', title: 'Is the card printed already?', body: '', btn_pry_txt: 'NO', btn_pry_color: 'grey darken-2', btn_pry_otl: true, btn_pry_act: 'closeAlert', btn_pry_emt: 'printBeforeReleasing', btn_sec_txt: 'YES', btn_sec_color: 'primary', btn_sec_otl: false, btn_sec_act: 'closeAlert', btn_sec_emt: 'confirmReleaseCard' }
    },

    printBeforeReleasing(){
      this.alert = { display: true, type: 'standard', width: '450', icon: 'mdi-alert-circle', color: 'red', title: 'Please print the card before releasing', body: '', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'closeAlert' }
    },

    confirmReleaseCard(){
      this.alert = { display: true, type: 'standard', width: '450', icon: 'mdi-help-circle', color: 'primary', title: 'This card will be issued to the member', body: 'Please confirm if you want to proceed', btn_pry_txt: 'CANCEL', btn_pry_color: 'grey darken-2', btn_pry_otl: true, btn_pry_act: 'closeAlert', btn_sec_txt: 'CONFIRM', btn_sec_color: 'primary', btn_sec_otl: false, btn_sec_act: 'closeAlert', btn_sec_emt: 'releaseCard' }
    },

    async releaseCard(){
      this.loading_release = true
      let response = await this.$services.wsMemberWeb({
        key: 'eurekare_key_web',
        data: {
          command: 322101005,
          data: {
            ek_lgu_id: this.member_data.ek_lgu_id,
            current_card_key: this.member_data.current_card_key,
            is_card_ready: '1',
            is_card_released: '1',
            updated_by: this.$store.state.usr_credentials.user_name
          }
        }
      })

      if(response.status === 200) {
        if(response.data.status){
          let title = `Card for <span class="font-weight-medium text-uppercase">${this.member_data.full_name} ${this.formatDate(this.member_data.birthdate)}</span> has been issued and activated</b>`
          this.alert = { display: true, type: 'standard', width: '500', icon: 'mdi-check-circle', color: 'success', title: title, body: '', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'closeAlert' , btn_pry_emt: 'redirectUser' }
          
        }else{
          this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: 'Something Went Wrong', body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' } 
        }
      } else {
        this.alert = response.error
      }
    },
    
    validateSaveSelected() {
      this.save_pdf_loader = true
      this.saveCard();
    },

    //GET THE EXACT HEIGHT AND WIDTH OF THE PROVIDER AND CARD LOGO AND GET ITS RATIO
    loadCardLogoImage() {
      const img = new Image();
      img.src = this.$store.state.prv_config.card_logo;

      img.onload = () => {
        this.card_ratio = img.width / img.height;
      };
    },

    loadProviderLogoImage() {
      const img = new Image();
      img.src = this.$store.state.prv_config.provider_logo;

      img.onload = () => {
        this.provider_ratio = img.width / img.height;
      };
    },

    async saveCard() {
      await this.loadCardLogoImage();
      await this.loadProviderLogoImage();
      
      html2canvas(document.getElementById('qrCode'), { allowTaint: false, scale: 5}).then(canvas => {
          let qr_image = canvas.toDataURL()
          const doc = new jsPDF('p', 'in', [4,6]);
          // FRONT CARD
          //doc.addImage(require(`@/assets/${this.get_provider_type === 'Antipolo'? 'front-card-antipolo.png':'front-card-bataan.png'}`), "PNG", 0 , 0, 4, 3);
          doc.addImage(require('@/assets/front-card.png'), "PNG", 0 , 0, 4, 3);
          doc.setFontSize(11)
          doc.setTextColor(1, 1, 101)
          doc.setFont('Helvetica', 'bold');
          let card_title = doc.splitTextToSize(this.getCardTitle(this.$store.state.prv_data.healthcard_id), 2.2)
          
          doc.text(1.1, 0.45, card_title, 'center')
          if(this.$store.state.prv_config.card_logo !== '' && this.$store.state.prv_config.card_logo !== null) {
            this.loadCardLogoImage();
            let card_height, card_width;
            
            // RECTANGULAR LOGOS
            if (this.card_ratio  > 1) {
              card_width = 0.7; 
              card_height = 0.4;
            }
            // CIRCULAR OR SQUARE
            else{
              card_width = 0.4; 
              card_height = 0.4;
            }

            doc.addImage(this.$store.state.prv_config.card_logo, "PNG", 2.3, 0.25, card_width, card_height);
          }
        
          if(this.$store.state.prv_config.provider_logo !== '' && this.$store.state.prv_config.provider_logo !== null) {
            this.loadProviderLogoImage();
            let provider_height, provider_width 

            // RECTANGULAR LOGOS
            if (this.provider_ratio > 1) {
              provider_width = 0.7; 
              provider_height = 0.4;
            }
            // CIRCULAR OR SQUARE
            else{
              provider_width = 0.4; 
              provider_height = 0.4;
            }

            //doc.addImage(this.$store.state.prv_config.provider_logo, "PNG", 3.1 , 0.25, 0.4, 0.4);
            doc.addImage(this.$store.state.prv_config.provider_logo, "PNG", 3.1, 0.25, provider_width, provider_height);
          }

          if (this.member_data.mem_photo) {
            doc.addImage(this.member_data.mem_photo, "PNG", 0.28 , 0.8, 1.5, 1.85);
          } else {
            doc.addImage(require('@/assets/no-image.jpg'), "PNG", 0.28 , 0.8, 1.5, 1.85);
          }
          doc.setTextColor(0, 0, 0)
          doc.setLineWidth(0.04)
          doc.line(1.80, 0.795, 1.80, 2.65 )
          doc.line(0.27,2.65,1.82,2.65)

          let height = 1.28, id_height = 2, location_height = 2.15
          const names = (this.member_data.full_name.replace(/\s+/g,' ').trim()).toUpperCase()
          const member_name =  doc.splitTextToSize(names, 2.5);

          if (doc.getTextDimensions(member_name).h <= 0.2222222222222222) height = 1.3, id_height = 1.48, location_height = 1.65
          if (doc.getTextDimensions(member_name).h > 0.2222222222222222 && doc.getTextDimensions(member_name).h <= 0.47777777777777775) height = 1.3, id_height = 1.65, location_height = 1.8
          if (doc.getTextDimensions(member_name).h > 0.47777777777777775 && doc.getTextDimensions(member_name).h <= 0.7333333333333333) height = 1.28, id_height = 1.8, location_height = 1.95
          doc.setFontSize(9.5);
          doc.setFont('Helvetica', 'bold');
          doc.text(2.93, height, member_name, 'center');

          doc.setFontSize(7.5);
          doc.setFont('Helvetica', 'normal');
          doc.text(2.93, id_height, this.member_data.ek_lgu_id, 'center')
          doc.text(2.93, location_height, this.get_provider_type, 'center')

          if (this.$store.state.prv_data.municipality === 'PAGBILAO') {
            doc.addImage(require('@/assets/card-logo/quezon/pagbilao/footer-icon.png'), "PNG", 3.3 , 2.8, 0.6, 0.2);
          }

          // BACK CARD
          doc.addImage(require('@/assets/back-card.png'), "PNG", 4 , 0, 4, 3, '', '', 180);
          doc.addImage(qr_image, "PNG",  3.75 , 2.4, 1.35, 1.4, '', '', 180);
          doc.setFontSize(6);
          doc.setTextColor(0, 0, 0)
          let text_height = 5.3

          let back_card_text_one = doc.splitTextToSize(`Presenting your ${this.getCardTitle(this.$store.state.prv_data.healthcard_id)} with QR Code to be scanned provides consent for authorized government personnel or an accredited healthcard  provider to access your personal information and medical records.`, 2) 
          doc.text(back_card_text_one, 2.2, text_height, 180, 180)
          doc.text('1. ', 2.3, text_height, 180, 180)

          if(doc.getTextDimensions(back_card_text_one).h >= 0.4) {
            text_height = text_height - 0.55
          } else {
            text_height = text_height - 0.35
          }
          
          let back_card_text_two = doc.splitTextToSize(`This ${this.getCardTitle(this.$store.state.prv_data.healthcard_id)} with QR Code are non transferable. `, 2)
          doc.text(back_card_text_two, 2.2, text_height, 180, 180)
          doc.text('2. ', 2.3, text_height, 180, 180)
          text_height = text_height - 0.25
          let back_card_text_three = doc.splitTextToSize('Maintain cleanliness of the card. Do not fold.', 2)
          doc.text(back_card_text_three, 2.2, text_height, 180, 180)
          doc.text('3. ', 2.3, text_height, 180, 180)
          text_height = text_height - 0.15
          let back_card_text_four = doc.splitTextToSize('If found, please return to the nearest Barangay Health Station, Rural Health Unit, or Municipal Health Office.', 2)
          doc.text(back_card_text_four, 2.2, text_height, 180, 180)
          doc.text('4. ', 2.3, text_height, 180, 180)
          doc.setFontSize(4.5);
          doc.setTextColor(0, 0, 0)
          doc.text("Released Date: " + this.formatDate(this.date_released), 1, 5.7, 180, 180)

          doc.setFontSize(12);
          doc.setTextColor(1, 1, 101)
          doc.setFont('Helvetica', 'bold');
          doc.text(card_title, 3.8, 5.7, 180, 180)

          return doc.save(`${(this.member_data.mem_last_name + ' ' + this.member_data.mem_first_name)}-${this.member_data.birthdate}.pdf`)
      }).finally(() => {
        this.save_pdf_loader = false
      }).catch(error => {
        return this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'closeAlert' }
      })
    },
  
    printQr() {
      window.print()
    },

    homepage() {
      sessionStorage.clear();
      this.$router.push('/code-scanning')
    },

    //FILTERING FOR CARD TITLE
    getCardTitle(value) {
      return value + ' ' + 'HEALTHCARE CARD'
    },

    // FOR RESPONSIVENESS OF IMAGE SIZES
    onResize() {
        this.windowSize = { x: window.innerWidth, y: window.innerHeight };
        if (this.windowSize.x > 1904) {
          this.is_fixed = true
        } else if (this.windowSize.x > 1480 && this.windowSize.x < 1904) {
          this.is_fixed = true
        } else if (this.windowSize.x > 960 && this.windowSize.x < 1480) {
          this.is_fixed = false
        } 
    },
  }
}
</script>

<style scoped>
.relative{
  position: relative;
}

.absolute {
  position: absolute;
}

.fixed {
  position: fixed;
  bottom: 60px;
  width:60%;
}

.position-card-view {
  top:75px;
  left:25px;
}

.font-title-view{
  color: #312f2f;
  font-size:11.5pt; 
  line-height:1.125;
  margin-top:2rem;
  
}

.font-subtitle-view{
  color: #312f2f;
  font-size:8pt;
}

.name_position {
  position: relative;
  top: -15px;
}

.space-around {
    justify-content: space-around;
    padding: 1.2em
}

.date-released{
  font-size: 8px;
  top: 25px;
  right: 10px;
  position: absolute;
  z-index: 1;

}

.health-card-title{
  color: #010165;
  font-size: 14px;
  font-family: Arial, Helvetica, sans-serif;
  font-weight: 600;
}

.card-back-text {
  font-family: Arial, Helvetica, sans-serif;
  color: rgb(26, 26, 26);
  font-size: 8px;
  font-weight: 200;
  word-spacing: 2px;
  line-height: 11px;
}

@media print {
  #print {visibility: hidden}
  #front {visibility: visible}
  #back {visibility: visible; transform: scale(-1, -1);}

  .space-around {
    justify-content: start;
    padding: 0
  }
 
}

</style>

