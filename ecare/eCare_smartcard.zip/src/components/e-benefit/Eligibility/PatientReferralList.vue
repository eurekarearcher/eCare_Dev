<template>
  <div>
    <v-dialog v-if="display_referal" v-model="display_referal"  persistent>
          <v-card>
            <v-card-title class="text-caption text-sm-h6 justify-center light-blue darken-4 white--text">REFERRAL TRANSACTION</v-card-title>

            <v-data-table
              :headers="referal_list_header" 
              :items="referral_data.data" 
              :footer-props="{ 'items-per-page-options': [5, 10, 15, 50] }"   
              :items-per-page="5" 
              :mobile-breakpoint="0" 
              loading-text="Loading Data... Please Wait..." 
              item-key="referral_code" 
              class="elevation-1 text-uppercase mx-5 mb-5 mt-10" 
              sort-desc 
              no-results>
               <template  v-slot:item="{item}"> 
                 <tr> 
                    <td>{{ formatDateAndTime(item.date_of_referral) }}</td>
                    <td>{{ item.referral_code  }}</td>
                    <td>{{ item.referring_doctor_provider_name}}</td>
                    <td>{{ item.referral_doctor_provider_name}}</td>
                    <td>{{ item.doctor_full_name ? item.doctor_full_name : 'N/A' }}</td>
                    <td>{{ item.referral_doctor_specialization}}</td>
                    <td>{{ item.reason_for_referral}}</td>
                    <td class="py-3">
                      <v-btn @click="confirmationReferral(item)" color="primary">Proceed With This Transaction</v-btn>
                    </td>
                </tr> 
               </template>
            </v-data-table>

            <v-card-actions class="d-flex flex-wrap">
              <v-flex pl-3 pt-1 lg4 md4 sm6 xs12 mb-3 class="text-center text-sm-left">
                <v-btn @click="otherTransaction">Continue with different transaction</v-btn> 
              </v-flex>
             </v-card-actions>
          </v-card>
    </v-dialog>

    <v-dialog v-if="confirmation_referral" v-model="confirmation_referral" width="600" persistent>
      <v-card class="pb-2">
          <v-card-title class="justify-center">
            <v-icon color="primary" size="80">mdi-help-circle</v-icon>
          </v-card-title>
          <h3 class="grey--text text--darken-3 text-center font-weight-medium mb-5">Continue with this referred transaction?</h3>

          <div class="px-12 pb-5">
              <h6 class="body-1 font-weight-regular mb-2">Referral Code: <span class="font-weight-medium">{{selected_referral.referral_code}}</span></h6>
              <h6 class="body-1 font-weight-regular mb-2">Date of Referral: <span class="font-weight-medium">{{selected_referral.date_of_referral}}</span></h6>
              <h6 class="body-1 font-weight-regular mb-2">Referral Provider Name: <span class="font-weight-medium">{{selected_referral.referral_doctor_provider_name}}</span></h6>
              <h6 class="body-1 font-weight-regular mb-2">Referral Doctor Name: <span class="font-weight-medium">{{selected_referral.doctor_full_name}}</span></h6>
              <h6 class="body-1 font-weight-regular mb-2">Referral Specialization: <span class="font-weight-medium">{{selected_referral.referral_doctor_specialization}}</span></h6>
              <h6 class="body-1 font-weight-regular mb-0">Reason for Referral: <span class="font-weight-medium"> {{selected_referral.reason_for_referral}} </span></h6>
          </div>

          <v-card-actions class="justify-center mt-5">
            <v-btn @click="cancelSelectedReferral" class="px-5 mx-2" large>Cancel</v-btn>
            <v-btn @click="proceedReferalTransaction" class="px-5 mx-2" color="primary" large>Confirm</v-btn>
          </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
export default {
  props:['ek_lgu_data', 'selected_referral'],

  data() {
    return {
      display_referal: false,
      confirmation_referral: false,
      referal_list_header: [
          { text: 'DATE OF REFERRAL', value: 'date_of_referral',width: 150},
          { text: 'REFERRAL CODE', value: 'referral_code', width: 180},
          { text: 'REFERRED FROM', value: 'referring_doctor_provider_name', width: 250},
          { text: 'REFERRAL PROVIDER NAME', value: 'referral_doctor_provider_name', width: 250},
          { text: 'REFERRAL DOCTOR', value: 'doctor_full_name', width: 200},
          { text: 'REFERRAL DOCTOR SPECIALIZATION', value: 'referral_doctor_specialization',  width: 200},
          { text: 'REASON FOR REFERRAL', value: 'reason_for_referral', width:300},
          { text: 'Action', value: '', width: 150}
      ],
    
      referral_data: sessionStorage.getItem('R2GSXfkF') ? JSON.parse(this.$crypto.AES.decrypt(sessionStorage.getItem('R2GSXfkF'), 'lfFo34sf').toString(this.$crypto.enc.Utf8)) : {
        fresh_load: true,
        has_data: false,
        data: [],
      },
    }
  },

  methods: {
    // FOR CALLING THE PATIENT'S LIST OF REFERRAL TRANSACTIONS
    async validateUserHasReferral() {
      if (this.referral_data.fresh_load) {
        let response = await this.$services.getPatientReferralTransaction({
          ek_lgu_id: this.ek_lgu_data.ek_lgu_id
        })

        if(response.status === 200) {
          if (response.data === 'No Data') {
            this.referral_data.fresh_load = false
            this.referral_data.has_data   = false
            this.$emit('has-referral-data', this.referral_data.has_data)
            sessionStorage.setItem('R2GSXfkF', this.$crypto.AES.encrypt(JSON.stringify(this.referral_data), 'lfFo34sf'))
            return 
          }

          response.data = this.responseDataDecryption(response.data)
          this.referral_data.data = response.data.map(items => {
            if (items.referral_doctor_first_name || items.referral_doctor_middle_name  || items.referral_doctor_last_name) {
              items.doctor_full_name = `DR. ${items.referral_doctor_first_name || ''} ${items.referral_doctor_middle_name || ''} ${items.referral_doctor_last_name || ''}`
            } else {
              items.doctor_full_name = ''
            }
            return items
          })
  
          this.loading_data = false
          this.display_referal = true
          this.referral_data.has_data   = true
          this.referral_data.fresh_load = false
          this.$emit('has-referral-data', this.referral_data.has_data)
          sessionStorage.setItem('R2GSXfkF', this.$crypto.AES.encrypt(JSON.stringify(this.referral_data), 'lfFo34sf'))
          return 
        }
      } else {
        this.$emit('has-referral-data', this.referral_data.has_data)
        this.display_referal = this.referral_data.has_data
      }
    },

    // FOR OPENING THE CONFIRMATION DIALOG
    confirmationReferral(item) {
      this.confirmation_referral = true
      this.$emit('change-selected-referral', item)
    },

    // FOR CLOSING THE CONFIRMATION DIALOG 
    cancelSelectedReferral() {
      this.confirmation_referral = false
      this.$emit('change-selected-referral', null)
    },

    // FOR SETTING UP THE SELECTED REFERRAL TRANSACTION TO SESSION STORAGE. THIS ALSO DISABLES OUTPATIENT BUTTON
    proceedReferalTransaction() {
      //REMOVED THE COMMENT IF THE OUTPATIENT AND INPATIENT BUTTON IS UPDATED
      //  if ((this.$store.state.usr_credentials?.provider_reg_type !== 'BRGY' || this.$store.state.usr_credentials?.provider_reg_type !== 'RHU')) {
      //   this.$emit('disabled-outpatient-btn')
      // }
      this.display_referal =  false
      this.confirmation_referral = false
      sessionStorage.setItem('S2GSXfkF', this.$crypto.AES.encrypt(JSON.stringify(this.selected_referral), 'lfFo34sf'))
    },

    // FOR NOT SELECTING ANY REFERRAL TRANSACTION
    otherTransaction() {
      //REMOVED THE COMMENT IF THE OUTPATIENT AND INPATIENT BUTTON IS UPDATED
      // if ((this.$store.state.usr_credentials?.provider_reg_type !== 'BRGY' || this.$store.state.usr_credentials?.provider_reg_type !== 'RHU')) {
      //   this.$emit('enabled-outpatient-btn')
      // }
      this.display_referal =  false
      this.$emit('change-selected-referral', null)
      sessionStorage.removeItem('S2GSXfkF')
    },
  }
}
</script>