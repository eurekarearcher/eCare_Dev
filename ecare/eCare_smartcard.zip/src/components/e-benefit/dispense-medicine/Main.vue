<template>
    <div class="px-sm-9 px-4 pb-2" id="not-for-print">
        <div v-if="$store.state.usr_credentials.user_type === '2-1'">
            <Navbar :navbar="navbar" />
        </div>

        <v-row class="mt-10 mb-4" justify="space-between" align="center" dense  id="not-for-print">
            <v-col cols="12" md="6" lg="6">
                <h2 class="font-weight-medium">Dispensing of Medicine</h2>
            </v-col>

            <v-col cols="12" md="4" lg="4">
                <v-text-field v-model="tbl_search" placeholder="Search" prepend-inner-icon="mdi-magnify" hide-details outlined dense></v-text-field>
            </v-col>
        </v-row>

        <v-data-table :headers="tbl_headers" :items="tbl_items" :loading="tbl_loading" :search="tbl_search" :footer-props="{ 'items-per-page-options': [5, 10, 15, 50] }" :mobile-breakpoint="0" @dblclick:row="viewMedicine" class="elevation-2 mb-5" id="not-for-print">
        </v-data-table>

        <v-dialog v-model="dispense_dialog" max-width="1500" persistent>
            <v-card>
                <ViewMedicine @closeViewMedicine="closeViewMedicine" ref="view" />
            </v-card>
        </v-dialog>

        <Alert :alert="alert" />
    </div>
</template>

<script>
import Navbar from '@/components/Navbar.vue'
import Alert from '@/components/Alert.vue'
import ViewMedicine from '@/components/e-benefit/dispense-medicine/ViewMedicine.vue'

export default {
    components: {
        Navbar,
        Alert,
        ViewMedicine
    },
    
    data() {
        return {
            tbl_loading: true,
            tbl_search: '',
            tbl_headers: [
                { text: 'Date Created', value: 'date_created', width: '150px' },
                { text: 'Transaction Number', value: 'transaction_number', width: '150px', sortable: false },
                { text: 'Patient Name', value: 'patient_name', width: '300px' },
                { text: 'Doctor Name', value: 'doctor_name', width: '300px', sortable: false }
            ],
            tbl_items: [],
        
            navbar: [],
            alert: {},
            dispense_dialog: false,
            data_length: '',
            dispensing_data_length: localStorage.getItem("DLJD92") ? this.$crypto.AES.decrypt(localStorage.getItem("DLJD92"), "jhfg8c7").toString(this.$crypto.enc.Utf8)  : 0
        }
    },

    created() {
        this.getPrescribedMedicineByPID();
        
        if(this.$store.state.usr_credentials.user_type !== '2-1') {
            this.navbar.push(
                {title: "Dispensing of Medicine", link: "/pharmacist/dispensing", icon: "mdi-pill-multiple" },
                { title: "Medicine Inventory", link: "/pharmacist/inventory", icon: "mdi-pill-multiple"},
                { title: "Inventory History", link: "/pharmacist/history", icon: "mdi-history"},
                { title: "Transfer Medicine", link: "/pharmacist/transfer", icon: "mdi-transfer"},
                { title: "Received Medicine", link: "/pharmacist/received", icon: "fas fa-folder" }
            )
        }  else {
            this.navbar.push({ title: 'Home', link: '/code-scanning', icon: 'fas fa-home' })
        }
    },

    methods: {
        async getPrescribedMedicineByPID() {
            let response = await this.$services.getTransactionPrescribedMedicineByPid({
                provider_tin: this.$store.state.prv_data.provider_tin,
                provider_code: this.$store.state.prv_data.provider_code
            })

            if(response.status === 200) {
                response.data = this.responseDataDecryption(response.data)

                if (Array.isArray(response.data)) {
                    this.tbl_items = response.data.map(element => {
                        return {
                            date_created: this.formatDateAndTime(element.date_created),
                            transaction_number: element.transaction_number,
                            patient_name: this.combineString([element.first_name, element.middle_name, element.last_name, element.suffix]),
                            doctor_name: this.combineString([element.doc_first_name, element.doc_middle_name, element.doc_last_name, element.doc_suffix]),
                            patient_address: element.patient_address,
                            patient_age: element.patient_age,
                            date_admitted: element.date_admitted,
                            doctor_prc_license: element.doctor_prc_license,
                            medicines: element.transaction_medicine.map(data => {
                                return {
                                    ...data,
                                    available_to_dispensed: data.total_dispensed_medicine ? data.total_prescribed_medicine - data.total_dispensed_medicine : data.total_prescribed_medicine - 0
                                }
                            })
                        }
                    })
                }
                this.tbl_loading = false
            } else {
                this.alert = response.error
            }
            const current_length = response.data.length;
            this.data_length  = Number(this.dispensing_data_length);

            if (this.data_length !== current_length) {
                const audio = new Audio(require('../../../assets/new_transaction.mp3'));
                audio.play();
            }

            this.dispensing_data_length = current_length;
            localStorage.setItem('DLJD92', this.$crypto.AES.encrypt(JSON.stringify(this.dispensing_data_length), 'jhfg8c7'));
            
            
            setTimeout(() => {
                this.display_add_new_or_delivery = true
            }, 180000)

        },

        viewMedicine(event, {item}) {
            this.dispense_dialog = true;
            this.$nextTick(() => {
                this.$refs.view.openViewMedicine({
                    patient_name: item.patient_name,
                    medicines: item.medicines,
                    transaction_number: item.transaction_number,
                    dispensed_medicine_status: item.dispensed_medicine_status,
                    doctor_name: item.doctor_name,
                    patient_address: item.patient_address,
                    patient_age: item.patient_age,
                    date_admitted: item.date_admitted,
                    doctor_prc_license: item.doctor_prc_license
                });
            });
        },

        closeViewMedicine() {
            this.dispense_dialog = false
        }
    }
}
</script>


<style scoped>
::v-deep .v-dialog {
    box-shadow: none;
}
@media print {
  ::v-deep #not-for-print {
    display: none !important;
  }
}

</style>