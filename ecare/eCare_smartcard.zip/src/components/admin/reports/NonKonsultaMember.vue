<template>
    <div>
        <h2 class="text-center grey--text text--darken-2 my-4">Non-Konsulta Members</h2>
        <v-row justify="space-between" dense>
            <v-col cols="12" sm="6" md="4" lg="3" xl="3">
                <v-text-field v-model="tbl_search" prepend-inner-icon="mdi-magnify" label="Search" maxlength="40" clearable outlined dense></v-text-field>
            </v-col>
            
            <v-col cols="12" sm="5" md="6" lg="7" xl="7" >
                <v-row class="flex-wrap mb-4" dense>
                    <v-col cols="12" sm="4" md="4" lg="3" xl="3">
                        <v-menu :close-on-content-click="false" transition="scale-transition" offset-y>
                            <template v-slot:activator="{ on }">
                                <v-text-field v-on="on" :value="formatDate(start_date)" label="Start Date" hide-details outlined readonly dense></v-text-field>
                            </template>

                            <v-date-picker v-model="start_date" :max="max_start_date && end_date" no-title></v-date-picker>
                        </v-menu>
                    </v-col>

                    <v-col cols="12" sm="4" md="4" lg="3" xl="3" class="pl-sm-2">
                        <v-menu :close-on-content-click="false" transition="scale-transition" offset-y>
                            <template v-slot:activator="{ on }">
                                <v-text-field v-on="on" :value="formatDate(end_date)" label="End Date" hide-details outlined readonly dense></v-text-field>
                            </template>

                            <v-date-picker v-model="end_date" :max="max_start_date" :min="start_date" :disabled="!start_date" no-title></v-date-picker>
                        </v-menu>
                    </v-col>

                    <v-col cols="12" sm="4" md="4" lg="6" xl="6" class="pl-2">
                        <div class="d-flex">
                            <v-btn :disabled="loading_data" @click="getNonKonsultaMembers" class="white--text" color="primary" height="41">
                                <v-icon color="white" left>mdi-update</v-icon>
                                <span>LOAD SELECTED DATES</span>
                            </v-btn>
                        </div>
                    </v-col>
                </v-row>
            </v-col>

            <v-col class="d-flex justify-end mt-1 mb-2 " cols="12" sm="6" md="3" lg="2" xl="2">
                <label class="mt-2">EXPORT:</label>
                <v-btn @click="exportToExcel" class="ml-3" color="success"><v-icon left>mdi-microsoft-excel</v-icon> Excel</v-btn>
            </v-col>
        </v-row>

        <v-data-table 
            :headers="tbl_headers" 
            :items="tbl_items" 
            :loading="tbl_loading" 
            :footer-props="{ 'items-per-page-options': [5, 10, 15, 50, 100] }" 
            :search="tbl_search" 
            :sort-desc.sync="sort_descending" 
            class="elevation-2 mt-n2" 
            mobile-breakpoint="0"
        >
        </v-data-table>
    </div>
</template>

<script>
export default {
    data(){
        return{
            start_date: this.$moment(this.$moment().subtract(1, 'months')).format('YYYY-MM-DD'),
            end_date: this.$moment().format('YYYY-MM-DD'),
            max_start_date: this.$moment().format('YYYY-MM-DD'),

            // TABLE
            tbl_loading: true,
            tbl_search: '',
            tbl_headers: [
                { text: 'DATE CREATED', value: 'date_created', width: '200px' },
                { text: 'PATIENT NAME', value: 'patient_name', width: '300px' },
                { text: 'AGE', value: 'age', width: '100px'},
                { text: 'BIRTHDAY', value: 'birthdate', width: '150px', sortable: false },
                { text: 'GENDER', value: 'gender', width: '150px', sortable: false },
                { text: 'CONTACT NUMBER', value: 'mobile_number', width: '150px', sortable: false },
                { text: 'EMAIL', value: 'email', width: '200px', sortable: false }
            ],
            tbl_items: [],
            sort_descending: true,
            loading_data: false,
            all_non_konsulta_members: []
        }
    },

    created() {
        this.getNonKonsultaMembers(false)
    },

    methods: {
        // GET NON KONSULTA MEMEBERS
        async getNonKonsultaMembers(filter = true) {
            this.loading_data = true;
            this.tbl_loading = true; 
            let response = await this.$services.getNonKonsultaMembers({
                provider_code: this.$store.state.prv_data.provider_code,
                lgu_host_code: this.$store.state.usr_credentials.lgu_host_code,
                start_date: this.start_date,
                end_date: this.end_date
            })

            if(response.status === 200) {
                if(response.data){
                    let non_konsulta_members = this.responseDataDecryption(response.data);
                    non_konsulta_members.sort((a, b) => new Date(b.date_created) - new Date(a.date_created))
                    non_konsulta_members.forEach((element) => {
                    element.date_created = this.formatDateAndTime(element.date_created)
                    element.age = this.calculateAge(element.birthdate)
                    });

                    this.all_non_konsulta_members = non_konsulta_members; 
                    // Non konsulta if filtered by date range
                    if (filter) {
                        let filter_start_date = new Date(this.start_date);
                        let filter_end_date = new Date(this.end_date);
                        // Ensure that endDate includes the whole day by setting the time to the end of the day
                        filter_end_date.setHours(23, 59, 59, 999);
    
                        this.tbl_items = non_konsulta_members.filter(item => {
                            let item_date = new Date(item.date_created);
                            return item_date >= filter_start_date && item_date <= filter_end_date;
                        });
                    } else {
                        //Non Konsulta Member onload
                        this.tbl_items = non_konsulta_members
                    }
                }else{
                    this.tbl_items = []
                }
                this.tbl_loading = false
                this.loading_data = false
            } else {
                this.alert = response.error
            }
        },

        // Button click handler to load selected date range
        loadSelectedDates() {
            this.getNonKonsultaMembers(true)
        },

        // EXPORT TO EXCEL
        exportToExcel(){
            let date = this.$moment().format('MM-DD-YYYY')
            let style = {
                align: 'center',
                alignVertical: 'center',
                borderColor: '#000000',
                type: String,
                wrap: true
            }
            let schema = [
                { ...style, width: 25, column: 'DATE CREATED', value: value => value.date_created },
                { ...style, width: 50, column: 'PATIENT NAME', value: value => value.patient_name },
                { ...style, width: 20, column: 'AGE', value: value => String(value.age)},
                { ...style, width: 20, column: 'BIRTHDAY', value: value => value.birthdate },
                { ...style, width: 20, column: 'GENDER', value: value => value.gender },
                { ...style, width: 20, column: 'CONTACT NUMBER', value: value => value.mobile_number },
                { ...style, width: 30, column: 'EMAIL', value: value => value.email },
            ]

            this.$excel_file(this.tbl_items, {
                schema,
                headerStyle: {
                    borderColor: '#FFFFFF', 
                    fontWeight: 'bold',
                    backgroundColor: '#1565C0',
                    color:'#FFFFFF'
                },
                fileName: this.$store.state.prv_data.provider_name + ' Non Konsulta Members ' + date + '.xlsx'
            })
        }
    }
}
</script>

<style scoped>
  .centered-tooltip {
    text-align: center; /* Center-align the tooltip content */
  }
</style>