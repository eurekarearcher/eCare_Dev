<template>
  <v-container class="pa-0">
    <section class="mx-auto">
      <v-card class="py-5 mx-auto" flat>
        <h1 class="font-weight-medium grey--text text--darken-3 mb-4">e-Konsulta Submission</h1>
        <v-form ref="report_data">
          <v-row class="flex-wrap pt-5" dense no-gutters>
            <v-col cols="12" sm="6" md="6" lg="6" xl="6">
              <v-row justify="space-between" class="flex-wrap" dense no-gutters>
                  <v-col cols="12" sm="6" md="6" lg="6" xl="6" class="text-center pr-5">
                    <label>Start Date</label>
                    <v-menu :close-on-content-click="false" transition="scale-transition" max-width="290px" min-width="290px" offset-y>
                      <template v-slot:activator="{ on }">
                          <v-text-field 
                            v-on="on"
                            v-model="start_date" 
                            v-mask="date_mask"
                            :rules="empty_validation"
                            :disabled="disable_date" 
                            class="body-2" 
                            placeholder="YYYY-MM-DD"
                            >
                          </v-text-field>
                      </template>
                      <v-date-picker v-model="start_date_picker" @change="start_date = start_date_picker"  no-title></v-date-picker>
                    </v-menu>
                  </v-col>

                  <v-col cols="12" sm="6" md="6" lg="6" xl="6" class="text-center pr-5">
                      <label>End Date</label>
                      <v-menu :close-on-content-click="false" transition="scale-transition" max-width="290px" min-width="290px" offset-y>
                        <template v-slot:activator="{ on }">
                            <v-text-field 
                              v-on="on"
                              v-model="end_date" 
                              v-mask="date_mask"
                              :rules="empty_validation"
                              :disabled="disable_date" 
                              class="body-2" 
                              placeholder="YYYY-MM-DD"
                              >
                            </v-text-field>
                        </template>

                        <v-date-picker v-model="end_date_picker" @change="end_date = end_date_picker" no-title></v-date-picker>
                      </v-menu>
                    </v-col>
              </v-row>
            </v-col>

            <v-col cols="12" sm="4" md="4" lg="4" xl="4" class="mt-1">
              <v-layout wrap justify-center>
                <div class="text-center">
                  <label>Tranche #</label>
                  <v-radio-group v-model="tranche_value" :disabled="disable_tranche" :rules="empty_validation" row >
                    <v-radio label="1st Tranche" value="1"></v-radio>
                    <v-radio label="2nd Tranche" value="2"></v-radio>
                  </v-radio-group>
                </div>
              </v-layout>
            </v-col>

            <v-col cols="12" sm="2" md="2" lg="2" xl="2" align-self="center" class="pl-3">
              <v-btn @click="searchRecord" :loading="loading_search_btn" color="primary" type="button" block>Search <v-icon right>mdi-magnify</v-icon></v-btn>
            </v-col>

          </v-row>
        </v-form>
        <v-card-actions class="pa-0">
          <v-row dense no-gutters> 
            <v-col cols="12" sm="12" md="4" lg="6">
              <v-text-field v-model="search_record" label="Search Record" :loading="loading_validate_btn" class="mr-4" append-icon="mdi-magnify" clearable outlined dense hide-details> </v-text-field>  
            </v-col>
            <v-col cols="12" sm="12" md="8" lg="6" class="d-flex justify-end pa-0"> 
              <div class="mb-5">
                <v-btn @click="validateRecordPerData" :disabled="disable_validate_btn || patient_data.length === 0 || select_patient.length === 0" :loading="loading_validate_btn" class="primary mx-1" type="button" > {{ ekonsulta_tab === 0 ? 'Validate' : 'Submit'}} Report</v-btn>
                <!-- <v-btn @click="validateTransaction" :disabled="disable_validate_btn || patient_data.length === 0" :loading="loading_validate_btn" class="primary mx-1" type="button" >Validate Report</v-btn> -->
                <!-- <v-btn @click="submitTransaction" :disabled="disable_submit_btn" :loading="loading_submit_btn" class="primary mx-1" type="button" >Submit Report</v-btn> -->
              </div>
            </v-col>
          </v-row>
        </v-card-actions>
        <!-- <v-divider></v-divider> -->

        <v-tabs v-model="ekonsulta_tab" @change="searchRecord">
          <!-- <v-tab @click="searchRecord">Validation</v-tab>
          <v-tab  @click="searchRecord">Submission</v-tab> -->
          <v-tab>Validation</v-tab>
          <v-tab >Submission</v-tab>
        </v-tabs>

        <v-tabs-items v-model="ekonsulta_tab">
          <v-tab-item>
            <!-- FOR VALIDATION  TABLE -->
            <v-data-table v-model="selected_patient" :headers="headers" :sort-by.sync="sort_by" :sort-desc.sync="sort_desc" :search="search_record" class="mt-4" :items-per-page="items_per_page" :footer-props="footer_props" :items="patient_data" :loading="loading_search_btn" show-select item-key="pHciCaseNo">
              <template v-slot:header.data-table-select="{ props, on }">
                  <v-simple-checkbox
                    color="white"
                    v-if="props.indeterminate"
                    v-ripple
                    v-bind="props"
                    :value="props.indeterminate"
                    v-on="on"
                  ></v-simple-checkbox>
                  <v-simple-checkbox
                    @click="selectAllItems"
                    color="white"
                    v-if="!props.indeterminate"
                    v-ripple
                    v-bind="props"
                    v-on="on"
                  ></v-simple-checkbox>
              </template>
            </v-data-table>
          </v-tab-item>
            <v-tab-item>
              <!-- FOR SUBMISSION  TABLE -->
              <v-data-table v-model="selected_patient" :headers="headers" :sort-by.sync="sort_by" :sort-desc.sync="sort_desc" :search="search_record" class="mt-4" :items-per-page="items_per_page" :footer-props="footer_props" :items="patient_data" :loading="loading_search_btn" show-select item-key="pHciCaseNo">
                <template v-slot:header.data-table-select="{ props, on }">
                    <v-simple-checkbox
                      color="white"
                      v-if="props.indeterminate"
                      v-ripple
                      v-bind="props"
                      :value="props.indeterminate"
                      v-on="on"
                    ></v-simple-checkbox>
                    <v-simple-checkbox
                      @click="selectAllItems"
                      color="white"
                      v-if="!props.indeterminate"
                      v-ripple
                      v-bind="props"
                      v-on="on"
                    ></v-simple-checkbox>
                </template>
              </v-data-table>
            </v-tab-item>
        </v-tabs-items>
      </v-card>

      <v-dialog v-if="display_validated" v-model="display_validated" width="850" persistent>
          <v-card width="850" height="550"> 
            <v-card-title class="d-flex justify-center"> VALIDATE REPORT (T{{ tranche_value }}) </v-card-title>
            <v-divider> </v-divider>
            <div v-if="selected_patient.length !== patient_validated_data.length" class="d-flex justify-center align-center" style="height: 420px;">  
                <v-progress-circular :size="120" :width="7" indeterminate color="primary">
                  <span class="body-1"> {{ patient_validated_data.length + " / " + selected_patient.length }} </span>
                </v-progress-circular>
            </div>
            <div v-else> 
                <v-sheet style="height: 380px;">
                    <div class="validate-items px-12"> 
                      <v-sheet class="d-flex justify-space-between my-4">
                          <h4 class="body-2 font-weight-bold"> NAME</h4>
                          <h4 class="body-2 font-weight-bold"> STATUS </h4>
                      </v-sheet>
                      <div v-for="patient_data in  patient_validated_data" :key="patient_data.pHciCaseNo"> 
                        <v-sheet class="d-flex justify-space-between my-4">
                            <h4 class="body-2"> <span class="body-2"> {{ patient_data.pPatientFullname }} </span> </h4>
                            <template v-if="patient_data.success"> 
                              <v-icon size="large" color="success" class="pr-4"> mdi-check-circle </v-icon>
                            </template>
                            <template v-else>
                              <v-tooltip bottom>
                                  <template v-slot:activator="{ on, attrs }">
                                      <v-icon v-bind="attrs" v-on="on" size="large" color="error" class="pr-4"> mdi-close-circle </v-icon>  
                                  </template>
                                  {{ patient_data.error.errors[0] }}
                              </v-tooltip>
                            </template>
                        </v-sheet>
                      </div> 
                    </div> 
                </v-sheet>
                <v-sheet class="d-flex justify-center align-center mb-4"> 
                  <h5 class="success--text body-2 mx-12 font-weight-medium"> Success: <span> {{ success_count }} </span> </h5> 
                  <h5 class="error--text body-2 mx-12 font-weight-medium"> Failed: <span> {{ failed_count }}</span> </h5>
                </v-sheet>
            </div>
            <div class="d-flex justify-center"> 
              <v-btn @click="searchRecord" :disabled="proceed_validate_loader" class="mr-1" text>  Close </v-btn>
              <div v-if="ekonsulta_tab === 1"> 
                <v-btn @click="validateTransaction" color="primary" :disabled="success_count < 1" :loading="proceed_validate_loader" class="ml-1"> Proceed to submission </v-btn>
              </div>
            </div>
          </v-card>
      </v-dialog> 

      <v-overlay v-if="submission_loading" :value="loading_validate_btn" z-index="9999"> 
        <v-progress-circular indeterminate size="35"></v-progress-circular>
        <span  class="ml-3 text-h6 font-weight-regular" >Loading... Please Wait...</span>
      </v-overlay>

      <Alert :alert="alert" />
      <TransactionDialog :alert="alert_data" :submit_report_loader="submit_report_loader" @backToHomepage="backToHomepage" @submitReport="submitTransaction" @closeReport="searchRecord"/>
    </section>
  </v-container>
</template>

<script>
import { mask } from "vue-the-mask"
import TransactionDialog from '@/components/admin/ekonsulta/TransactionDialog'
import Alert from '@/components/Alert'

export default {
  directives: { mask },
  components: {TransactionDialog, Alert},

  data() {
    return {
      tranche_value: '',
      start_date: '',
      start_date_picker: '',
      end_date: '',
      end_date_picker: '',
      date_mask: '####-##-##',
      
      disable_validate_btn: true,
      loading_validate_btn: false,
      loading_submit_btn: false,
      disable_submit_btn: true,
      disable_tranche: false,
      disable_date: false,
      loading_search_btn: false,

      alert_data: {},
      alert: {},

      // FORM VALIDATION
      empty_validation: [
          v => !!v && !/^ *$/.test(v) || 'Required Field',
      ],

      headers:[
        // { text: 'Transaction Date', value: 'pTransDate', width:"130px", sortable: false, align:'center'},
        { text: 'Name', value: 'pPatientFullname', width:'250px', sortable: false, align:'center'},
        { text: 'Patient Type', value: 'pPatientType', sortable: false, align:'center'},
        { text: 'Patient Pin', value: 'pPatientPin', sortable: false, align:'center'},
        { text: 'Member Pin', value: 'pMemPin', sortable: false, align:'center'},
        { text: 'Date of Birth', value: 'pPatientDob', width:"120px", sortable: false, align:'center'},
        { text: 'Gender', value: 'pPatientSex', sortable: false, align:'center'},
        { text: 'Status', value: 'validation_status', sortable: false, align:'center'},
      ],

      sort_by: 'pTransDate',
      sort_desc: true,

      patient_data: [],
      selected_patient: [],
      selected: [],
      pHciCaseNo: [],
      pHciTransNo: [],

      upload_loading: false,
      upload_success: false,
      upload_error: false,
      upload_delete: false,
      upload_list: '',

      patient_validated_data: [],

      display_validated: false,
      proceed_validate_loader: false,

      submit_report_loader: false,
      search_record: '',

      success_count: 0,
      failed_count: 0,
      transmittal_id: '',
      ekonsulta_tab: null,
      submission_loading: false,

      items_per_page: 10,

      footer_props: {
        'items-per-page-options': [5, 10, 25, { text: 'All', value: -1 }]
      }
    }
  },

  computed: {
    select_patient() {
      return this.selected_patient.map(data => {
        return data.pHciCaseNo
      })
    },

    enc_xml_file_name () {
      return this.tranche_value + this.$store.state.prv_data.phic_acc_no + "_" + this.$moment().format('YYYYMMDD') + "_" + this.transmittal_id + ".xml"
    },

    dec_xml_file_name () {
      return this.tranche_value + this.$store.state.prv_data.phic_acc_no + "_" + this.$moment().format('YYYYMMDD') + "_" + this.transmittal_id
    }
  },

  methods: {
    selectAllItems(){
      this.items_per_page = -1
      this.selected_patient = this.patient_data
    },

    //VALIDATE RECORD FORE DATA
    async validateRecordPerData() {
      if (this.selected_patient.length <= 1000) {
        let validation_payload = {
          request_key: 'db',
          provider_code: this.$store.state.prv_data.provider_code,
          phic_token: this.$store.state.prv_data.phic_token,
          pHciAccreNo: this.$store.state.prv_data.phic_acc_no,
          report_tagging: this.tranche_value,
          report_status: this.ekonsulta_tab === 0 ? 'first_validation' : 'batch_validation'
        }

        if(this.ekonsulta_tab === 0) {
          this.display_validated = true
          this.selected_patient.forEach((element) => {
            setTimeout(async() => {
              let response =  await this.$services.getEkonsultaValidationReports({
                  ...validation_payload,
                  case_number: [element.pHciCaseNo],
              })
      
              if (response.status === 200) {
                response.data = this.responseDataDecryption(response.data)
                this.patient_validated_data.push({
                  ...element,
                  success: response.data.success,
                  error: response.data.encryptedXmlerrors ? JSON.parse(response.data.encryptedXmlerrors) : undefined
                })
      
                if (response.data.success) {
                  this.success_count++
                } else {
                  this.failed_count++
                }
              } else {
                this.alert = response.error
              }
            }, 500)
          })
        } else {
          // VALIDATE TRANSACTION FOR TRANCHE 1 AND TRANCHE 2

          this.submission_loading = true
          this.proceed_validate_loader = true
          this.loading_validate_btn = true

          let success_validate = []

          this.selected_patient.map(data => {
              success_validate.push(data.pHciCaseNo)
          })

          let response = await this.$services.getEkonsultaValidationReports({
            ...validation_payload,
            case_number: success_validate,

          })

          if(response.status === 200) {
            this.loading_validate_btn = false
            response.data = this.responseDataDecryption(response.data)
            this.proceed_validate_loader = false
            this.submission_loading = false

            if (response.data === 'No Data') {
              this.loading_validate_btn = this.disable_tranche = this.disable_date = false

              this.alert = {
                    display: true,
                    type: "standard",
                    width: "350",
                    icon: "mdi-alert-circle",
                    color: "yellow darken-1",
                    title: '',
                    body: `No more data found for ${this.start_date} / ${this.end_date}`,
                    btn_pry_txt: "OK",
                    btn_pry_color: "primary",
                    btn_pry_otl: false,
                    btn_pry_act: "closeAlert",
                }
              return 
            }

            if (response.data.success) {
              this.encrypted_xml = JSON.stringify(response.data.pReport);
              this.transmittal_id = response.data.pTransmittalID;
              this.hci_case_no = JSON.stringify(response.data.pHciCaseNo);

              this.loading_validate_btn = false
              this.disable_validate_btn = true
              this.disable_submit_btn = false

              this.alert_data = {
                display:true, width: 620, 
                icon: 'mdi-check-circle', 
                color: 'success', 
                title: 'Validated Successfully', 
                sub_title: `${success_validate.length} Record${success_validate.length > 1 ? 's' : ''} successfully validated, You can now submit the report.`,  
                downloadTextFile: true,                    
                xmlData: this.encrypted_xml,
                file_name: this.enc_xml_file_name
              }

              return

            } else {
                this.loading_validate_btn = this.disable_tranche = this.disable_date = false
                this.alert_data = {display:true, width: 550, icon: 'mdi-alert-circle', color: 'error', title:'Validation Failed', sub_title: 'Please try again'}
                return
            }
          } else {
            this.alert = response.message
          }
        }
      } else {
          this.alert = {
              display: true,
              type: "standard",
              width: "400",
              icon: "mdi-alert-circle",
              color: "yellow darken-1",
              title: 'Validate Report',
              body: `Maximum of 15 records can validate please try again.`,
              btn_pry_txt: "OK",
              btn_pry_color: "primary",
              btn_pry_otl: false,
              btn_pry_act: "closeAlert",
          }
     }
    },
    
    // SUBMIT TRANSACTION FOR TRANCHE 1 AND TRANCHE 2
    async submitTransaction() {
        this.submit_report_loader = true

        let trans_data = new FormData();
        trans_data.append("pTransmittalID", this.transmittal_id);
        trans_data.append("pReport", this.encrypted_xml);
        trans_data.append("pReportTagging", this.tranche_value);
        trans_data.append("pHciCaseNo", this.hci_case_no);
        trans_data.append("Prv_Name", this.$store.state.prv_data.provider_name)
        trans_data.append('phic_token', this.$store.state.prv_data.phic_token)
        trans_data.append("provider_code", this.$store.state.prv_data.provider_code)

        let response = await this.$axios.post(this.$tms_url+'resources/api/_get_ekonsulta_submit_reports.php', trans_data)
        
        if(response.status === 200) {
          if(response.data.success) {
              response.data = this.responseDataDecryption(response.data)
              this.submit_report_loader = this.disable_tranche = this.disable_date = false
              this.pTransmittalID = response.data.pTransmittalID
              this.alert_data = {
                  display:true, 
                  width: 660, 
                  icon: 'mdi-check-circle', 
                  color: 'success', 
                  title:'Ekonsulta Submission', 
                  sub_title: 'Tranche ' + this.tranche_value + ' is submitted successfully to PhilHealth', 
                  sub_title_2: 'Ref No. ' + response.data.uploadXmlResult.transaction_no,
                  emitMethod: 'backToHomepage',
              }

              return
            
            } else {
              this.submit_report_loader = this.disable_tranche = this.disable_date = false
              this.alert_data = {display:true, width: 550, icon: 'mdi-alert-circle', color: 'error', title:'Submission Failed', sub_title: 'Please try again'}
              return
          }
        } else {
            this.alert = response.error
        }
    },

    //SEARCH RECORD FOR E-KONSULTA PATIENT
    async searchRecord() {
      if (this.$refs.report_data.validate()) {
        this.loading_search_btn = true
        this.selected_patient = []
        this.alert_data = {}
        this.selected_patient = []
        this.patient_validated_data = []
        this.display_validated = false
        this.patient_data = []
        this.success_count = 0,
        this.failed_count = 0
        let response = await this.$services.getEkonsultaEligibilityList({
            request_key: this.ekonsulta_tab === 0 ?'for_validation' : 'for_submission',
            start_date: this.start_date,
            end_date: this.end_date,
            report_tagging: this.tranche_value,
            phic_acc_no: this.$store.state.prv_data.phic_acc_no
        })

        if(response.status === 200) {
          response.data = this.responseDataDecryption(response.data)

          if(response.data === 'No Data') {
            this.loading_search_btn = false
            this.alert = {
                      display: true,
                      type: "standard",
                      width: "350",
                      icon: "mdi-alert-circle",
                      color: "yellow darken-1",
                      title: '',
                      body: `No more data found for ${this.start_date} / ${this.end_date}`,
                      btn_pry_txt: "OK",
                      btn_pry_color: "primary",
                      btn_pry_otl: false,
                      btn_pry_act: "closeAlert",
                  }
          } else {
            this.disable_validate_btn = false  
            this.patient_data = response.data
            this.loading_search_btn = false
          }
        } else {
          this.alert = response.error
        } 
      }
    },

    //COUNT SUCCESS AND FAILED RECORD
    countRecord(value) {
      let success_count = 0
      let error_count = 0
      if(value) {
        success_count + 1
        return success_count
      } else {
        error_count + 1
        return error_count
      }
    },

    countSuccessAndFailed() {
        let success_count = 0;
        let failed_count = 0;

        this.patient_validated_data.forEach(record => {
            if (record.success) {
                success_count++;
            } else {
                failed_count++;
            }
        });

        return { success_count, failed_count };
    },

    backToHomepage() {
      this.$router.push('/admin/ekonsulta-submission')
    }
  }
}
</script>

<style scoped>
::v-deep.v-icon.notranslate.mdi.mdi-checkbox-blank-outline.theme--light:first-of-type {
  color:rgb(255, 255, 255) !important;
}
.input-label:hover { 
  cursor: pointer;
  border-bottom: 1px solid #2196f3;
}
.border-bottom {
  border-bottom: 1px solid rgb(228, 228, 228);
}

.validate-items {
  max-height: 340px;
  overflow-y: auto;
}
</style>