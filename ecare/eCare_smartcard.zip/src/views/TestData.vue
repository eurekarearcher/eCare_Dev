<template>
    <div class="pa-4">
        
        <h4 class="text-h5 font-weight-medium my-4"> Ekonsulta Testing Data </h4>
        <v-text-field v-model="search_member" label="Search"> </v-text-field>
        <v-data-table v-model="selected_member" :headers="headers" :search="search_member" :items="item" show-select item-key="pPrimaryPIN" class="my-4">
          <!-- <template v-slot:header.data-table-select="{ props, on }">
              <v-simple-checkbox
                color="white"
                v-if="props.indeterminate"
                v-ripple
                v-bind="props"
                :value="props.indeterminate"
                v-on="on"
              ></v-simple-checkbox>
              <v-simple-checkbox
                color="white"
                v-if="!props.indeterminate"
                v-ripple
                v-bind="props"
                v-on="on"
              ></v-simple-checkbox>
          </template> -->
        </v-data-table>
        <!-- <v-btn @click="verifyMember"> Verify User </v-btn>
        <v-btn @click="registerUser"> Register Member </v-btn>
        <v-btn @click="checkEkonsulta"> Check ekonsulta eligible </v-btn>
        <v-btn @click="preConsultation"> Pre-consultation Tranche 1 </v-btn>
        <v-btn @click="emrConsultation"> EMR-consultation Tranche 2 </v-btn>
        <v-btn @click="preCons"> Pre-consultation Tranche 2 </v-btn> -->

        <!-- <v-btn @click="showImage"> Click </v-btn>
        <v-img v-if="show_image" :src="image" :id="image_id"> </v-img> -->
    </div>
</template>
<script> 
export default {
    data() {
        return {
            ek_lgu_id: '',
            mem_first_name: 'TFSHC FN SIXTEEN',
            mem_middle_name: 'TFSHC MN SIXTEEN',
            mem_last_name: 'TFSHC LN SIXTEEN',
            mem_birthday: '1974-01-17',
            mem_phic_pin: '190269297712',

            search_member: '',

            item: [],

            selected_member: '',

            transaction_number: '',

            headers:[
                { text: 'Status (Registration)', width:"100px", sortable: true, value: 'registration_status', align:'center'},
                { text: 'First Name', value: 'pAssignedFirstName', width:'250px', sortable: true, align:'center'},
                { text: 'Middle Name', value: 'pAssignedMiddleName', sortable: false, align:'center'},
                { text: 'Last Name', value: 'pAssignedLastName', sortable: false, align:'center'},
                { text: 'Date of Birth', value: 'pAssignedDateOfBirth', width:"120px", sortable: false, align:'center'},
                { text: 'PHIC Pin', value: 'pAssignedPin', width:"120px", sortable: false, align:'center'},
                { text: 'Gender', value: 'pAssignedSex', sortable: false, align:'center'}
            ],
            show_image: false,
            image: '',
            auth_token: 'changeme',
            image_id: 'some-image'
        }
    },

    mounted() {
        if(this.$tms_url.includes('dev') && this.$cms_url.includes('dev')) {
            this.get_ekonsulta_member()
        } else {
            this.$router.push('/*')
        }
    },

    methods: {
        fetchWithAuthentication(url, authToken) {
            const headers = new Headers();
            headers.set('Authorization', `Bearer ${authToken}`);
            console.log(url, { headers })
            return fetch(url, { headers });
        },

        showImage() {
            this.show_image = true
            this.image = 'http://upload.wikimedia.org/wikipedia/commons/a/a1/Normal_posteroanterior_%28PA%29_chest_radiograph_%28X-ray%29.jpg'
            this.displayProtectedImage(this.image_id, this.image, this.auth_token)
            //const img = 'https://upload.wikimedia.org/wikipedia/commons/a/a1/Normal_posteroanterior_%28PA%29_chest_radiograph_%28X-ray%29.jpg'
        },

        async displayProtectedImage(imageId, imageUrl, authToken) {
            // Fetch the image.
            const response = await this.fetchWithAuthentication(imageUrl, authToken);
            console.log('RESPONSE: ', response)
            // Create an object URL from the data.
            const blob = await response.blob();
            const objectUrl = URL.createObjectURL(blob);

            // Update the source of the image.
            console.log(imageId)
            console.log(objectUrl)
            this.image = objectUrl
            // const imageElement = document.getElementById(imageId);
            // imageElement.src = objectUrl;
            // imageElement.onload = () => URL.revokeObjectUrl(objectUrl);
        },

        async get_ekonsulta_member () {
            let response =  await this.$axios.post(this.$tms_url+"resources/test_ws/phic_masterlist.php")
            let items = response.data.map(data => {
                return {
                    ...data,
                    pAssignedDateOfBirth: this.formatDate(data.pAssignedDateOfBirth)
                }
            })
            this.item = items
        },

        async verifyMember() {
           await this.selected_member.forEach(element => {
               this.$axios.post(this.$cms_url+"resources/web_service/ws_member_web.php",this.$qs.stringify({ 
                    post_data: this.wsDataEncryption(JSON.stringify({
                        key: 'eurekare_key_web',
                        data: {
                            command: 322101001,
                            data: {
                                first_name: element.pAssignedFirstName,
                                last_name: element.pAssignedLastName,
                                birthdate: this.$moment(element.pAssignedDateOfBirth).format('YYYY-MM-DD')
                            }
                        }
                    }))
                })).then(response => {
                    response.data = this.responseDataDecryption(response.data)
                    
                    if(response.data.is_registered === '2') {
                        console.log("register")
                        console.log(response.data)
                    } else {
                        console.log("Not register.")
                        this.registerUser(element)

                    }
                    
                }).catch(error => {
                    console.log(error)
                })  
            })

        },

        async registerUser(data) {
            console.log(data)

            await this.$axios.post(this.$cms_url+"resources/web_service/ws_member_web.php",this.$qs.stringify({
                post_data: this.wsDataEncryption(JSON.stringify({
                    key:"eurekare_key_web",
                    data: {
                        command: "322101002",
                        data: {
                            request_key: "PRIMARY",
                            registered_from: "web",
                            is_app_ready: "0",
                            mem_birthdate: data.pAssignedDateOfBirth,
                            mem_mobile_no: "",
                            mem_first_name: data.pAssignedFirstName,
                            mem_middle_name: data.pAssignedMiddleName,
                            mem_last_name: data.pAssignedLastName,
                            mem_suffix_name: "",
                            mem_gender: data.pAssignedSex === 'F'? "FEMALE":"F" || data.pAssignedSex === 'M'? "MALE":'M',
                            house_number: "",
                            street: "",
                            barangay: "MAGUPISING",
                            municipality: "BRAULIO E. DUJALI",
                            province: "DAVAO (DAVAO DEL NORTE)",
                            region: "REGION XI",
                            subdivision: "",
                            lot: "",
                            blk: "",
                            phase: "",
                            unit_room_floor: "",
                            building_name: "",
                            zip_code: "2121",
                            educational_attainment: "Some High School",
                            mem_company_name: "",
                            indigenous: 1,
                            ethnic_group: "",
                            blood_type: "",
                            mothers_first_name: "TEST",
                            mothers_middle_name: "",
                            mothers_surname: "TEST",
                            mem_phic_pin: data.pAssignedPin,
                            mem_ek_phic_id: null,
                            phic_host_code: null,
                            ek_lgu_id: null,
                            principal_ek_lgu_id: null,
                            lgu_host_code: null,
                            registration_type: "LGU",
                            has_data: "0",
                            mem_registration_type: "PRINCIPAL",
                            frbs_registration_id: "",
                            mem_photo: ",/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCAD6ALsDASIAAhEBAxEB/8QAHAAAAgMBAQEBAAAAAAAAAAAAAgMAAQQFBgcI/8QANRAAAgIBBAECBAYBBAEFAQAAAQIAESEDEjFBUSJhBBNxkQUGMoGhsUIUIzPBUhVygtHw8f/EABgBAQEBAQEAAAAAAAAAAAAAAAECAAME/8QAIxEAAwEBAAIDAQACAwAAAAAAAAERITECQRJRYXEDIjJCgf/aAAwDAQACEQMRAD8A/JGlqHcQ3IXIjkL7jtbPMorpC1UCyOTyI3YoAomxgz0ptglekbTwxNgN5zFAaikEkEDgXNOOSMkUAYG4ClNEWcwa3Sq/FYUNhrcCe918QwV6U+MnmXoLRJABBF47h2vzBa3is+IfH1wj5MmNJDtHpsY/uGNFdQ3XjmU7hVLMb6l3uSneyc2BRqViwq0HaFtytqDmpFcKxCsaYVULTCtuQfXEIaakBlqxziFbeG4uhIu9gFSjVwCQDZ0rMIMFAN0B1cNBpAlqJJPB6m+LpkLVFGouttBKijR5hLurcVxdijD2hADgZ58SIosWfpXE0aN1Qs6ai/lkm+cf3KLgaotcD25jFUENuIA5GexKZ0YBjZyLEG5rFILTC+sot2bMaijTWgD6eKxBQlAKT0saOcg5mpFVrVefJm8dwa08B03DEqwwBz4iLKqyEXZoEYM0KFDDcCpYX9YDor6m5XIo/WC8X4rDPyr0mCCb3E8Hx7TP8Xqan+lbrsVNRoGgmd2M/wBxHxyqugaBFZhNhk0fL/xgMvxbMoomcnU3lyS9HxO7+Nqn+rdq4sTlBdMizVn3kRrEPT6Dporks24muDDUMGNZxkcykUqFaz9feHphTe5toPM7c705pt8CBDqTRteqqKC2PUCcXHOoX13yK9olySAVPHkx/obaHo2GO0G+bviM1BepWwgnMVpm9tG93JviM1DvyDZ6riplzTOcHBLUllP7DEpQ2RVgY8ytO2QoWJoYNy126YDNYvnPc36azC1sONPadw7rBhpZDWDxRkA+YgYKR3j+4W3YMtzwTNExk6CyBlCEVta1wcxgpiwJOBeRBDEBgxFg4Mpi5OdS/eupvQa2U52Lf+JPAhANqE/LsDFwlG4EMxBAFXxB0gzAKwO7P6YRvR/8G2AzbrzzQ7hORp6e6rJFjHcH0slUdwPEO/QPJOAYxUEp0M1p7wQdtBhfFwwEIVlLcXfMXqAMijJHB8VGoG2gBspxnqTdwphF23KzEGxUEbsijt8xj7Wq7oiq4zKOkfl2Dxzmrm35Yby/SFBuWjStk+aivjtJhosGf/HFxlAqEWjR/cRfx71oOpPI6xN1lcR80/G9HZ8SWBz7zkMcnj7Tu/jAXV+I9B4FWe5ym+HJJpVr3nNtLSY1098EOqQytJrKQbW93GP7lKhQ21WTxXMMKMuGokTvIQmnpPUFAIJF3iXtRmL0DZyp6EEsQCCBgYMMi0BIo8kDzMo1GNZSqgFbR3QPUYi7QG0yGBGBAK2A4q6oy9hKqCaF4x17QulZ7DVGFhVHHELGqKcAWBIA20qtEAUDK0GIc0vtmOPCPwahOmqmx7+0p222Ctk+8tchg7KVOQO5AjAnBZa8cQfjuFZAlRALY/T6wRZUCu8RhQnRNZ82IIFBQAOfEFLDWIorgKTkYvqVRGqpugPH0j20xpuSWw2bqAwbdS+q8cTPxRk6Gt6ukcepP2uNBV1AIHtmBpo6qXZb3Sxsc0poAgxWGdYZVDogPVqcV3HIgYjcCT9ridFORkgkmiOI1AwADOWW7HsJPHWKXoamnvVi1Eqf2qV8sqMNYu/2jNMEgsHsE8VKCEWMGvM3oyVAUaTEEWv0mT8Qs/DsCQccmb9pO61sj2mP8Q0z/pdRRx79TT/sZP7Pn/xqg/EMzCx48TnMULGjQ+s3/GvWtqbrINnjicfUADkfLJz4kVC94e/VlJ22d3msSBdBtQ77BEZqMm8+ocXjsyr3GiCOrnb/AJYyEQfLY2D1jMAHII4GDIflNt3EgA1ZjCFvaoXz7zN/ZgFILbiRZwLjHsgAMGA66inIcAKCCp76jQzVigTe7EzjNH7L0XFWfvHBVY0Rgm8HqZVb5bshyDxGglQWJB2iiYVGGEhdbaBajuo5NQm1QHHIMSpZ0BLccRtj5d2OefJhUnptLatpXT5f2oSI5GSMjBrkQlceksBZ5A8ytHUZnYL6aPUrOsPcDwLzkcmrgMrISwLVdGGjetg2E7NRrNpE5IJ545m7wrvAdhY7Vb0gXIUUsSp4o11LFtTKRSnIqNKLuDCwr+OoPdQ1LAb42m79oenqKpzuO7qL01OkzqSTZ4MbokWVLDB8CFgDVcFS3eB4qRWG90XlT4xUJqY2TtHGO5emPVaAVUfeDUGjDdbKT4v+pn/FAP8ARu27rE0q6kEZ3XnEyfjDMPgHXsrQxc3k/Qrp8z/E9Qf6lwt+k5Nczmls59XvfM2fHuV+Kdgc55E5xdrw05PySeolU+jEK6nV2+v/ABkLlAbA9uyIKMpQhjdcYkAUm/UabInb2Ec0MhGANcD7RRcaQGDk/vI2oDqMSDXEFmdlJ25JxUMoqJDtqm/l9iAp+W5PR7MtSRtuwaznuA4B1Q27HgzSg3HAjXzCyCi0YthNjKG3ZzFMTvAvvEad4UNg7egZPsZOGhnAVdq0QCCIWjqqNP1pi+Io067gavBqXp0DtYWBFL2Sn9jSrHT3VeMdGH8MQls2A3mLVgf0k+nEvRIqg1D+4vXhWLR5Fam7TWwcGM0xeWYEfSZg9NQB3VYE0KxJUNz7CZpgotLVNNWoAkA2RHKNoorY5AMz7gWLNR38Ru1iytRwLMzfsc9k1GBf5hWtwqOVFGGqxkG4lkNBrJAM0i2AYC8UfaLblD3CwCAMWD95E9Kgk44kCHYM0R9oJRNo3HmZ2YKx6NUk8Yv+Zi/GWc/AOuRXFzat3yT19Zh/GGCfBahu7xZkPlQ+4j5Z+Jsy/EPgUeKmEcZA+83fizD/AFLAAc/ec4vqKdq8SXVoOH0gE7SAbxnMgG9iQTfcJlKhlUmhjEvTLKVIKkjq/vOiZJSIVLWOsCpNDTLtuYd1zGb/AFbWPsM4uEGCv6RWe4+KXUbYJ10I1AEHAsZgMylQP8hfB/iO1N2SWuzmBpaZ2Mxojg9SfwbPQGmy7QzLZu8R9Wo2L+/QmYI5G9DwfM06RdEIAAAM3MN+otfSBRrNEQzp01g5BwIJ20Q4snIo1CXcAfVZMXHhkmnWTdZNKQSMw0I27dwsmIV9QvVCuCQY9QqUXBro3MpwOEZ3DlWPqBqxHXqqC1nbVEHmV6DRYZsZh/EMVW1sxqYO9FAIdl4Km+MzchZroi+AZhGmxbev6T5NVNisP1lTbDGeZOFr7GIp1P8AbNebj0XYrANxUz6OsFtWWiOczUoJU8mxxGxA0wvQeTV1/wD2AV3ajIG4GL8QygB9j4hALuF3N5VIUoAoOzaRmpy/x5iPgyVwanXJp+MVjucz8fUf+nuwFmDXoU2j5T+ILu+JLEm7xcxMi7jat950fxJSNVixquJhLuTaorDo3OXyS6HxrPpqKBpllaiBX1gmkAdqBvmuZQcbiKAPg9+8FvUQCTkXOz2E6gwwsNzngQgRqm1IA4q4p29F7T9smGilRZBo9eIt+jXAm0SWvP7n+pYrZuUWAcGA2qQKYkVxD0mHywT/AJZqCX0NF6dA7mWr+0buFEiqPvzBbUJNFB95Ay7gu3nP0mVoXCkatZd9EX2Y8KvzTRIB+xiU0yWJul/vPMeoDqF3EtfjiHybKcFqB89gvJFeIYUMAjAEDPmUzqj3tOcZ6j00LXcBnzcVuUhNJgKhXB5OR9I9b2KGArz3BcHaCLtf5jkdW0lWvTFo1AAycV+0INgqATtyLlam1FG28/xIp2sCzc+O5LVLoQGk4XFA8m5q0NUMwRB6By3mZWCjfnAPMfpHbVd9TN7pp9mlicALjyOpFJV92CG5uUhXIyB9YSMCw2gn2MWsop7CzYO66/7nG/MGuNP4FiQbz9J2NSlajmjnM89+a3K/BNVmuMyfJpqN6PT538RqH5mpu0hn36nNdtIMQBx7zbragbUNkD6zI22zaqT5kJMH+H0vU9ILA2T/ABLABAJu7qwMwdwZhbFvOO4ywgCcgeBzPRx1nFWkYEre2zWKl6eqCK4JOcyaYyQbF5zKUE2jUD4kpzhTQ1k0nb5b0AZTaabaU5AsGF6BRNYOcSEEkCrsX4i3USrQOSCQB+0pyLvbYPQ5kKuWOxuOjiUVLsBe0ju4Oey6kHpK6o1HDdeI3SQggXVRaqQRRI9xgw0oH1k31XEHyILdDbS2nOe/rH3aKtbc1BUbRsbJ3WCIQFEktfv4MUkDbuDGVdhT7ytrkYbjiW9kbS1E8E8y0sj9RuMXGIAQsm43Z4hKm3BurrEmo5QqDgeSIWBYVyD3fiTOlaHqUiKStg++RD0QoG8AnriIRCzVwDGo7i1FCveM9g2oN02FEKpBuozSBU7SbPkxKEUNzC7sRu8s5BxgzeOIfY1wDm+Mmec/NoH+nDADbXc9CmpYwR+089+a2J+GCpweZPlOiz5x8SFViWUW11XEwPTMSVYfSbPiLUsuMWczEysWNOfvIoPFp9PBpd+MGiB3CrcmBkm6MBd2mKNGzGuFOP3M7rTmsdJuqt3C9S0dmex55IzBKbQac39OJNMso3EgEHmTH4inWMfcqM4AIvxBXWf05q+T7QndtQ+m69hBdauhwPtBVPBl6R2qwvcZpkvpkBVNdgReAy8VUNNMk5YVEKphYD7h14EMB1AH/ibrrMFAWbcgsLgwm/3Qy8eBH1Te4PU7dOxt2/19IaOpAvi/EXoMqDYeVFiWvqfPi/rHgJ+iUyl2Rt18XG542/Ywd9amOOCCJSNqM4DCqPMCrA2BC3d11UH1MWAUAkYNxz7iCFWlPtB0602a2r3OZLxwfFlglVAOK4oQnCo4N4Iu4lDhTe7m64jnUamSxBAqvMbfHR9hq9ENsU93xLdyzAigpzcpl2Kqs3q8RYBU02RXHibirN4uOI1KQE+YKB7E89+anA0t20AbefeddNUUyhhwQPr4nC/NLFtCznGRJcKf2eA+IBbUO6jzxMjr6jxzNrhdx1bBInPfVO85B/ac+A2fT/l0xFiji65lISrbARQ4hBQpBBFHjEpvS25luzO9jOSwIFWFH9QzxxC+YAu0ABvpcFm0yDQyarHEhJDAEjaJnoyDNwv9MtWK0At2IK9spzfYkUqHIzx4mThk6M2+ndsUC/vAZgASKr2EskUMDHEAMCdl55qDwb9h6V2GDYJj3BV1ZRZPMxrvIz/U1I/rUNdJxH5XgNQJaayBZ4z1GqP9sBtpNRes5ZRQFkcQdKxp2SBmqqZL0Z/Y0sF1NoHHNxoX0kAWORAtE0zuFNeD4EYcICGxzddQWUrPJaGWO0KTW3rxF6mopJKg4kDL6iQc0SRBRKY2xC81WJm3w2BCwQtg2PEvbgUeMiTeCbPAwJQFg05F4kyjEMbU3aZAbIoG4HqAFAnrmAUUoqE1mqPEhRlOCa+nEUZK6WiqAdPcN3m+5xvzQoGgckmhkTsa4UkNpgDHicT8zv8AL+HHzCAxGKMl7wpfp4LWASwMX3Mu1Tyov3Mf8TZc5+/cxkNf/Gp96kOk4z6r6VH6aHcJSp5UVX7ygQAfSDIQAbJwRPQ8w5dYGoNNF43DwIXpZbZaYgnIgsrAGl9ODVZll6cbBuCjkdSV9C/tBoos2D5kQKn6l9Iuh7/WAPVZ3jccgdiX6mAU8r3Kq4baDtFli1AkcyKUXXBZLJHI4hrpjcFrHJvqCTWVQmjiTH0angxSpYj9xCKEsRuGMxYW9Sz3yeo1AFYNd5zFKi6NCmqZRt/kQtBFJL1iS9LO/sVcrTpQQrMVgvJL2RIH8QrJW2mvkXG6bqKJFAfvL4QkqCAMCLa2BO0gjiYtah+r8s5S6Igk7R2L8iRGBpTjI5xLba1gLYPEzbfDJADbYFZJ/aDtc0yqWYG6qETtam06NVLFhCFsE+DUltIpfpTED1Fasym1C2rkc5Jlj1qAANw5qA2hQAX6m5XFghalhcgUPE85+bCg0lH6rAYAT0WoGohit7exPL/m12CqtGwMjxOXl9jDxnxG52ZgOOAZm2XkMfsZr1N2wkqAR13MpKL6QQK6qb5KIlZp9Sa0UHdnsSKx2mn5Fw39bgnPYEvYgNEVZ4E9FXGee1gWBlrzE2vzGZaFVfvNNAnbn6TOUKuSFJv+JLSLTgzTZWB1KAJFZEYqiwRkDz4iwrEbaI7kG2yTYs/QTSM1vA91WQDjAi3yCR0LMOwaDNZAwYtvHkZHmLVWh44il1GLKAh9WeI3eRa0buvrFIaohiamoEimLVf2+sEpqK8vtl0ooMTQzGW1hlJN3VdRPqs7iDefrLRi/wCnAAuveZ4V4umhdfap3Cj5I7hnWOmpYgEkXMjEqy5APkS9R2emBBrxBvCZs9DdRXYq+mNv7xquSmbB9pSjcPUSD0PEvcivY9R4gqlRxvC21GajRLfzAbUONy1WaOZeoSilrPtFruZSxyebqE9IuouhQdbDXd3Dd9TNNyaswWUMPlliAciublqoXTIaziuO4pZR2AN6SCASprnueW/Nuow1KIYAjE9RqaibQym6HieX/NfqYDcSpFG5DpkzyXxIJAAII5vuYWchiCP4mzX9CgLzx9JlyOSL9xI+BLrPqivTZa79oaMXG7dAVgWCYHBzHAgCqBYHj2no+PpnHrLQkBlFbTmyICoGH6wbPB4hqWDE0xBFZMUjBLLMbsDHmLgzQm03VCd4PgRb0RfgfzIxLmtxo8UYLMittIz48w7oprgxfVkkAdnzBZCznfYruuYIZ2G0gEH+JWpq7XUXZ4vxJbRrGRLoLYIXnHUcWLAKckGLZwpXdye/MtCFyTYPHtH5PiFKoaNzL0KhUyvtDCLXWCIGHeMiV8zTGoQSQf5EFqM+1E+ICv8A5DBuD8L8Qvzgu0+MmRtRCoBPdG/ErS01377rNwXjHgt/Z0VYMzN/l5uFVuzHseInTddrCmFd3GLqsgVVGKyLltw1RHIBVHB5sVxI5AUDkHBrqQ6yqTvXmwDAfVRqCEkDmvMG5o/wg1L2gnIyLEiaitqU7AEmueYpqsm8m8ftzBLlvUyX1R6hXaI7UAYkX6T/ABPI/mtyupW42RQE9TqKlBaIPgf3PKfmlm3krVYqT5O4xcSp5jUurbPURu0xhm2nxc0n9NY8ke8zsWs0RUlv44gnyZ9RpkPqIHeRGFmYC+feLssdjjPcJFG7cEvqgZ3unGboSFgGLEgViA3yjdnju4bPaHTYLYF2YjcAACDmzmS2kUv0JNRVcbxQqlNyiFo21m+5dF7Ab3q+JRsIAzKdvB7gtRm03Bb5IcXQHXUjjcobonvmWzDTBUEH3lCtQAMarJAzDyg/hWpRrYw2gdmWGZaSiw7+kI6CkihfgZkYkUpoAijniUquh3gVE6Z9eRwDFMwO0kjI/eNJIUKKFCIwBusZHPvD1pXx0cUQEWaF3z3DvT9KBxfBidNrwR6us8xqhKB2C5l3g8QxTsYhSebEcurtNu13EAhc8ZoXJvOlq7F1AxYdzT6BX2aNwqgbs7hZ4i7BG4rVRPzSDu3VUg1FJKoxsi6uGIZo52DsWAryYt8gADjmLVnUg36QMg8y2yu4E+1GSttK+O1BNqU28uQQPM8n+ZNRX1wt0wFC56Z29JcAEL0e5438w6m/4kAA2ffibybXDZKzlbiLIIqskzK7KGN7ifYxzOAhzx4mV9amI2A+9yPkvHqDeI+tFve2vF/3IHfJDXuP2EA6lAlmIORzBbUCqSpNkYviei1w4K9Guz/LYhKBHJOYBYHTBYXQwRAOo7aeSb4BuWC23YTi+5nZSl37RZ1CwAAoEV+0Xqv+nOAfvKO4A+uiDYAMDU1mPpaiesdw6Cc6NDjUAJ6jAqhARYJ98xAYBAFY0OBcNXYAHfZPiGe0LnpjfWpJV7qLLll2sDYPN4hlyBu3bc5Ai2ZQ24tnxFlpBFgVpf1c8zPqaupjcowaMttV1cC6FYi9U6jOTYr2Mm3hSi6M0mcqdoNXNCuVYbwADE/DnTYFroDJzmT4nVANqwpv7gkloJmhn3UWA2g8yOxNMMGsTC+tqGgHwOR1NC6lIpUi+vpKvsEwtzghcDPJluysNq480e5nfUb0UwvioGq+oKbcOOB1JdaiKWIedViLUgMMZ7hjUbaQWrzRxMjFiADlj1cauqpQqe1yPEYb5ZRqMAhVs7htHtPGfjm8/F11PTtrkFVRrPR6nlvxj5j/ABT7zwfMn+C+U4vxI+WfSLDHoxYQEWzUfB5h/EMQwJaIvVY7t2nnzdzl/DKLp9WTVPqRlusG+4GoC6lFJLHNdRYZtzncfvLJPziL6E9CbbpyaSUHINihTkAm7kdXK2ACRmzEv+n/AOR/6kUn1ZP/AOMqxB464VWowLFsjMl7VFscm7hH/iv2P9zK5III95D8vZa8UuDvmEKf9oV7R+8pt4qsxfwmdMk87YXxIA0VA9oKpMIn5Ft62pv0j2qLYOvpo0KoxdneRfSwnJG2j3/3HvRcT4E6uwuzWL9ouijDir4uadUAOwHmIf8A5E+p/qKVZSVGhWuqXaZTKWISrrAirN8/5f8AU1af/Kv/ALRNFQ8XjMj6GqrlAxqELAFjHXkfWH8ST8x89xdnYos8D+oeONo3VSObUgN+nwe4LsrggAiv78QNQkCxg7TF7ms5Mzehfihu4Mv6rYZx/wDcYX25tlNTDZpjZmjSJKCzfph/j/206PxQLaimjeZ5b8V1GPxHp1N31E77E7znszy34pjXYj/wP9yX5fQtIx/Ej1UDkiYW1SpIJOPaamJt89Tm6jNvPqP3nFupMycP/9k=",
                            hmo_host_code: null,
                            mem_password: null,
                            primary_first_name: data.pPrimaryFirstName,
                            primary_last_name: data.pPrimaryLastName,
                            primary_birthdate: data.pPrimaryDateOfBirth,
                            mem_phic_membership_type: null,
                            mem_phic_membership_self_earning_type: null,
                            mem_phic_membership_migrant_worker_type: null,
                            mem_phic_membership_foreign_national_pra_srrv: null,
                            mem_phic_membership_foreign_national_acr_1: null,
                            mem_phic_membership_type_tag: null,
                            philsys_number: null,
                            current_card_key: "1",
                            is_card_ready: "0",
                            is_card_released: "0"
                        }
                    }
                }))
            })).then (response => {
                response.data = this.responseDataDecryption(response.data)
                this.ek_lgu_id = response.data.ek_lgu_id
                console.log(this.ek_lgu_id)
                this.getPatientDM()

            }).catch(error => {
                this.alert = { 
                    display: true, 
                    type: 'standard', 
                    width: '350', 
                    icon: 'mdi-alert-circle', 
                    color: 'red', 
                    title: error, 
                    body: 'Please try again', 
                    btn_pry_txt: 'OK', 
                    btn_pry_color: 'primary', 
                    btn_pry_otl: false,
                    btn_pry_act: 'reloadPage' 
                }
            })   
        },

        async getPatientDM() {
            await this.$axios.post(this.$tms_url+'resources/controller/trn_add_consultation_dm.php',this.$qs.stringify({
                post_data: this.wsDataEncryption(JSON.stringify({
                    hmo_policy_number: null,
                    hmo_host_code: null,
                    ek_phic_id: null,
                    ek_lgu_id: this.ek_lgu_id,
                    lgu_host_code: 'BT',
                    phic_host_code: this.mem_phic_pin? "PHIC":null,
                    mem_phic_pin: this.mem_phic_pin,
                    has_diabetes: '0',
                    family_has_diabetes: '0',
                    family_history_classification: ''
                }))
            })).then(()=> {
                this.releaseCard()
            }).catch(error => {
                this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
            })

            
        },

        async releaseCard() {
            await this.$axios.post(this.$cms_url+'resources/web_service/ws_member_web.php', this.$qs.stringify({
                post_data: this.wsDataEncryption(JSON.stringify({
                key: 'eurekare_key_web',
                data: {
                    command: 322101005,
                    data: {
                        ek_lgu_id: this.ek_lgu_id,
                        current_card_key: '1',
                        is_card_ready: '1',
                        is_card_released: '1',
                        updated_by: this.$store.state.usr_credentials.user_name
                    }
                }
                }))
            }))
            .then(response => {
                console.log(response.data)
                console.log("Released Card")
            })
            .catch( error => {
                this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
            })
        },

        async checkEkonsulta() {
            // await this.$axios.post(this.$cms_url +"resources/api/_get_ekonsulta_eligibility_checker.php", this.$qs.stringify({
            //     post_data: this.wsDataEncryption(JSON.stringify({
            //         pPatientFname: this.member[0].mem_first_name,
            //         pPatientMname: this.member[0].mem_middle_name,
            //         pPatientLname: this.member[0].mem_last_name,
            //         pPatientExtname: this.member[0].mem_suffix,
            //         pPatientDob: this.member[0].mem_birthdate
            //     }))
            //     })).then((response) => {
            //     response.data = this.responseDataDecryption(response.data)
                
            //     this.mem_btn_loader = false
            //     if(response.data.eligible){          
            //         this.ekonsulta_mem = response.data
            //         this.add_atc_code = true
            //     } else {
            //         this.alert = { display: true, type: 'standard', width: '650', icon: 'mdi-alert-circle', color: 'primary', title: 'e-Konsulta Eligibility', body: 'This member is not eligible for eKonsulta. You can register the member through the PhilHealth portal.', btn_pry_color: 'grey darken-2', btn_pry_otl: true, btn_pry_act: 'closeAlert', ekonsulta: true, btn_sec_txt: 'Ok', btn_sec_color: 'primary', btn_sec_otl: false, btn_sec_act: 'loadingBtn',  btn_sec_emt:'confirmSubmit'}
            //     }
            //     }).catch(error => {
            //         this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
            //     });
        },

        async preConsultation() {
            await this.$axios.post(this.$tms_url+"resources/controller/trn_add_consultation.php",this.$qs.stringify({
                post_data: this.wsDataEncryption(JSON.stringify({
                
                hmo_policy_number: null,
                hmo_healthcare_status: null,
                provider_code: "EK8BE7221CB09A2221",
                provider_tin: "",
                provider_name: "Dinalupihan Bataan Rural Health Unit 1 (RHU 1)",
                transaction_type: "PRE CONSULTATION",
                chief_complaint: "Test",
                created_by: "rhu1-ad-archer",
                doc_phic_acc_no: "1100-1432170-1",
                doc_prc_license: "65958",
                approval_code: "N/A",
                hmo_max_coverage_bal: 0,
                consultation_rate: 500,
                room_type: "",
                room_rate: 0,
                is_service_rendered: "0",
                service_feedback: "N/A",
                reason_for_not_rendered: "N/A",
                doctor_tin: "151459528",
                loa_generated_date: "2023-5-31",
                loa_expiration_date: "2023-6-6",
                agent_transaction_status_cc_ref: "0",
                transaction_status: "TO PROCESS",
                request_type: "WEB",
                on_queue: 1,
                processing_by: "rhu1-ad-archer",
                ek_lgu_id: this.ek_lgu_id,
                lgu_host_code: "BT",
                process_type: "LGU",
                host_claim_type: "NOT FOR CLAIMS",
                ek_phic_id: null,
                first_name: this.mem_first_name,
                middle_name: this.mem_middle_name,
                last_name: this.mem_last_name,
                suffix: "",
                birthday: this.mem_birthday,
                mem_phic_pin: this.mem_phic_pin,
                phic_host_code: "PHIC",
                has_emr_record: true,
                patient_medical_history: {
                    past_medical_history: [
                    {
                        mdisease_code: "999",
                        disease: "None"
                    }
                    ],
                    previous_hospitalization: "st lukes",
                    previous_hospitalization_date: "2023-03-01",
                    previous_surgeries: "Incision",
                    allergies: "N/a",
                    has_previous_record: true
                },
                patient_current_medicine: {
                    has_previous_record: false,
                    medicine: []
                },
                family_past_medical_history: {
                    has_previous_record: true,
                    history: [
                    {
                        mdisease_code: "999",
                        family_past_medical_history: "None",
                        family_history_classification: null
                    }
                    ]
                },
                patient_social_history: {
                    has_previous_record: true,
                    social_history: [
                    {
                        social_history: "Non-smoker",
                        years_of_smoked: null,
                        year_stopped_in_smoking: "Stopped < a year",
                        alcohol_consumed_in_5_months: null
                    },
                    {
                        social_history: "Alcoholic",
                        years_of_smoked: null,
                        year_stopped_in_smoking: null,
                        alcohol_consumed_in_5_months: "1"
                    },
                    {
                        social_history: "Illicit Drug User",
                        years_of_smoked: null,
                        year_stopped_in_smoking: null,
                        alcohol_consumed_in_5_months: null
                    },
                    {
                        social_history: "Sexually Active",
                        years_of_smoked: null,
                        year_stopped_in_smoking: null,
                        alcohol_consumed_in_5_months: null
                    }
                    ]
                },
                child_vaccination_record: {},
                patient_record: {
                    height: "161",
                    weight: "54",
                    bmi: 20.83,
                    bmi_remarks: "Normal Weight",
                    height_for_age: "",
                    weight_for_age: "",
                    weight_for_height: "",
                    has_previous_record: true,
                    hip: null,
                    limbs: null,
                    skin_for_thinkness: null,
                    mid_upper_arm_circle: null,
                    head_circle: null,
                    left_vision: "21/21",
                    right_vision: "21/21"
                },
                physical_exam_data: {
                    blood_pressure: "120/80",
                    blood_pressure_2nd: "",
                    blood_pressure_2nd_systolic: "",
                    blood_pressure_2nd_diastolic: "",
                    temp: "36",
                    pulse_rate: "",
                    heart_rate: "89",
                    oxygen_saturation: "",
                    respiration_rate: "32",
                    waist_circumference: "143",
                    central_adiposity: "1"
                },
                general_survey: {
                    general_survey: [
                    "Awake and Alert"
                    ],
                    general_survey_notes: ""
                },
                patient_heent: {
                    heent: [
                    {
                        heent_id: "11",
                        heent: "Essentially Normal"
                    }
                    ],
                    others_notes: ""
                },
                patient_assessment: {
                    chest: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "6",
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    cvs: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "5",
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    musculoskeletal: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: null,
                        assessment: "Essentially Normal"
                        }
                    ]
                    },
                    abdomen: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "7",
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    gui: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "1",
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    skin: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "1",
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    neuro: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "6",
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    pelvic: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: null,
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    rectal: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "1",
                        assessment: "Essentially normal"
                        }
                    ]
                    }
                },
                vaccination_record: null,
                patient_medicine: [],
                diet: "",
                fluid_intake: "",
                follow_up_consultation_date: "",
                purpose_of_visit_service_availed: "General",
                operator_notes: "",
                dietary_intake: {
                    high_fat_salt_intake: "",
                    fiber_intake_fruit: "",
                    fiber_intake_vegetable: "",
                    physical_activity: ""
                },
                patient_symptoms: [
                    {
                    symptom: "None",
                    duration: "",
                    symptoms_id: ""
                    }
                ],
                diagnostic_exam_result: [],
                ncdQans: {
                    ek_lgu_id: this.ek_lgu_id,
                    Qid5_Ynx: "",
                    Qid6_Yn: "",
                    Qid7_Yn: "",
                    Qid8_Yn: "",
                    Qid9_Yn: "",
                    Qid10_Yn: "",
                    Qid11_Yn: "",
                    Qid12_Yn: "",
                    Qid13_Yn: "",
                    Qid14_Yn: "",
                    Qid15_Yn: "",
                    Qid16_Yn: "",
                    Qid17_Abcde: "",
                    Qid18_Yn: "",
                    Qid19_Yn: "",
                    Qid19_Fbsmg: "",
                    Qid19_Fbsmmol: "",
                    Qid20_Yn: "",
                    Qid20_Choleval: "",
                    Qid20_Choledate: "",
                    Qid21_Yn: "",
                    Qid21_Ketonval: "",
                    Qid21_Ketondate: "",
                    Qid22_Yn: "",
                    Qid22_Proteinval: "",
                    Qid22_Proteindate: "",
                    Qid23_Yn: "",
                    Qid24_Yn: "",
                    date_created: "05-31-2023",
                    date_updated: "05-31-2023"
                }

                }))
            })).then((response) => {
                this.transaction_number = response.data.transaction_number
                this.addEkonsulta()

            }).catch(error => {
                this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
            });
        },

        async addEkonsulta() {
            await this.$axios.post(this.$tms_url + 'resources/controller/trn_add_ekonsulta.php', this.$qs.stringify({
                post_data: this.wsDataEncryption(JSON.stringify({
                    transaction_number: this.transaction_number,
                    ek_lgu_id: this.ek_lgu_id,
                    blood_type: null,
                    atc: "WALKEDIN",
                    ekonsulta: {
                        eligible: true,
                        pPatientPin: "190269297569",
                        pPatientFname: "TFSHC FN TWO",
                        pPatientMname: "TFSHC MN TWO",
                        pPatientLname: "TFSHC LN TWO",
                        pPatientExtName: null,
                        pPatientDob: "1974-01-03",
                        pPatientType: "MM",
                        pPatientSex: "F",
                        Prv_Name: "P03033540",
                        pMemPin: "190269297569",
                        pMemFname: "TFSHC FN TWO",
                        pMemMname: "TFSHC MN TWO",
                        pMemLname: "TFSHC LN TWO",
                        pMemExtName: "",
                        pMemDob: "1974-01-03",
                        pEffYear: "2023",
                        pEnlistStat: "1",
                        pEnlistDate: "2023-01-01",
                        pHciCaseNo: "TP0303354020230586936",
                        pPatientMobileNo: "N/A",
                        pPatientAge: "49",
                        mem_category: null
                    },
                    diagnostic_exam_trans_no: null,
                    created_by: "rhu1-ad-archer",
                    is_emr: 0,
                    has_diabetes: true
                }))
            }))
            .then(response => {
                response.data = this.responseDataDecryption(response.data)
                console.log(response.data)
            })
            .catch(error => {
                this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
            })
        },

        async emrConsultation() {
            await this.$axios.post(this.$tms_url+'/resources/controller/trn_upd_pre_consultation.php', this.$qs.stringify({
                post_data: this.wsDataEncryption(JSON.stringify({
                    transaction_number: this.transaction_number,
                    icd_cpt_data: [
                        {
                        icd_code: "A15.1",
                        icd_description: "TUBERCULOSIS OF LUNG, CONFIRMED BY CULTURE ONLY",
                        category_description_id: "",
                        hmo_icd_limit_bal: 0,
                        hmo_icd_status: null,
                        phic_icd_status: null,
                        lgu_icd_status: null,
                        icd_type: "PRIMARY",
                        procedure_list: [
                            {
                            cpt_code: "0012F",
                            cpt_description: "CAP BACTERIAL ASSESS",
                            cpt_amount: 0,
                            hmo_cpt_approved_amount: 0,
                            phic_cpt_status: null,
                            gu_cpt_status: null,
                            hmo_cpt_status: null,
                            hmo_loa_amount: 0,
                            for_hmo_approval: 0,
                            diag_exam_status: "N",
                            physician_recommendation: "Y",
                            patient_remarks: "XX"
                            },
                            {
                            cpt_code: "71020",
                            cpt_description: "CHEST X-RAY",
                            cpt_amount: 0,
                            hmo_cpt_approved_amount: 0,
                            phic_cpt_status: null,
                            lgu_cpt_status: null,
                            hmo_cpt_status: null,
                            hmo_loa_amount: 0,
                            for_hmo_approval: 0,
                            diag_exam_status: "N",
                            physician_recommendation: "Y",
                            patient_remarks: "XX"
                            }
                        ]
                        }
                    ],
                    patient_medicine: [],
                    date_admitted: "2023-05-31",
                    date_discharged: "2023-05-31",
                    transaction_type: "CONSULTATION",
                    transaction_status: "ISSUED",
                    treatment_recommendation: "OUTPATIENT",
                    notes_management: {
                        lib_id: 0,
                        doctor_notes: null
                    }
                }))
            }))
            .then(() => {

            })
            .catch(error => {
                this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
            })
        },

        async preCons() {
            await this.$axios.post(this.$tms_url+"resources/controller/trn_add_consultation.php",this.$qs.stringify({
                post_data: this.wsDataEncryption(JSON.stringify({

                hmo_policy_number: null,
                hmo_healthcare_status: null,
                provider_code: "EK8BE7221CB09A2221",
                provider_tin: "",
                provider_name: "Dinalupihan Bataan Rural Health Unit 1 (RHU 1)",
                transaction_type: "PRE CONSULTATION",
                chief_complaint: "Test",
                created_by: "rhu1-ad-archer",
                doc_phic_acc_no: "1100-1432170-1",
                doc_prc_license: "65958",
                approval_code: "N/A",
                hmo_max_coverage_bal: 0,
                consultation_rate: 500,
                room_type: "",
                room_rate: 0,
                is_service_rendered: "0",
                service_feedback: "N/A",
                reason_for_not_rendered: "N/A",
                doctor_tin: "151459528",
                loa_generated_date: "2023-5-31",
                loa_expiration_date: "2023-6-6",
                agent_transaction_status_cc_ref: "0",
                transaction_status: "TO PROCESS",
                request_type: "WEB",
                on_queue: 1,
                processing_by: "rhu1-ad-archer",
                ek_lgu_id: "EK-NRF6D1974T18-5033",
                lgu_host_code: "BT",
                process_type: "LGU",
                host_claim_type: "NOT FOR CLAIMS",
                ek_phic_id: null,
                first_name: "TFSHC FN TWO",
                middle_name: "TFSHC MN TWO",
                last_name: "TFSHC LN TWO",
                suffix: "",
                birthday: "1974-01-03",
                mem_phic_pin: "190269297569",
                phic_host_code: "PHIC",
                has_emr_record: true,
                patient_medical_history: {
                    past_medical_history: [
                    {
                        mdisease_code: "999",
                        disease: "None"
                    }
                    ],
                    previous_hospitalization: "st lukes",
                    previous_hospitalization_date: "2023-03-01",
                    previous_surgeries: "Incision",
                    allergies: "N/a",
                    has_previous_record: true
                },
                patient_current_medicine: {
                    has_previous_record: false,
                    medicine: []
                },
                family_past_medical_history: {
                    has_previous_record: true,
                    history: [
                    {
                        mdisease_code: "006",
                        family_past_medical_history: "Diabetes Mellitus",
                        family_history_classification: "Paternal"
                    }
                    ]
                },
                patient_social_history: {
                    has_previous_record: true,
                    social_history: [
                    {
                        social_history: "Non-smoker",
                        years_of_smoked: null,
                        year_stopped_in_smoking: "Stopped < a year",
                        alcohol_consumed_in_5_months: null
                    },
                    {
                        social_history: "Alcoholic",
                        years_of_smoked: null,
                        year_stopped_in_smoking: null,
                        alcohol_consumed_in_5_months: "1"
                    },
                    {
                        social_history: "Illicit Drug User",
                        years_of_smoked: null,
                        year_stopped_in_smoking: null,
                        alcohol_consumed_in_5_months: null
                    },
                    {
                        social_history: "Sexually Active",
                        years_of_smoked: null,
                        year_stopped_in_smoking: null,
                        alcohol_consumed_in_5_months: null
                    }
                    ]
                },
                child_vaccination_record: {},
                patient_record: {
                    height: "161",
                    weight: "54",
                    bmi: 20.83,
                    bmi_remarks: "Normal Weight",
                    height_for_age: "",
                    weight_for_age: "",
                    weight_for_height: "",
                    has_previous_record: true,
                    hip: null,
                    limbs: null,
                    skin_for_thinkness: null,
                    mid_upper_arm_circle: null,
                    head_circle: null,
                    left_vision: "21/21",
                    right_vision: "21/21"
                },
                physical_exam_data: {
                    blood_pressure: "120/80",
                    blood_pressure_2nd: "",
                    blood_pressure_2nd_systolic: "",
                    blood_pressure_2nd_diastolic: "",
                    temp: "35",
                    pulse_rate: "",
                    heart_rate: "89",
                    oxygen_saturation: "",
                    respiration_rate: "32",
                    waist_circumference: "121",
                    central_adiposity: "1"
                },
                general_survey: {
                    general_survey: [
                    "Awake and Alert"
                    ],
                    general_survey_notes: ""
                },
                patient_heent: {
                    heent: [
                    {
                        heent_id: "11",
                        heent: "Essentially Normal"
                    }
                    ],
                    others_notes: ""
                },
                patient_assessment: {
                    chest: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "6",
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    cvs: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "5",
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    musculoskeletal: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: null,
                        assessment: "Essentially Normal"
                        }
                    ]
                    },
                    abdomen: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "7",
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    gui: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "1",
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    skin: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "1",
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    neuro: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "6",
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    pelvic: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: null,
                        assessment: "Essentially normal"
                        }
                    ]
                    },
                    rectal: {
                    others_notes: "",
                    assessment: [
                        {
                        assessment_id: "1",
                        assessment: "Essentially normal"
                        }
                    ]
                    }
                },
                vaccination_record: null,
                patient_medicine: [],
                diet: "",
                fluid_intake: "",
                follow_up_consultation_date: "",
                purpose_of_visit_service_availed: "General",
                operator_notes: "",
                dietary_intake: {
                    high_fat_salt_intake: "",
                    fiber_intake_fruit: "",
                    fiber_intake_vegetable: "",
                    physical_activity: ""
                },
                patient_symptoms: [
                    {
                    symptom: "None",
                    duration: "",
                    symptoms_id: ""
                    }
                ],
                diagnostic_exam_result: {
                    transaction_number: "V0TIC2RXNAFW",
                    data: [
                    {
                        libId: "99",
                        libDesc: "Others",
                        cpt_code: "0012F",
                        pDiagStatus: "Done",
                        pReferralFacility: "Test",
                        pLabDate: "2023-05-31",
                        pOtherDiagnosticExam: "CAP BACTERIAL ASSESS",
                        pFindings: "Test",
                        pDiagnosticLabFee: "2121"
                    },
                    {
                        lib_findings: "LIB_CHESTXRAY_FINDINGS",
                        lib_observation: "LIB_CHESTXRAY_OBSERVATION",
                        libDesc: "CHEST X-RAY",
                        cpt_code: "71020",
                        pDiagStatus: "Done",
                        pReferralFacility: "Test",
                        pLabDate: "2023-05-31",
                        pFinds: {
                        LibDesc: "BRONCHIOLITIS",
                        LibID: "10"
                        },
                        pFindings: "10",
                        pRemarksFindings: "21",
                        pObs: {
                        LibDesc: "CONSOLIDATION",
                        LibID: "3"
                        },
                        pObservation: "3",
                        pRemarksObservation: "Test",
                        pDiagnosticLabFee: "211"
                    }
                    ]
                },
                ncdQans: {
                    ek_lgu_id: "EK-NRF6D1974T18-5033",
                    Qid5_Ynx: "",
                    Qid6_Yn: "",
                    Qid7_Yn: "",
                    Qid8_Yn: "",
                    Qid9_Yn: "",
                    Qid10_Yn: "",
                    Qid11_Yn: "",
                    Qid12_Yn: "",
                    Qid13_Yn: "",
                    Qid14_Yn: "",
                    Qid15_Yn: "",
                    Qid16_Yn: "",
                    Qid17_Abcde: "",
                    Qid18_Yn: "",
                    Qid19_Yn: "",
                    Qid19_Fbsmg: "",
                    Qid19_Fbsmmol: "",
                    Qid20_Yn: "",
                    Qid20_Choleval: "",
                    Qid20_Choledate: "",
                    Qid21_Yn: "",
                    Qid21_Ketonval: "",
                    Qid21_Ketondate: "",
                    Qid22_Yn: "",
                    Qid22_Proteinval: "",
                    Qid22_Proteindate: "",
                    Qid23_Yn: "",
                    Qid24_Yn: "",
                    date_created: "05-31-2023",
                    date_updated: "05-31-2023"
                }
                
                }))
            })).then((response) => {
                this.transaction_number = response.data.transaction_number
                this.addEkonsulta()

            }).catch(error => {
                this.alert = { display: true, type: 'standard', width: '350', icon: 'mdi-alert-circle', color: 'red', title: error, body: 'Please try again', btn_pry_txt: 'OK', btn_pry_color: 'primary', btn_pry_otl: false, btn_pry_act: 'reloadPage' }
            });
        }

    }
}
</script>