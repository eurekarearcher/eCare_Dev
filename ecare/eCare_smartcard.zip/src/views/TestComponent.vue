<template>
  <v-container>
    <v-tabs v-model="tab"  class="card-border px-1" active-class="active-tab" hide-slider outlined>
          <v-tab class="non-active-tab">Data Decryption</v-tab>
          <v-tab class="non-active-tab" disabled>Data Encryption</v-tab>
    </v-tabs>
                
    <v-tabs-items v-model="tab"  class="px-1 mb-7" ref="tabs" touchless>
      <v-tab-item>
        <v-card width="800" class="mx-auto px-5 pb-5 my-4" style="overflow:auto;">
          <v-card-title class="px-0">Single Decryption</v-card-title>
          <v-text-field v-model="single_value" placeholder="Enter Value Here"  hide-details outlined dense></v-text-field>
          <v-card-actions class="px-0">
            <v-btn @click="decrypt('single')" class="ml-auto" color="primary" small dark>Decrypt <v-icon small right>mdi-send</v-icon></v-btn>
          </v-card-actions>
          
          <v-divider class="my-2"></v-divider>

          <v-card-title class="px-0">Object Decryption</v-card-title>
          <v-text-field v-model="obj_value" placeholder="Enter Value Here"  hide-details outlined dense></v-text-field>
          <v-card-actions class="px-0">
            <v-btn @click="decrypt('obj')" class="ml-auto" color="primary" small dark>Decrypt <v-icon small right>mdi-send</v-icon></v-btn>
          </v-card-actions>

          <v-divider class="my-2"></v-divider>

          <div v-show="show_decrypted">
            <v-card-subtitle class="px-0 font-weight-medium">DECRYPTED DATA</v-card-subtitle>
            <h6>
              <pre>
              {{this.dec_result}}
              </pre>
            </h6>
          </div>
    
          <v-card-title class="px-0">API/Controller</v-card-title>
          <v-text-field v-model="request_url" placeholder="Request URL" class="mb-4"  hide-details outlined dense></v-text-field>
          <v-text-field v-model="payload" placeholder="Encrypted Payload" class="mb-4"  hide-details outlined dense></v-text-field>
          <v-card-actions class="px-0">
            <v-btn @click="submitRequest()" class="ml-auto" color="primary" small dark>Submit Request <v-icon small right>mdi-send</v-icon></v-btn>
          </v-card-actions>
          
          <v-divider class="my-2"></v-divider>

          <div v-show="data_response">
            <v-card-subtitle class="px-0 font-weight-medium">DATA RESPONSE</v-card-subtitle>
            <h6>
              <pre>
              {{this.data_response}}
              </pre>
            </h6>
          </div>

          <!-- <div v-show="show_decrypted">
            <v-card-subtitle class="px-0 font-weight-medium">DECRYPTED DATA</v-card-subtitle>
            <h6>
              <pre>
              {{this.dec_result}}
              </pre>
            </h6>
          </div>
    -->

   <v-form>
    <v-btn @click="usbSmartCard"> READ USB SMART CARD </v-btn> 
    <v-btn @click="clicks"> GET LOCAL IP ADDRESS </v-btn>
    <v-btn @click="readCard"> Read Card </v-btn> 
    </v-form>
    </v-card>
      </v-tab-item>

      <v-tab-item>
        <v-card width="800" class="mx-auto  my-6" style="overflow:auto;">
          <v-tabs v-model="encrypt_tab"  class="card-border px-1" active-class="active-tab" hide-slider outlined>
                <v-tab class="non-active-tab">Input Text</v-tab>
                <v-tab class="non-active-tab">Pre Text</v-tab>
          </v-tabs>
          <v-tabs-items v-model="encrypt_tab"  class="px-1 mb-7" ref="tabs" touchless>
            <v-tab-item>
              <div class="px-5 pb-5">
                <v-sheet class="d-flex justify-end mt-4"> 
                  <v-btn @click="addParameter" color="primary" small> Add parameter </v-btn>
                </v-sheet>
                
                <v-row v-for="(data, i) in encrypted_json_holder" :key="i" dense> 
                  <v-col>
                    <v-text-field v-model="data.key" label="Key" hide-details> </v-text-field>
                  </v-col>
                  <v-col>
                    <v-text-field v-model="data.value" label="value" @click:append="clearField(i)" append-icon="mdi mdi-delete" hide-details> </v-text-field>
                  </v-col>
                </v-row>
                
              </div>
            </v-tab-item>
            <v-tab-item>
                <v-sheet class="ma-4">
                  <h4 class="body-2 mb-4"> Type JSON Format </h4>
                  <v-textarea v-model="list_of_payload" rows="12" outlined> </v-textarea>
                </v-sheet>
            </v-tab-item>

            <div class="mx-4">
              <v-sheet class="d-flex justify-end mt-4"> 
                <v-btn @click="encryptPayload" color="primary" small> Encrypt Data </v-btn>
              </v-sheet>
              
              <v-sheet class="mt-4">
                <v-textarea v-model="encrypted_payload" outlined readonly> </v-textarea>
              </v-sheet>
              <v-sheet class="d-flex justify-end"> 
                <v-btn @click="clearFieldItems" class="mr-4" small> Clear </v-btn>
                <v-btn @click="copyToClipboard" color="success" small> Copy </v-btn>
              </v-sheet>
            </div>
          </v-tabs-items>
        </v-card>
      </v-tab-item>
    </v-tabs-items>

    
  </v-container>
</template>

<script>
import axios from 'axios'
import mixin from '@/mixin'

export default {
  data() {
    return {
      tab: '',
      encrypt_tab: '',
      dec_result: '',
      obj_value:'',
      single_value: '',
      show_decrypted: false,

      for_decryption: false,

      file_upload: [],
      user_ip_address: '',
      request_url: '',
      payload: '',
      cms_tms: '',
      data_response: '',

      encrypted_json_holder: [{ key: null, value: null }],
      encrypted_payload: null,
      list_of_payload: '',

      med_data: [
  {
    "date": "1/2/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Acetylcysteine",
    "brand_name": "Cysaphteine-600",
    "dosage": "600mg",
    "form": "Powder for Oral Solution",
    "lot_number": "NCY123",
    "expiration_date": "1/1/2027",
    "boxes": "10",
    "pieces_per_box": "10",
    "total_qty": 100
  },
  {
    "date": "1/2/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Amlodipine",
    "brand_name": "Diadipine",
    "dosage": "5mg",
    "form": "Tablet",
    "lot_number": "132447",
    "expiration_date": "11/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/2/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cefalexin",
    "brand_name": "Exel",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "101ADB",
    "expiration_date": "4/1/2027",
    "boxes": "3",
    "pieces_per_box": "100",
    "total_qty": 300
  },
  {
    "date": "1/2/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Chlorphenamine Maleate",
    "brand_name": "Mervilar",
    "dosage": "4mg",
    "form": "Tablet",
    "lot_number": "443108",
    "expiration_date": "5/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/2/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Mefenamic Acid",
    "brand_name": "Myrefen",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "079ACN",
    "expiration_date": "3/1/2027",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/2/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Multivitamins",
    "brand_name": "Myrevit",
    "dosage": "--",
    "form": "Capsule",
    "lot_number": "152ABN",
    "expiration_date": "2/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/2/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Omeprazole",
    "brand_name": "Omephil-20",
    "dosage": "20mg",
    "form": "Capsule",
    "lot_number": "BI0074",
    "expiration_date": "8/1/2025",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/2/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Sambong Leaf",
    "brand_name": "MIA Forte",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "B24006",
    "expiration_date": "2/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Acetylcysteine",
    "brand_name": "Cysaphteine-600",
    "dosage": "600mg",
    "form": "Powder for Oral Solution",
    "lot_number": "NCY123",
    "expiration_date": "1/1/2027",
    "boxes": "10",
    "pieces_per_box": "10",
    "total_qty": 100
  },
  {
    "date": "1/6/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Amlodipine",
    "brand_name": "Diadipine",
    "dosage": "5mg",
    "form": "Tablet",
    "lot_number": "132447",
    "expiration_date": "11/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Amoxicillin",
    "brand_name": "Ambimox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "706240297",
    "expiration_date": "2/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cefixime",
    "brand_name": "Saphixime 400",
    "dosage": "400mg",
    "form": "Tablet",
    "lot_number": "NSIX01",
    "expiration_date": "3/1/2026",
    "boxes": "20",
    "pieces_per_box": "10",
    "total_qty": 200
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cetirizine",
    "brand_name": "Reax",
    "dosage": "2.5mg/mL",
    "form": "Oral Drops",
    "lot_number": "C24125",
    "expiration_date": "3/1/2026",
    "boxes": "--",
    "pieces_per_box": "114 bottles",
    "total_qty": "114 bottles"
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cloxacillin",
    "brand_name": "Philclox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "233133042",
    "expiration_date": "11/1/2025",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Lagundi",
    "brand_name": "Ofplemed",
    "dosage": "300mg",
    "form": "Tablet",
    "lot_number": "2305156",
    "expiration_date": "5/1/2026",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Mefenamic Acid",
    "brand_name": "Mecid",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "230687",
    "expiration_date": "6/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Multivitamins",
    "brand_name": "Myrevit",
    "dosage": "--",
    "form": "Capsule",
    "lot_number": "093ABN",
    "expiration_date": "2/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Naproxen",
    "brand_name": "Proxen",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "4D117",
    "expiration_date": "4/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Norfloxacin",
    "brand_name": "Urinox 400",
    "dosage": "400mg",
    "form": "Tablet",
    "lot_number": "U-01032",
    "expiration_date": "11/1/2025",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "ORS-75 Replacement",
    "brand_name": "Dehydrosol",
    "dosage": "--",
    "form": "Powder for Oral Solution",
    "lot_number": "4C50",
    "expiration_date": "3/1/2027",
    "boxes": "10",
    "pieces_per_box": "25",
    "total_qty": 250
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Paracetamol",
    "brand_name": "Hyfer-250",
    "dosage": "250mg/5mL",
    "form": "Oral Suspension",
    "lot_number": "L20644A",
    "expiration_date": "11/1/2025",
    "boxes": "--",
    "pieces_per_box": "144 bottles",
    "total_qty": "144 bottles"
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Paracetamol",
    "brand_name": "Philpara",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "220762",
    "expiration_date": "7/1/2025",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "PP+CPM+Paracetamol",
    "brand_name": "Symdex-D",
    "dosage": "25mg/2mg/325mg",
    "form": "Tablet",
    "lot_number": "25123286",
    "expiration_date": "7/1/2026",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/6/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Simvastatin",
    "brand_name": "Simvasyn",
    "dosage": "20mg",
    "form": "Tablet",
    "lot_number": "CD0115",
    "expiration_date": "3/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/9/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Amlodipine",
    "brand_name": "Diadipine",
    "dosage": "5mg",
    "form": "Tablet",
    "lot_number": "132447",
    "expiration_date": "11/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/9/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cefixime",
    "brand_name": "Saphixime 400",
    "dosage": "400mg",
    "form": "Tablet",
    "lot_number": "NSIX01",
    "expiration_date": "3/1/2026",
    "boxes": "40",
    "pieces_per_box": "10",
    "total_qty": 400
  },
  {
    "date": "1/9/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Celecoxib",
    "brand_name": "Saphlecox-400",
    "dosage": "400mg",
    "form": "Capsule",
    "lot_number": "NOF11",
    "expiration_date": "2/1/2027",
    "boxes": "3",
    "pieces_per_box": "100",
    "total_qty": 300
  },
  {
    "date": "1/9/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cinnarizine",
    "brand_name": "Vertex",
    "dosage": "25mg",
    "form": "Tablet",
    "lot_number": "4B144",
    "expiration_date": "3/1/2027",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/9/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Multivitamins",
    "brand_name": "Myrevit",
    "dosage": "--",
    "form": "Capsule",
    "lot_number": "093ABN",
    "expiration_date": "2/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/9/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "PP+CPM+Paracetamol",
    "brand_name": "Symdex-D",
    "dosage": "25mg/2mg/325mg",
    "form": "Tablet",
    "lot_number": "25123286",
    "expiration_date": "7/1/2026",
    "boxes": "3",
    "pieces_per_box": "100",
    "total_qty": 300
  },
  {
    "date": "1/13/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Metformin",
    "brand_name": "Glycemet",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "240201",
    "expiration_date": "2/1/2027",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "1/13/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Multivitamins",
    "brand_name": "Myrevit",
    "dosage": "--",
    "form": "Capsule",
    "lot_number": "093ABN",
    "expiration_date": "2/1/2026",
    "boxes": "15",
    "pieces_per_box": "100",
    "total_qty": 1500
  },
  {
    "date": "1/14/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Amlodipine",
    "brand_name": "Diadipine",
    "dosage": "5mg",
    "form": "Tablet",
    "lot_number": "132447",
    "expiration_date": "11/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Amoxicillin",
    "brand_name": "Ambimox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "706240297",
    "expiration_date": "2/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Celecoxib",
    "brand_name": "Saphlecox-400",
    "dosage": "400mg",
    "form": "Capsule",
    "lot_number": "NOF11",
    "expiration_date": "2/1/2027",
    "boxes": "3",
    "pieces_per_box": "100",
    "total_qty": 300
  },
  {
    "date": "1/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Chlorphenamine Maleate",
    "brand_name": "Mervilar",
    "dosage": "4mg",
    "form": "Tablet",
    "lot_number": "443108",
    "expiration_date": "5/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cloxacillin",
    "brand_name": "Philclox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "233133023",
    "expiration_date": "5/1/2025",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Lagundi",
    "brand_name": "Ofplemed",
    "dosage": "300mg",
    "form": "Tablet",
    "lot_number": "2305156",
    "expiration_date": "5/1/2026",
    "boxes": "15",
    "pieces_per_box": "100",
    "total_qty": 1500
  },
  {
    "date": "1/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Mefenamic Acid",
    "brand_name": "Myrefen",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "ZJN157",
    "expiration_date": "9/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Metformin",
    "brand_name": "Glycemet",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "240201",
    "expiration_date": "2/1/2027",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "1/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "PP+CPM+Paracetamol",
    "brand_name": "Symdex-D",
    "dosage": "25mg/2mg/325mg",
    "form": "Tablet",
    "lot_number": "25123286",
    "expiration_date": "7/1/2026",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Simvastatin",
    "brand_name": "Simvasyn",
    "dosage": "20mg",
    "form": "Tablet",
    "lot_number": "CD0115",
    "expiration_date": "3/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/17/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Lagundi",
    "brand_name": "Ofplemed",
    "dosage": "300mg/5mL",
    "form": "Syrup",
    "lot_number": "2406118",
    "expiration_date": "6/1/2027",
    "boxes": "--",
    "pieces_per_box": "144 bottles",
    "total_qty": "144 bottles"
  },
  {
    "date": "1/17/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Metformin",
    "brand_name": "Glycemet",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "221013",
    "expiration_date": "10/1/2025",
    "boxes": "58",
    "pieces_per_box": "100",
    "total_qty": 5800
  },
  {
    "date": "1/17/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Multivitamins",
    "brand_name": "Multi Vita",
    "dosage": "--",
    "form": "Capsule",
    "lot_number": "240712",
    "expiration_date": "7/18/2027",
    "boxes": "100",
    "pieces_per_box": "100",
    "total_qty": 10000
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Amlodipine",
    "brand_name": "Diadipine",
    "dosage": "5mg",
    "form": "Tablet",
    "lot_number": "132447",
    "expiration_date": "11/1/2026",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Amoxicillin",
    "brand_name": "Ambimox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "706240523",
    "expiration_date": "5/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Ascorbic Acid",
    "brand_name": "Ascophil",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "240582",
    "expiration_date": "5/1/2026",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Atorvastatin",
    "brand_name": "Lestor",
    "dosage": "20mg",
    "form": "Tablet",
    "lot_number": "240507",
    "expiration_date": "5/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cefixime",
    "brand_name": "Saphixime 400",
    "dosage": "400mg",
    "form": "Tablet",
    "lot_number": "NSIX01",
    "expiration_date": "3/1/2026",
    "boxes": "50",
    "pieces_per_box": "10",
    "total_qty": 500
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Celecoxib",
    "brand_name": "Saphlecox-400",
    "dosage": "400mg",
    "form": "Capsule",
    "lot_number": "NOF11",
    "expiration_date": "2/1/2027",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cinnarizine",
    "brand_name": "Vertex",
    "dosage": "25mg",
    "form": "Tablet",
    "lot_number": "4B144",
    "expiration_date": "3/1/2027",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Ciprofloxacin",
    "brand_name": "Cyfrox",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "233123012",
    "expiration_date": "2/1/2026",
    "boxes": "50",
    "pieces_per_box": "100",
    "total_qty": 5000
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Lagundi",
    "brand_name": "Ofplemed",
    "dosage": "300mg",
    "form": "Tablet",
    "lot_number": "2305156",
    "expiration_date": "5/1/2026",
    "boxes": "35",
    "pieces_per_box": "100",
    "total_qty": 3500
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Losartan",
    "brand_name": "Losaar 100",
    "dosage": "100mg",
    "form": "Tablet",
    "lot_number": "240527",
    "expiration_date": "5/1/2027",
    "boxes": "33",
    "pieces_per_box": "100",
    "total_qty": 3300
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Metformin",
    "brand_name": "Glycemet",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "240201",
    "expiration_date": "2/1/2027",
    "boxes": "15",
    "pieces_per_box": "100",
    "total_qty": 1500
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Metoprolol",
    "brand_name": "Prometin",
    "dosage": "50mg",
    "form": "Tablet",
    "lot_number": "NPR358",
    "expiration_date": "9/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Paracetamol",
    "brand_name": "Milgesic Forte",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "254093",
    "expiration_date": "3/1/2027",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Paracetamol",
    "brand_name": "Parasaph-250",
    "dosage": "250mg/5mL",
    "form": "Suspension",
    "lot_number": "ANR-05",
    "expiration_date": "1/1/2027",
    "boxes": "--",
    "pieces_per_box": "100 bottles",
    "total_qty": "100 bottles"
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "PP+CPM+Paracetamol",
    "brand_name": "Symdex-D",
    "dosage": "25mg/2mg/325mg",
    "form": "Tablet",
    "lot_number": "25123286",
    "expiration_date": "7/1/2026",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Vitamin B Complex",
    "brand_name": "Nervita 100",
    "dosage": "100mg/5mg/50mcg",
    "form": "Tablet",
    "lot_number": "2406026",
    "expiration_date": "6/1/2026",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "1/28/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Amlodipine Besilate",
    "brand_name": "Regivasc",
    "dosage": "5mg",
    "form": "Tablet",
    "lot_number": "2405080",
    "expiration_date": "5/1/2029",
    "boxes": "28",
    "pieces_per_box": "100",
    "total_qty": 2800
  },
  {
    "date": "1/28/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Amoxicillin",
    "brand_name": "Ambimox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "706240523",
    "expiration_date": "5/1/2027",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/28/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Amoxicillin",
    "brand_name": "Eppitrexil",
    "dosage": "100mg/mL",
    "form": "Powder for Suspension",
    "lot_number": "161ADB",
    "expiration_date": "4/1/2027",
    "boxes": "--",
    "pieces_per_box": "144 bottles",
    "total_qty": "144 bottles"
  },
  {
    "date": "1/28/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Atorvastatin",
    "brand_name": "Lestor",
    "dosage": "20mg",
    "form": "Tablet",
    "lot_number": "240507",
    "expiration_date": "5/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/28/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cloxacillin",
    "brand_name": "Philclox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "233133042",
    "expiration_date": "11/1/2025",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/28/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Co-Amoxiclav",
    "brand_name": "Asiclav-625",
    "dosage": "625mg",
    "form": "Tablet",
    "lot_number": "687240410",
    "expiration_date": "4/1/2026",
    "boxes": "16",
    "pieces_per_box": "14",
    "total_qty": 224
  },
  {
    "date": "1/28/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Mefenamic Acid",
    "brand_name": "Mecid",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "240502",
    "expiration_date": "5/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/28/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Omeprazole",
    "brand_name": "Omephil-20",
    "dosage": "20mg",
    "form": "Capsule",
    "lot_number": "BI0074",
    "expiration_date": "8/1/2025",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/28/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "ORS-75 Replacement",
    "brand_name": "Dehydrosol",
    "dosage": "--",
    "form": "Powder for Oral Solution",
    "lot_number": "4C50",
    "expiration_date": "3/1/2027",
    "boxes": "10",
    "pieces_per_box": "25",
    "total_qty": 250
  },
  {
    "date": "1/28/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "PP+CPM+Paracetamol",
    "brand_name": "Symdex-D",
    "dosage": "25mg/2mg/325mg",
    "form": "Tablet",
    "lot_number": "25123285",
    "expiration_date": "7/1/2026",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/28/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Sodium Ascorbate + Zinc",
    "brand_name": "Maxicor Plus",
    "dosage": "500mg/10mg",
    "form": "Capsule",
    "lot_number": "2409096",
    "expiration_date": "9/1/2027",
    "boxes": "13",
    "pieces_per_box": "100",
    "total_qty": 1300
  },
  {
    "date": "1/28/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Vitamin B Complex",
    "brand_name": "Nervita 100",
    "dosage": "100mg/5mg/50mcg",
    "form": "Tablet",
    "lot_number": "2406026",
    "expiration_date": "6/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/28/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Vitamin B Complex",
    "brand_name": "Amcovit-B",
    "dosage": "100mg/10mg/50mcg",
    "form": "Tablet",
    "lot_number": "240481",
    "expiration_date": "4/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/30/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Amoxicillin",
    "brand_name": "Ambimox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "706240297",
    "expiration_date": "2/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "1/30/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Ascorbic Acid",
    "brand_name": "Myrevit-C",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "2GN040",
    "expiration_date": "7/1/2025",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "1/30/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Celecoxib",
    "brand_name": "Saphlecox-400",
    "dosage": "400mg",
    "form": "Capsule",
    "lot_number": "NOF11",
    "expiration_date": "2/1/2027",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/30/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Chlorphenamine Maleate",
    "brand_name": "Mervilar",
    "dosage": "4mg",
    "form": "Tablet",
    "lot_number": "443108",
    "expiration_date": "5/1/2026",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "1/30/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cotrimoxazole",
    "brand_name": "Kathrex",
    "dosage": "800mg/160mg",
    "form": "Tablet",
    "lot_number": "ZGN179",
    "expiration_date": "7/1/2026",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/30/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Paracetamol",
    "brand_name": "Parasaph-250",
    "dosage": "250mg/5mL",
    "form": "Suspension",
    "lot_number": "ANR-05",
    "expiration_date": "1/1/2027",
    "boxes": "--",
    "pieces_per_box": "100 bottles",
    "total_qty": "100 bottles"
  },
  {
    "date": "1/30/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "PP+CPM+Paracetamol",
    "brand_name": "Symdex-D",
    "dosage": "25mg/2mg/325mg",
    "form": "Tablet",
    "lot_number": "25123285",
    "expiration_date": "7/1/2026",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "1/30/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Vitamin B Complex",
    "brand_name": "Nervita 100",
    "dosage": "100mg/5mg/50mcg",
    "form": "Tablet",
    "lot_number": "2406026",
    "expiration_date": "6/1/2026",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Allopurinol",
    "brand_name": "Alluprex",
    "dosage": "300mg",
    "form": "Tablet",
    "lot_number": "052AFN",
    "expiration_date": "6/1/2026",
    "boxes": "36",
    "pieces_per_box": "100",
    "total_qty": 3600
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Amlodipine Besilate",
    "brand_name": "Regivasc",
    "dosage": "5mg",
    "form": "Tablet",
    "lot_number": "2405078",
    "expiration_date": "5/1/2029",
    "boxes": "30",
    "pieces_per_box": "100",
    "total_qty": 3000
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Amoxicillin",
    "brand_name": "Ambimox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "706240523",
    "expiration_date": "5/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Amoxicillin",
    "brand_name": "Axmel",
    "dosage": "250mg/5mL",
    "form": "Powder for Suspension",
    "lot_number": "206AGB",
    "expiration_date": "7/1/2027",
    "boxes": "--",
    "pieces_per_box": "144 bottles",
    "total_qty": "144 bottles"
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Amoxicillin",
    "brand_name": "Eppitrexil",
    "dosage": "100mg/mL",
    "form": "Powder for Suspension",
    "lot_number": "161ADB",
    "expiration_date": "4/1/2027",
    "boxes": "--",
    "pieces_per_box": "144 bottles",
    "total_qty": "144 bottles"
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Atorvastatin",
    "brand_name": "Lestor",
    "dosage": "20mg",
    "form": "Tablet",
    "lot_number": "240507",
    "expiration_date": "5/1/2027",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Betahistine",
    "brand_name": "Betzine",
    "dosage": "16mg",
    "form": "Tablet",
    "lot_number": "EGT240197",
    "expiration_date": "6/1/2027",
    "boxes": "12",
    "pieces_per_box": "100",
    "total_qty": 1200
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Cefalexin",
    "brand_name": "Edexin",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "289ACB",
    "expiration_date": "3/1/2027",
    "boxes": "15",
    "pieces_per_box": "100",
    "total_qty": 1500
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Cefalexin",
    "brand_name": "Exel",
    "dosage": "100mg/mL (10mL)",
    "form": "Powder for Suspension",
    "lot_number": "292ACB",
    "expiration_date": "3/1/2027",
    "boxes": "--",
    "pieces_per_box": "144 bottles",
    "total_qty": "144 bottles"
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cetirizine",
    "brand_name": "Reax",
    "dosage": "2.5mg/mL",
    "form": "Oral Drops",
    "lot_number": "C24125",
    "expiration_date": "3/1/2026",
    "boxes": "--",
    "pieces_per_box": "144 bottles",
    "total_qty": "144 bottles"
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Chlorphenamine Maleate",
    "brand_name": "Mervilar",
    "dosage": "4mg",
    "form": "Tablet",
    "lot_number": "443108",
    "expiration_date": "5/1/2026",
    "boxes": "13",
    "pieces_per_box": "100",
    "total_qty": 1300
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cloxacillin",
    "brand_name": "Philclox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "233133042",
    "expiration_date": "11/1/2025",
    "boxes": "15",
    "pieces_per_box": "100",
    "total_qty": 1500
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Co-Amoxiclav",
    "brand_name": "Asiclav-625",
    "dosage": "625mg",
    "form": "Tablet",
    "lot_number": "687240410",
    "expiration_date": "4/1/2026",
    "boxes": "45",
    "pieces_per_box": "14",
    "total_qty": 630
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Hyoscine N-Butylbromide",
    "brand_name": "Hyopan",
    "dosage": "10mg",
    "form": "Tablet",
    "lot_number": "B10205",
    "expiration_date": "8/1/2025",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Lagundi",
    "brand_name": "Asflem",
    "dosage": "300mg",
    "form": "Tablet",
    "lot_number": "24D493",
    "expiration_date": "7/1/2026",
    "boxes": "55",
    "pieces_per_box": "100",
    "total_qty": 5500
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Losartan",
    "brand_name": "Losaar 50",
    "dosage": "50mg",
    "form": "Tablet",
    "lot_number": "240442",
    "expiration_date": "4/1/2027",
    "boxes": "27",
    "pieces_per_box": "100",
    "total_qty": 2700
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Losartan",
    "brand_name": "Losaar 100",
    "dosage": "100mg",
    "form": "Tablet",
    "lot_number": "240527",
    "expiration_date": "5/1/2027",
    "boxes": "50",
    "pieces_per_box": "100",
    "total_qty": 5000
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Mefenamic Acid",
    "brand_name": "Mecid",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "240502",
    "expiration_date": "5/1/2027",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Mefenamic Acid",
    "brand_name": "Myrefen",
    "dosage": "50mg/5mL",
    "form": "Suspension",
    "lot_number": "ZHN036",
    "expiration_date": "8/1/2026",
    "boxes": "--",
    "pieces_per_box": "60 bottles",
    "total_qty": "60 bottles"
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Metformin",
    "brand_name": "Glycemet",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "240405",
    "expiration_date": "4/1/2027",
    "boxes": "50",
    "pieces_per_box": "100",
    "total_qty": 5000
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Multivitamins",
    "brand_name": "Myrevit",
    "dosage": "--",
    "form": "Capsule",
    "lot_number": "191AEN",
    "expiration_date": "5/1/2026",
    "boxes": "22",
    "pieces_per_box": "100",
    "total_qty": 2200
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "ORS-75 Replacement",
    "brand_name": "Dehydrosol",
    "dosage": "--",
    "form": "Powder for Oral Solution",
    "lot_number": "4C50",
    "expiration_date": "3/1/2027",
    "boxes": "15",
    "pieces_per_box": "25",
    "total_qty": 375
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Paracetamol",
    "brand_name": "Milgesic Forte",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "254092",
    "expiration_date": "3/1/2027",
    "boxes": "25",
    "pieces_per_box": "100",
    "total_qty": 2500
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Paracetamol",
    "brand_name": "Hyfer-125",
    "dosage": "125mg/5mL",
    "form": "Oral Suspension",
    "lot_number": "L40093A",
    "expiration_date": "1/1/2027",
    "boxes": "--",
    "pieces_per_box": "288 bottles",
    "total_qty": "288 bottles"
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Rosuvastatin",
    "brand_name": "Rozatin-20",
    "dosage": "20mg",
    "form": "Tablet",
    "lot_number": "DC0049",
    "expiration_date": "2/1/2027",
    "boxes": "50",
    "pieces_per_box": "100",
    "total_qty": 5000
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Sambong Leaf",
    "brand_name": "MIA Forte",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "B24006",
    "expiration_date": "2/1/2026",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Simvastatin",
    "brand_name": "Diastatin",
    "dosage": "40mg",
    "form": "Tablet",
    "lot_number": "144081",
    "expiration_date": "4/1/2027",
    "boxes": "34",
    "pieces_per_box": "100",
    "total_qty": 3400
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Tranexamic Acid",
    "brand_name": "Haemorex",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "ZHN030",
    "expiration_date": "8/1/2025",
    "boxes": "3",
    "pieces_per_box": "100",
    "total_qty": 300
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Vitamin B Complex",
    "brand_name": "Nervita 100",
    "dosage": "100mg/5mg/50mcg",
    "form": "Tablet",
    "lot_number": "2406028",
    "expiration_date": "6/1/2026",
    "boxes": "50",
    "pieces_per_box": "100",
    "total_qty": 5000
  },
  {
    "date": "2/3/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Vitamin B Complex",
    "brand_name": "Myrevit-B",
    "dosage": "100mg/10mg/50mcg",
    "form": "Tablet",
    "lot_number": "179AGN",
    "expiration_date": "7/1/2026",
    "boxes": "97",
    "pieces_per_box": "100",
    "total_qty": 9700
  },
  {
    "date": "2/10/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Cefalexin",
    "brand_name": "Edexin",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "289ACB",
    "expiration_date": "3/1/2027",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "2/10/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Cefixime",
    "brand_name": "Saphixime 400",
    "dosage": "400mg",
    "form": "Tablet",
    "lot_number": "NSIX01",
    "expiration_date": "3/1/2026",
    "boxes": "50",
    "pieces_per_box": "10",
    "total_qty": 500
  },
  {
    "date": "2/10/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Cinnarizine",
    "brand_name": "Vertex",
    "dosage": "25mg",
    "form": "Tablet",
    "lot_number": "4B144",
    "expiration_date": "3/1/2027",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "2/10/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Co-Amoxiclav",
    "brand_name": "Asiclav-625",
    "dosage": "625mg",
    "form": "Tablet",
    "lot_number": "687240410",
    "expiration_date": "4/1/2026",
    "boxes": "10",
    "pieces_per_box": "14",
    "total_qty": 140
  },
  {
    "date": "2/10/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Naproxen",
    "brand_name": "Proxen",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "4D117",
    "expiration_date": "4/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "2/10/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Omeprazole",
    "brand_name": "Omephil-20",
    "dosage": "20mg",
    "form": "Capsule",
    "lot_number": "BI0074",
    "expiration_date": "8/1/2025",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "2/10/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Paracetamol",
    "brand_name": "Novamol",
    "dosage": "100mg/mL",
    "form": "Oral Drops",
    "lot_number": "E2425",
    "expiration_date": "5/1/2026",
    "boxes": "--",
    "pieces_per_box": "170 bottles",
    "total_qty": "170 bottles"
  },
  {
    "date": "2/13/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Amoxicillin",
    "brand_name": "Axmel",
    "dosage": "250mg/5mL",
    "form": "Powder for Suspension",
    "lot_number": "206AGB",
    "expiration_date": "7/1/2027",
    "boxes": "--",
    "pieces_per_box": "144 bottles",
    "total_qty": "144 bottles"
  },
  {
    "date": "2/14/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Amlodipine Besilate",
    "brand_name": "Regivasc",
    "dosage": "5mg",
    "form": "Tablet",
    "lot_number": "2405079",
    "expiration_date": "5/1/2029",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "2/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Amoxicillin",
    "brand_name": "Ambimox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "706240523",
    "expiration_date": "5/1/2027",
    "boxes": "15",
    "pieces_per_box": "100",
    "total_qty": 1500
  },
  {
    "date": "2/14/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Lagundi",
    "brand_name": "Asflem",
    "dosage": "300mg",
    "form": "Tablet",
    "lot_number": "24D493",
    "expiration_date": "7/1/2026",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "2/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Multivitamin",
    "brand_name": "Multilem",
    "dosage": "--",
    "form": "Pediatric Drops",
    "lot_number": "75258",
    "expiration_date": "7/1/2025",
    "boxes": "--",
    "pieces_per_box": "144 bottles",
    "total_qty": "144 bottles"
  },
  {
    "date": "2/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Omeprazole",
    "brand_name": "Omephil-20",
    "dosage": "20mg",
    "form": "Capsule",
    "lot_number": "BI0074",
    "expiration_date": "8/1/2025",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "2/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Paracetamol",
    "brand_name": "Hyfer-125",
    "dosage": "125mg/5mL",
    "form": "Oral Suspension",
    "lot_number": "L40094A",
    "expiration_date": "1/1/2027",
    "boxes": "--",
    "pieces_per_box": "144 bottles",
    "total_qty": "144 bottles"
  },
  {
    "date": "2/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Sodium Ascorbate + Zinc",
    "brand_name": "Maxicor Plus",
    "dosage": "500mg/10mg",
    "form": "Capsule",
    "lot_number": "2409096",
    "expiration_date": "9/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "2/18/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Allopurinol",
    "brand_name": "Urisol",
    "dosage": "100mg",
    "form": "Tablet",
    "lot_number": "U-02036",
    "expiration_date": "2/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "2/18/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Captopril",
    "brand_name": "Captobes",
    "dosage": "25mg",
    "form": "Tablet",
    "lot_number": "4E137",
    "expiration_date": "5/1/2027",
    "boxes": "15",
    "pieces_per_box": "100",
    "total_qty": 1500
  },
  {
    "date": "2/18/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Celecoxib",
    "brand_name": "Saphlecox-400",
    "dosage": "400mg",
    "form": "Capsule",
    "lot_number": "NOF11",
    "expiration_date": "2/1/2027",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "2/18/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Co-Amoxiclav",
    "brand_name": "Asiclav-625",
    "dosage": "625mg",
    "form": "Tablet",
    "lot_number": "687240410",
    "expiration_date": "4/1/2026",
    "boxes": "10",
    "pieces_per_box": "14",
    "total_qty": 140
  },
  {
    "date": "2/18/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Cotrimoxazole",
    "brand_name": "Kathrex",
    "dosage": "800mg/160mg",
    "form": "Tablet",
    "lot_number": "ZGN179",
    "expiration_date": "7/1/2026",
    "boxes": "6",
    "pieces_per_box": "100",
    "total_qty": 600
  },
  {
    "date": "2/18/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Sambong Leaf",
    "brand_name": "MIA Forte",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "B24006",
    "expiration_date": "2/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "2/21/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Amlodipine",
    "brand_name": "Diadipine",
    "dosage": "10mg",
    "form": "Tablet",
    "lot_number": "133511",
    "expiration_date": "11/1/2026",
    "boxes": "30",
    "pieces_per_box": "100",
    "total_qty": 3000
  },
  {
    "date": "2/21/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Amoxicillin",
    "brand_name": "Ambimox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "706240523",
    "expiration_date": "5/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "2/21/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Ascorbic Acid",
    "brand_name": "Myrevit-C",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "7GN040",
    "expiration_date": "7/1/2025",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "2/21/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Aspirin",
    "brand_name": "Philprin",
    "dosage": "80mg",
    "form": "Tablet",
    "lot_number": "240170",
    "expiration_date": "1/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "2/21/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cefalexin",
    "brand_name": "Exel",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "005AGB",
    "expiration_date": "7/1/2027",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "2/21/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Celecoxib",
    "brand_name": "Saphlecox-400",
    "dosage": "400mg",
    "form": "Capsule",
    "lot_number": "NOF11",
    "expiration_date": "2/1/2027",
    "boxes": "2",
    "pieces_per_box": "100",
    "total_qty": 200
  },
  {
    "date": "2/21/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cinnarizine",
    "brand_name": "Vertex",
    "dosage": "25mg",
    "form": "Tablet",
    "lot_number": "4B144",
    "expiration_date": "3/1/2027",
    "boxes": "3",
    "pieces_per_box": "100",
    "total_qty": 300
  },
  {
    "date": "2/21/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Co-Amoxiclav",
    "brand_name": "Comxicla",
    "dosage": "625mg",
    "form": "Tablet",
    "lot_number": "23520738",
    "expiration_date": "11/1/2025",
    "boxes": "10",
    "pieces_per_box": "20",
    "total_qty": 200
  },
  {
    "date": "2/21/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Erythromycin",
    "brand_name": "Erzin",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "EGT230134",
    "expiration_date": "3/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "2/21/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Lagundi",
    "brand_name": "Asflem",
    "dosage": "300mg",
    "form": "Tablet",
    "lot_number": "24D493",
    "expiration_date": "7/1/2026",
    "boxes": "21",
    "pieces_per_box": "100",
    "total_qty": 2100
  },
  {
    "date": "2/21/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Multivitamins",
    "brand_name": "Myrevit",
    "dosage": "--",
    "form": "Capsule",
    "lot_number": "192AEN",
    "expiration_date": "5/1/2026",
    "boxes": "100",
    "pieces_per_box": "100",
    "total_qty": 10000
  },
  {
    "date": "2/28/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Ascorbic Acid",
    "brand_name": "Ascophil",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "240582",
    "expiration_date": "5/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "2/28/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cloxacillin",
    "brand_name": "Philclox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "233133042",
    "expiration_date": "11/1/2025",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "2/28/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Co-Amoxiclav",
    "brand_name": "Comxicla",
    "dosage": "625mg",
    "form": "Tablet",
    "lot_number": "23520738",
    "expiration_date": "11/1/2025",
    "boxes": "10",
    "pieces_per_box": "20",
    "total_qty": 200
  },
  {
    "date": "2/28/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Lagundi",
    "brand_name": "Asflem",
    "dosage": "300mg",
    "form": "Tablet",
    "lot_number": "24D493",
    "expiration_date": "7/1/2026",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "2/28/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Mefenamic Acid",
    "brand_name": "Mecid",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "240502",
    "expiration_date": "5/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "2/28/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "ORS-75 Replacement",
    "brand_name": "Dehydrosol",
    "dosage": "--",
    "form": "Powder for Oral Solution",
    "lot_number": "4C50",
    "expiration_date": "3/1/2027",
    "boxes": "10",
    "pieces_per_box": "25",
    "total_qty": 250
  },
  {
    "date": "2/28/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Paracetamol",
    "brand_name": "Novamol",
    "dosage": "100mg/mL",
    "form": "Oral Drops",
    "lot_number": "E2425",
    "expiration_date": "5/1/2026",
    "boxes": "--",
    "pieces_per_box": "170 bottles",
    "total_qty": "170 bottles"
  },
  {
    "date": "3/5/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Amlodipine Besilate",
    "brand_name": "Regivasc",
    "dosage": "5mg",
    "form": "Tablet",
    "lot_number": "2405079",
    "expiration_date": "5/1/2029",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "3/5/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Amoxicillin",
    "brand_name": "Ambimox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "706240523",
    "expiration_date": "5/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "3/5/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Amoxicillin",
    "brand_name": "Axmel",
    "dosage": "250mg/5mL",
    "form": "Powder for Suspension",
    "lot_number": "206AGB",
    "expiration_date": "7/1/2027",
    "boxes": "--",
    "pieces_per_box": "72 bottles",
    "total_qty": "72 bottles"
  },
  {
    "date": "3/5/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Ascorbic Acid",
    "brand_name": "Ascophil",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "240582",
    "expiration_date": "5/1/2026",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "3/5/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Atorvastatin",
    "brand_name": "Lestor",
    "dosage": "20mg",
    "form": "Tablet",
    "lot_number": "240507",
    "expiration_date": "5/1/2027",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "3/5/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Cefalexin",
    "brand_name": "Exel",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "005AGB",
    "expiration_date": "7/1/2027",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "3/5/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cefixime",
    "brand_name": "Saphixime 400",
    "dosage": "400mg",
    "form": "Tablet",
    "lot_number": "NSIX01",
    "expiration_date": "3/1/2026",
    "boxes": "50",
    "pieces_per_box": "10",
    "total_qty": 500
  },
  {
    "date": "3/5/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Celecoxib",
    "brand_name": "Saphlecox-400",
    "dosage": "400mg",
    "form": "Capsule",
    "lot_number": "NOF11",
    "expiration_date": "2/1/2027",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "3/5/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Cloxacillin",
    "brand_name": "Oxeed",
    "dosage": "250mg/5mL",
    "form": "Powder for Oral Suspension",
    "lot_number": "24D55",
    "expiration_date": "4/1/2027",
    "boxes": "--",
    "pieces_per_box": "72 bottles",
    "total_qty": "72 bottles"
  },
  {
    "date": "3/5/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Co-Amoxiclav",
    "brand_name": "Comxicla",
    "dosage": "625mg",
    "form": "Tablet",
    "lot_number": "23520738",
    "expiration_date": "11/1/2025",
    "boxes": "10",
    "pieces_per_box": "20",
    "total_qty": 200
  },
  {
    "date": "3/5/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Hyoscine N-Butylbromide",
    "brand_name": "Hyopan",
    "dosage": "10mg",
    "form": "Tablet",
    "lot_number": "B10205",
    "expiration_date": "8/1/2025",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "3/5/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Mefenamic Acid",
    "brand_name": "Mecid",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "240502",
    "expiration_date": "5/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "3/5/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Paracetamol",
    "brand_name": "Milgesic Forte",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "254093",
    "expiration_date": "3/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "3/7/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cloxacillin",
    "brand_name": "Philclox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "233133042",
    "expiration_date": "11/1/2025",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "3/10/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Ascorbic Acid",
    "brand_name": "Ascophil",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "240582",
    "expiration_date": "5/1/2026",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "3/10/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Co-Amoxiclav",
    "brand_name": "Comxicla",
    "dosage": "625mg",
    "form": "Tablet",
    "lot_number": "23520738",
    "expiration_date": "11/1/2025",
    "boxes": "10",
    "pieces_per_box": "20",
    "total_qty": 200
  },
  {
    "date": "3/10/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Lagundi",
    "brand_name": "Asflem",
    "dosage": "300mg",
    "form": "Tablet",
    "lot_number": "24D490",
    "expiration_date": "7/1/2026",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "3/10/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Naproxen",
    "brand_name": "Proxen",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "4D117",
    "expiration_date": "4/1/2026",
    "boxes": "8",
    "pieces_per_box": "100",
    "total_qty": 800
  },
  {
    "date": "3/10/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Omeprazole",
    "brand_name": "Omephil-20",
    "dosage": "20mg",
    "form": "Capsule",
    "lot_number": "BI0056",
    "expiration_date": "8/1/2025",
    "boxes": "1",
    "pieces_per_box": "100",
    "total_qty": 100
  },
  {
    "date": "3/10/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Omeprazole",
    "brand_name": "Omephil-20",
    "dosage": "20mg",
    "form": "Capsule",
    "lot_number": "BI0074",
    "expiration_date": "8/1/2025",
    "boxes": "9",
    "pieces_per_box": "100",
    "total_qty": 900
  },
  {
    "date": "3/10/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Paracetamol",
    "brand_name": "Milgesic Forte",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "254093",
    "expiration_date": "3/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "3/14/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Amlodipine",
    "brand_name": "Diadipine",
    "dosage": "5mg",
    "form": "Tablet",
    "lot_number": "132447",
    "expiration_date": "11/1/2026",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "3/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Amoxicillin",
    "brand_name": "Ambimox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "706240523",
    "expiration_date": "5/1/2027",
    "boxes": "15",
    "pieces_per_box": "100",
    "total_qty": 1500
  },
  {
    "date": "3/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Celecoxib",
    "brand_name": "Saphlecox-400",
    "dosage": "400mg",
    "form": "Capsule",
    "lot_number": "NOF11",
    "expiration_date": "2/1/2027",
    "boxes": "4",
    "pieces_per_box": "100",
    "total_qty": 400
  },
  {
    "date": "3/14/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Co-Amoxiclav",
    "brand_name": "Comxicla",
    "dosage": "625mg",
    "form": "Tablet",
    "lot_number": "23520738",
    "expiration_date": "11/1/2025",
    "boxes": "10",
    "pieces_per_box": "20",
    "total_qty": 200
  },
  {
    "date": "3/14/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "ORS-75 Replacement",
    "brand_name": "Dehydrosol",
    "dosage": "--",
    "form": "Powder for Oral Solution",
    "lot_number": "4C50",
    "expiration_date": "3/1/2027",
    "boxes": "10",
    "pieces_per_box": "25",
    "total_qty": 250
  },
  {
    "date": "3/14/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Vitamin B Complex",
    "brand_name": "Nervita 100",
    "dosage": "100mg/5mg/50mcg",
    "form": "Tablet",
    "lot_number": "2406026",
    "expiration_date": "6/1/2026",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "3/17/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Lagundi",
    "brand_name": "Asflem",
    "dosage": "300mg",
    "form": "Tablet",
    "lot_number": "24D490",
    "expiration_date": "7/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Amlodipine",
    "brand_name": "Diadipine",
    "dosage": "10mg",
    "form": "Tablet",
    "lot_number": "133511",
    "expiration_date": "11/1/2026",
    "boxes": "25",
    "pieces_per_box": "100",
    "total_qty": 2500
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Amlodipine",
    "brand_name": "Diadipine",
    "dosage": "5mg",
    "form": "Tablet",
    "lot_number": "132447",
    "expiration_date": "11/1/2026",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "3/20/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Amoxicillin",
    "brand_name": "Ambimox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "706240523",
    "expiration_date": "5/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Ascorbic Acid",
    "brand_name": "Ascophil",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "240582",
    "expiration_date": "5/1/2026",
    "boxes": "30",
    "pieces_per_box": "100",
    "total_qty": 3000
  },
  {
    "date": "3/20/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Atorvastatin",
    "brand_name": "Trovipri",
    "dosage": "80mg",
    "form": "Tablet",
    "lot_number": "PH-2420",
    "expiration_date": "12/1/2026",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Atorvastatin",
    "brand_name": "Lestor",
    "dosage": "20mg",
    "form": "Tablet",
    "lot_number": "240507",
    "expiration_date": "5/1/2027",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Cefalexin",
    "brand_name": "Diacef",
    "dosage": "250mg/5mL",
    "form": "Powder for Suspension",
    "lot_number": "29462",
    "expiration_date": "4/1/2027",
    "boxes": "--",
    "pieces_per_box": "72 bottles",
    "total_qty": "72 bottles"
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Cefalexin",
    "brand_name": "Exel",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "005AGB",
    "expiration_date": "7/1/2027",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "3/20/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Celecoxib",
    "brand_name": "Saphlecox-400",
    "dosage": "400mg",
    "form": "Capsule",
    "lot_number": "NOF11",
    "expiration_date": "2/1/2027",
    "boxes": "2",
    "pieces_per_box": "100",
    "total_qty": 200
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Chlorphenamine Maleate",
    "brand_name": "Riphen",
    "dosage": "4mg",
    "form": "Tablet",
    "lot_number": "138167",
    "expiration_date": "4/1/2026",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Cinnarizine",
    "brand_name": "Rizine",
    "dosage": "25mg",
    "form": "Tablet",
    "lot_number": "R-08064",
    "expiration_date": "3/1/2026",
    "boxes": "7",
    "pieces_per_box": "100",
    "total_qty": 700
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cloxacillin",
    "brand_name": "Philclox",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "233133042",
    "expiration_date": "11/1/2025",
    "boxes": "13",
    "pieces_per_box": "100",
    "total_qty": 1300
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Lagundi",
    "brand_name": "Asflem",
    "dosage": "300mg",
    "form": "Tablet",
    "lot_number": "24D493",
    "expiration_date": "7/1/2026",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Losartan",
    "brand_name": "Losaar 100",
    "dosage": "100mg",
    "form": "Tablet",
    "lot_number": "240527",
    "expiration_date": "5/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Losartan",
    "brand_name": "Losaar 50",
    "dosage": "50mg",
    "form": "Tablet",
    "lot_number": "240442",
    "expiration_date": "4/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Mefenamic Acid",
    "brand_name": "Mecid",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "240502",
    "expiration_date": "5/1/2027",
    "boxes": "4",
    "pieces_per_box": "100",
    "total_qty": 400
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Mefenamic Acid",
    "brand_name": "Myrefen",
    "dosage": "500mg",
    "form": "Capsule",
    "lot_number": "ZJN157",
    "expiration_date": "9/1/2026",
    "boxes": "1",
    "pieces_per_box": "100",
    "total_qty": 100
  },
  {
    "date": "3/20/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Metformin",
    "brand_name": "Glycemet",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "240344",
    "expiration_date": "3/1/2027",
    "boxes": "38",
    "pieces_per_box": "100",
    "total_qty": 3800
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "ORS-75 Replacement",
    "brand_name": "Dehydrosol",
    "dosage": "--",
    "form": "Powder for Oral Solution",
    "lot_number": "4C50",
    "expiration_date": "3/1/2027",
    "boxes": "10",
    "pieces_per_box": "25",
    "total_qty": 250
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Paracetamol",
    "brand_name": "Ambiretic",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "240208",
    "expiration_date": "2/1/2027",
    "boxes": "19",
    "pieces_per_box": "100",
    "total_qty": 1900
  },
  {
    "date": "3/20/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Simvastatin",
    "brand_name": "Simvasyn",
    "dosage": "20mg",
    "form": "Tablet",
    "lot_number": "CD0083",
    "expiration_date": "3/1/2026",
    "boxes": "20",
    "pieces_per_box": "100",
    "total_qty": 2000
  },
  {
    "date": "3/20/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Vitamin B Complex",
    "brand_name": "Nervita 100",
    "dosage": "100mg/5mg/50mcg",
    "form": "Tablet",
    "lot_number": "2406026",
    "expiration_date": "6/1/2026",
    "boxes": "50",
    "pieces_per_box": "100",
    "total_qty": 5000
  },
  {
    "date": "3/31/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Amlodipine",
    "brand_name": "Diadipine",
    "dosage": "5mg",
    "form": "Tablet",
    "lot_number": "132447",
    "expiration_date": "11/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "3/31/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Cefixime",
    "brand_name": "Saphixime 400",
    "dosage": "400mg",
    "form": "Capsule",
    "lot_number": "NSIX01",
    "expiration_date": "3/1/2026",
    "boxes": "40",
    "pieces_per_box": "10",
    "total_qty": 400
  },
  {
    "date": "3/31/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Clarithromycin",
    "brand_name": "Claritrol",
    "dosage": "500mg",
    "form": "Tablet",
    "lot_number": "CC0047",
    "expiration_date": "2/1/2026",
    "boxes": "10",
    "pieces_per_box": "30",
    "total_qty": 300
  },
  {
    "date": "3/31/2025",
    "from_lgu": true,
    "from_mo": false,
    "generic_name": "Clindamycin",
    "brand_name": "Acresil",
    "dosage": "300mg",
    "form": "Capsule",
    "lot_number": "S831",
    "expiration_date": "8/1/2026",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "3/31/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Lagundi",
    "brand_name": "Asflem",
    "dosage": "300mg",
    "form": "Tablet",
    "lot_number": "24D368",
    "expiration_date": "6/1/2026",
    "boxes": "6",
    "pieces_per_box": "100",
    "total_qty": 600
  },
  {
    "date": "3/31/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Lagundi",
    "brand_name": "Asflem",
    "dosage": "300mg",
    "form": "Tablet",
    "lot_number": "24D493",
    "expiration_date": "7/1/2026",
    "boxes": "5",
    "pieces_per_box": "100",
    "total_qty": 500
  },
  {
    "date": "3/31/2025",
    "from_lgu": false,
    "from_mo": true,
    "generic_name": "Losartan",
    "brand_name": "Losaar 50",
    "dosage": "50mg",
    "form": "Tablet",
    "lot_number": "240442",
    "expiration_date": "4/1/2027",
    "boxes": "10",
    "pieces_per_box": "100",
    "total_qty": 1000
  },
  {
    "date": "3/31/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Omeprazole",
    "brand_name": "Omephil-20",
    "dosage": "20mg",
    "form": "Capsule",
    "lot_number": "BJ0124",
    "expiration_date": "9/1/2025",
    "boxes": "3",
    "pieces_per_box": "100",
    "total_qty": 300
  },
  {
    "date": "3/31/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Omeprazole",
    "brand_name": "Omephil-20",
    "dosage": "20mg",
    "form": "Capsule",
    "lot_number": "BI0056",
    "expiration_date": "8/1/2025",
    "boxes": "1",
    "pieces_per_box": "100",
    "total_qty": 100
  },
  {
    "date": "3/31/2025",
    "from_lgu": false,
    "from_mo": false,
    "generic_name": "Omeprazole",
    "brand_name": "Omephil-20",
    "dosage": "20mg",
    "form": "Capsule",
    "lot_number": "BJ0127",
    "expiration_date": "9/1/2025",
    "boxes": "1",
    "pieces_per_box": "100",
    "total_qty": 100
  }
],
      cardData: null,
      device: null,
    }
  },

  mounted() {
    if((this.$tms_url.includes('dev') && this.$cms_url.includes('dev')) || (this.$tms_url.includes('testqa') && this.$cms_url.includes('testqa'))) {
      const test_object = {
          a: ['1','2','3','4','5'],
          b: ['test1','test2','test3','test4','test5'],
          c: ['pest1','pest2', 'pest3', 'pest4', 'pest5'],
          d: ['jest1','jest2', 'jest3', 'jest4', 'jest5']
      }
  
      // CREATE CODE TO MERGE KEY TO ARRAY VALUES
      const new_array = Object.entries(test_object).map(items => {
        return items[1].map(value => {
          return ({[items[0]] : value})
        })
      })
      
      let main_array = new_array[0]
      let get_array_other_than_first = new_array.splice(1)
  
      // CREATE CODE TO MERGE ARRAY TO MAIN ARRAY
      for (let x = 0; x < get_array_other_than_first.length; x++) {
        main_array =  main_array.map((value, idx) => {
          return Object.assign({}, {...value, ...get_array_other_than_first[x][idx]})
        })
      }   

      } else {
        this.$router.push('/*')
    }
  }, 


  methods: {
    // insertMed(){
    //   let med_data = this.med_data.map(el => {
    //     return {
    //       ...el,
    //       form: el.form.toUpperCase(),
    //       brand_name: el.brand_name.toUpperCase(),
    //       generic_name: el.generic_name.toUpperCase()
    //     }
    //   })

    //   this.$axios.post('https://dev-cms.eurekare.net:61012/resources/medicine_inventory_webservice/inventory_controller.php', this.$qs.stringify({
    //       post_data: this.wsDataEncryption(JSON.stringify({
    //         data: med_data
    //       }))
    //   })).then(response => {
    //     console.log(response)
    //   }).catch(err => {
    //     console.log(err)
    //   })
    // },

    addParameter(){
      // this.encrypted_json_data.push({ key: null, value: null })
      // this.encrypted_json_holder.push({

      // })
      this.encrypted_json_holder.push({ key: null, value: null })

      // this.json_key = ''
      // this.json_value = ''

      console.log(this.encrypted_json_holder)
    },

    encryptPayload(){
        let json_data = {}

        this.encrypted_json_holder.forEach(data => {
          json_data[data.key] = data.value
        })
  
        this.encrypted_payload = mixin.methods.wsDataEncryption(JSON.stringify(
              this.encrypt_tab === 0 ? json_data : this.list_of_payload
        ))
    },

    clearField(index) {
      this.encrypted_json_holder = this.encrypted_json_holder.filter(item => item !== this.encrypted_json_holder[index])
    },

    clearFieldItems(){
      this.list_of_payload = ''
      this.encrypted_payload = null
      this.encrypted_json_holder = [{ key: null, value: null }]
    },

    async copyToClipboard() {
      try {
        // Use the Clipboard API to copy the text
        await navigator.clipboard.writeText(this.encrypted_payload);
      } catch (error) {
        console.error('Failed to copy text:', error);
      }
    },

    clicks(){ 
      var ip = false;
        window.RTCPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection || false;

        if (window.RTCPeerConnection) {
          ip = [];
          var pc = new RTCPeerConnection({iceServers:[]}), noop = function(){};
          pc.createDataChannel('');
          pc.createOffer(pc.setLocalDescription.bind(pc), noop);

          pc.onicecandidate = function(event) {
          if (event && event.candidate && event.candidate.candidate) {
              var s = event.candidate.candidate.split('\n');
              ip.push(s[0].split(' ')[4]);
            }
          }
        }

        this.user_ip_address = ip

        return ip;
    }, 

    async usbSmartCard(){
      try {
        // Request device permission
        const device = await navigator.usb.requestDevice({
          filters: [{ vendorId: 0x0CA6 }]  // Replace with your reader's vendorId
        });

        
        // Open the device
        await device.open();
        
        // // Claim the interface for communication
        // await device.selectConfiguration(1);
        // await device.claimInterface(0);

        // // Save the device object for future interaction
        // this.device = device;
        // this.deviceName = device.productName;

        // // Initialize communication with card
        // const result = await this.initializeCard(device);
        // console.log(result);

        // // Read data from the card
        // const data = await this.readDataFromCard(device);
        // this.cardData = data;

      } catch (error) {
        console.error('Error:', error);
      }
    },

    // Initialize communication with the card (reset card, select file/application)
    async initializeCard(device) {
      try {
        // Example of an APDU command to reset the card
        const commandReset = new Uint8Array([0x00, 0xA4, 0x04, 0x00, 0x00]);  // Select command
        await device.transferOut(1, commandReset);  // Send the reset command

        // Optionally, you could send additional commands to select a specific file or application
        // Example of an APDU command to select an application (e.g., 'A0000002471001')
        const selectAppCommand = new Uint8Array([0x00, 0xA4, 0x04, 0x00, 0x07, 0xA0, 0x00, 0x00, 0x24, 0x71, 0x00, 0x01]);
        await device.transferOut(1, selectAppCommand);

        // Return a success message or result
        return 'Card Initialized and Application Selected';
      } catch (error) {
        console.error('Error initializing card:', error);
        throw new Error('Failed to initialize card');
      }
    },

    // Read data from the card (for example, read a memory block or file)
    async readDataFromCard(device) {
      try {
        // Example APDU to read data from the card (e.g., get data from a file)
        // This command would depend on the card's protocol and file system
        const readCommand = new Uint8Array([0x00, 0xB0, 0x00, 0x00, 0x10]);  // Read 16 bytes from memory
        const response = await device.transferOut(1, readCommand);
        console.log('Response:', response);

        // Get the response from the card
        const cardResponse = await device.transferIn(1, 64);  // Read response (64 bytes max)
        const cardData = new TextDecoder().decode(cardResponse.data);  // Decode the data as text
        console.log(cardData)
        // Return the data from the card
        return cardData;
      } catch (error) {
        console.error('Error reading data from card:', error);
        throw new Error('Failed to read data from card');
      }
    },

    async readCard() {
      const data = "Xr8=read_data&T0x=EKBVAC23D34C802134";

      const xhr = new XMLHttpRequest();
      xhr.withCredentials = true;

      xhr.addEventListener("readystatechange", function () {
        if (this.readyState === this.DONE) {
          console.log(this.responseText);
        }
      });

      xhr.open("POST", "http://10.0.4.16:1900/api/cardissuance/ReadCard");
      xhr.setRequestHeader("Accept", "*/*");
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
      xhr.send(data);

      console.log("XHR status:", xhr.status);
      console.log("XHR readyState:", xhr.readyState);
      console.log("XHR response:", xhr.responseText);
      

    // let data = {
    //   Xr8: 'read_data',
    //   T0x: 'EKBVAC23D34C802134'
    // }

// let headersList = {
//  "Accept": "*/*",
//  "Content-Type": "application/x-www-form-urlencoded",

// }

// // let bodyContent = "Xr8=read_data&T0x=EKBVAC23D34C802134";

// let reqOptions = {
//   url: "http://192.168.1.10:1900/api/cardissuance/readcard",
//   method: "POST",
//   headers: headersList,
//   data: data,
// }

// let response = await axios.request(reqOptions);
// console.log(response.data);

    // let data = {
    //   Xr8: 'read_data',
    //   T0x: 'EKBVAC23D34C802134'
    // }
    //   let response = await fetch(`http://192.168.1.20:1900/api/cardissuance/readcard`, {
    //     method: "POST", // *GET, POST, PUT, DELETE, etc.
    //     //mode: "same-origin", // no-cors, *cors, same-origin
    //     cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
    //     //credentials: "same-origin", // include, *same-origin, omit
    //     headers: {
    //       // "Content-Type": "application/json",
    //       'Content-Type': 'application/x-www-form-urlencoded',
    //       'Accept': '*/*',
    //       'Access-Control-Allow-Origin' : '*'

    //     },
    //     redirect: "follow", // manual, *follow, error
    //     // mode: 'no-cors',
    //     RequestCredentials: true,
    //     referrerPolicy: "strict-origin-when-cross-origin", // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
    //     body: JSON.stringify(data), // body data type must match "Content-Type" header
    //   })

    //   let text = await response.text()
    //   console.log(text)
      // console.log(response)
      // return response.json()

// let formData = new URLSearchParams();
// formData.append('Xr8', 'read_data');
// formData.append('T0x', 'EKBVAC23D34C802134');

// let response = await fetch('http://192.168.1.20:1900/api/cardissuance/readcard', {
//   method: 'POST',
//   headers: {
//     'Content-Type': 'application/x-www-form-urlencoded',
//     'Accept': '*/*'
//   },
//   body: formData.toString()
// });

// let text = await response.text();
// console.log(text);
    },
    
    // A function that decrypts the data.
    decrypt(type) {
      if (type === 'single' && this.single_value) {
        this.show_decrypted = true
        this.dec_result = this.wsDataDecryption(this.single_value)
      } else if (type === 'obj' && this.obj_value) {
        this.show_decrypted = true
        try {
          this.dec_result = JSON.parse(this.wsDataDecryption(this.obj_value))
        } catch  {
          this.dec_result = "decryption_failed"
        }
      } else {
        alert('ENTER VALUE')
      }
    },

    submitRequest() {
      axios.post(this.request_url, this.$qs.stringify({
        post_data: this.payload
      })).then(response => {
        this.data_response = this.responseDataDecryption(response.data)
      }).catch(err => {
        this.data_response = err
      })
    }
  }
}
</script>