import Vue from 'vue'
import VueRouter from 'vue-router'
import store from '@/store/index'
import mixin from '@/mixin'

import Login from '@/views/Login'
import PageNotFound from '@/views/PageNotFound'
import WelcomePage from '@/views/WelcomePage'
import TestComponent from '@/views/TestComponent'
import TestData from '@/views/TestData'

import PVTPharmacist from '@/components/prv-facility/prv-pharmacist/Main'
import MedicineLab from '@/components/prv-facility/prv-pharmacist/MedicineLab'
import PVTMedsInventory from '@/components/prv-facility/prv-pharmacist/MedsInventory'

import ProviderRegistration from '@/components/e-benefit/ProviderRegistration'
import CodeScanning from '@/components/e-benefit/code-scanning/CodeScanning'
import eLoaList from '@/components/e-benefit/eLoaList'
import PrintELOA from '@/components/e-benefit/PrintELOA'
import QueueList from '@/components/e-benefit/QueueList'
import TeleConsultQueueList from '@/components/e-benefit/TeleConsultQueueList'
import WebRegistration from '@/components/e-benefit/web-registration/WebRegistration'

import Eligibility from '@/components/e-benefit/Eligibility/Main'
import Consultation from '@/components/e-benefit/Consultation/Consultation'
import ConsultationResult from '@/components/e-benefit/Consultation/ConsultationResult'
import PrintConsultation from '@/components/e-benefit/Consultation/PrintConsultation'
import Outpatient from '@/components/e-benefit/Outpatient/Outpatient'
import OutpatientResult from '@/components/e-benefit/Outpatient/OutpatientResults'
import PrintOutpatient from '@/components/e-benefit/Outpatient/PrintOutpatient'
import Inpatient from '@/components/e-benefit/Inpatient/Inpatient'
import CovidList from '@/components/e-benefit/Covid/CovidList'
import CovidPositive from '@/components/e-benefit/Covid/CovidPositive'
import Mortality from '@/components/e-benefit/m1-forms/Mortality'
import Natality from '@/components/e-benefit/m1-forms/Natality'
import EnvironmentlHealth from '@/components/e-benefit/m1-forms/EnvironmentalHealth'
import ChildCareAndServices from '@/components/e-benefit/m1-forms/ChildCareAndServices'
import OfflineTransaction from '@/components/e-benefit/code-scanning/OfflineTransaction'
import EkonsultaSubmission from '@/components/e-benefit/ekonsulta-submission/Main'
import OfflineQueueList from '@/components/e-benefit/offline-queue-list/Main'

//DIAGNOSTIC-LABORATORY
import DiagnosticLaboratory from '@/components/prv-facility/prv-diagnostic/Main'
import DiagnosticLab from '@/components/prv-facility/prv-diagnostic/DiagnosticLab'
import PrvQueueList from '@/components/prv-facility/prv-queue-list/Main'

// E-CLAIMS
import PatientList from '@/components/e-claims/PatientList'
// import EclaimsPatientSubmitted from '@/components/e-claims/EclaimsPatientSubmitted'
import PBEF from '@/components/e-claims/PBEF'
import InputForms from '@/components/e-claims/InputForms'
import CFForms from '@/components/e-claims/CFForms'

// ADMIN
import Navbar from '@/components/admin/Navbar'
import MedicalTransactionReport from '@/components/admin/reports/medical-transaction/Main'

// EMR
import EMRConsultation from '@/components/emr/EMRConsultation'
import PatientQueueList from '@/components/emr/DoctorPatientQueueList'
import TransactionRecord from '@/components/emr/DoctorTransactionRecord'

// DISPENSING OF MEDICINE
import DPMMain from '@/components/e-benefit/dispense-medicine/Main'

// REFERRED TRANSACTION
import ReferredTransaction from '@/views/ReferredTransaction'

//PHARMACIST
import Pharmacist from '@/components/pharmacist/Main'

//TELECONSULT
import TeleconsultClinicHours from '@/components/emr/TeleconsultClinicHours'
import TeleconsultPatientList from '@/components/emr/TeleconsultPatientList'

//EDIT-INFO
import EditInfo from '@/components/e-benefit/Eligibility/EditInfo'

//USER-DELETION
import UserDeletion from '@/components/user-deletion/Main'
import SuccessDeletion from '@/components/user-deletion/SuccessDeletion'
import RequestDenied from '@/components/user-deletion/RequestDenied'

//PRIVACY AND POLICY
import PrivacyAndPolicy from '@/components/PrivacyAndPolicy'

//ECARE APP
import EcareApp from '@/components/ecare-app/Main'

Vue.use(VueRouter)

const routes = [
  // REFERRED TRANSACTION
  {
    path: '/referred-transaction',
    name: 'ReferredTransaction',
    component: ReferredTransaction,
    beforeEnter: (to, from, next) => {
      if (store.state.prv_data && store.state.usr_credentials) {
        if (store.state.usr_credentials.department === 'Admission' && store.state.usr_credentials.provider_reg_type === 'BRGY') {
          next()
        } else if ((store.state.usr_credentials.department === 'Doctor' || store.state.usr_credentials.department === 'Midwife') && store.state.usr_credentials.provider_reg_type !== 'BRGY') {
          next()
        } else {
          next(false)
        }
      } else {
        next('/')
      }
    }
  },

  // DISPENSING OF MEDICINE
  {
    path: '/dispense-medicine',
    name: 'DPMMain',
    component: DPMMain,
    beforeEnter: (to, from, next) => {
      if (store.state.prv_data && store.state.usr_credentials?.department === 'Admission' || store.state.prv_data && store.state.usr_credentials?.department === 'Data Encoder') {
        next()
      } else {
        next(false)
      }
    }
  },

  // EMR
  {
    path: '/patient-queue-list',
    name: 'PatientQueueList',
    component: PatientQueueList,
    beforeEnter: (to, from, next) =>{
      if(store.state.prv_data && (store.state.usr_credentials?.department === 'Doctor' || store.state.usr_credentials?.department === 'Midwife' || store.state.usr_credentials?.department === 'Medical Practitioner')){
        next()
      }else{
        next(false)
      }
    }
  },
  {
    path: '/patient-transaction-record',
    name: 'TransactionRecord',
    component: TransactionRecord,
    beforeEnter: (to, from, next) =>{
      if(store.state.prv_data && (store.state.usr_credentials?.department === 'Doctor' || store.state.usr_credentials?.department === 'Midwife' || store.state.usr_credentials?.department === 'Medical Practitioner')){
        next()
      }else{
        next(false)
      }
    }
  },
  //EMR CONSULTATION / DOCTOR'S PAGE
  {
    path: '/emr-consultation/:page',
    name: 'EMRConsultationTypeA',
    component: EMRConsultation,
    beforeEnter: (to, from, next) =>{
      let emr_params = sessionStorage.getItem('PIX235')

      if(store.state.prv_data && store.state.usr_credentials && emr_params){
        next()
      }else{
        if(store.state.prv_data && (store.state.usr_credentials?.department === 'Doctor' || store.state.usr_credentials?.department === 'Midwife')){
          next('/patient-queue-list')
        }else{
          next(false)
        }
      }
    }
  },

  //EMR CONSULTATION / DOCTOR'S PAGE
  {
    path: '/emr-consultation',
    name: 'EMRConsultationTypeB',
    component: EMRConsultation,
    beforeEnter: (to, from, next) =>{
      let emr_params = sessionStorage.getItem('PIX235')

      if(store.state.prv_data && store.state.usr_credentials && emr_params){
        next()
      }else{
        if(store.state.prv_data && (store.state.usr_credentials?.department === 'Doctor' || store.state.usr_credentials?.department === 'Midwife')){
          next('/patient-queue-list')
        }else{
          next(false)
        }
      }
    }
  },
  
  // ADMIN
  {
    path: '/admin/:page',
    name: 'Navbar',
    component: Navbar,
    beforeEnter: (to, from, next) =>{
      if(store.state.prv_data && store.state.usr_credentials?.department === 'Admin' || store.state.prv_data && store.state.usr_credentials?.department === 'super-admin'){
        next()
      }else{
        next(false)
      }
    }
  },
    // E-CLAIMS
    {
      path: '/patient-list',
      name: 'PatientList',
      component: PatientList,
      beforeEnter: (to, from, next) =>{
        if(store.state.prv_data && store.state.usr_credentials?.department !== 'Doctor' && store.state.usr_credentials?.department !== 'Midwife' && store.state.usr_credentials?.department !== 'Laboratory' && store.state.prv_data.phic === 1){
          next()
        }else{
          next(false)
        }
      }
    },
    {
      path: '/pbef',
      name: 'PBEF',
      component: PBEF,
      beforeEnter: (to, from, next) =>{
        let pbef_params = sessionStorage.getItem('gdo3sGfd')
  
        if(store.state.prv_data && store.state.usr_credentials && pbef_params){
          next()
        }else{
          next(false)
        }
      }
    },

    {
      path: '/eclaims-patient-list',
      name: 'EclaimsPatientSubmitted',
      component: PatientList,
      beforeEnter: (to, from, next) =>{
        if(store.state.prv_data && store.state.usr_credentials?.department !== 'Doctor' && store.state.usr_credentials?.department !== 'Midwife' && store.state.usr_credentials?.department !== 'Laboratory' && store.state.prv_data.phic === 1){
          next()
        }else{
          next(false)
        }
      }
    },

    {
      path: '/input-forms/:category',
      name: 'InputForms',
      component: InputForms,
      beforeEnter: (to, from, next) =>{
        let trans_detail = sessionStorage.getItem('QesRTe3j4fs3')

        if(store.state.prv_data && store.state.usr_credentials){
          if(trans_detail){
            next()
          }else{
            if(store.state.usr_credentials.department === 'Nurse Station' || store.state.usr_credentials.department === 'Credit and Collection'){
              next('/patient-list')
            }else{
              next(false)
            }
          }
        }else{
          next(false)
        }
      }
    },

    {
      path: '/cf-forms/:configuration',
      name: 'CFForms',
      component: CFForms,
      beforeEnter: (to, from, next) =>{
        let trans_detail = sessionStorage.getItem('QesRTe3j4fs3')
  
        if(store.state.prv_data && store.state.usr_credentials && trans_detail){
          next()
        }else{
          next(false)
        }
      }
    },
  // E-BENEFITS

  {
    path: '/provider-registration',
    name: 'ProviderRegistration',
    component: ProviderRegistration,
    beforeEnter: (to, from, next) => {
      let prv_tin_code = localStorage.getItem('PCR245')
      if(prv_tin_code) next()
      if(!prv_tin_code) next({name : 'Login'})
    }
  },

  {
    path: '/',
    name: 'Login',
    component: Login,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials && store.state.prv_data){
        next(false)
        if(store.state.usr_credentials.department === 'Admin' || store.state.usr_credentials.department === 'super-admin'){
          next('/admin/registered-users')
        }else if(store.state.usr_credentials.department === 'Nurse Station'){
          next('/patient-list')
        }else if(store.state.usr_credentials.department === 'Credit and Collection'){
          next('/eclaims-patient-list')
        }else if(store.state.usr_credentials.department === 'Laboratory'){
          next('/covid-list')
        }else if(store.state.usr_credentials.department === 'Doctor' || store.state.usr_credentials.department === 'Midwife' || store.state.usr_credentials.department === 'Medical Practitioner'){
          next('/patient-queue-list')
        }else if(store.state.usr_credentials.department === 'Pharmacist'){
          next('/pharmacist/received')
        }else if(store.state.usr_credentials.department === 'Data Encoder'){
          next('/offline-transaction')
        }else if(store.state.usr_credentials.department === 'Medical Laboratory Technologists'){
          next('/diagnostic-laboratory')
        }else if(store.state.usr_credentials.department === 'PVTPharmacist'){
          next('/pvt-pharmacist')
        }else{
          if(store.state.prv_data.hmo === 1 || store.state.prv_data.lgu === 1){
            next('/code-scanning')
          } else {
            next('/patient-list')
          }
        }
      }else{
        mixin.methods.webCookies('delete', 'DF342')
        mixin.methods.webCookies('delete', 'QR5YP')
        next()
      }
    }
  },

  {
    path: '/code-scanning',
    name: 'CodeScanning',
    component: CodeScanning,
    beforeEnter: (to, from, next) => {
      if((store.state.usr_credentials?.department === 'Admission') && store.state.prv_data  && store.state.prv_config && (store.state.prv_data.hmo === 1 || store.state.prv_data.lgu === 1)){
        next()
      }else{
        next({name : 'Login'})
      }
    }
  },

  {
    path: '/offline-transaction',
    name: 'OfflineTransaction',
    component: OfflineTransaction,
    beforeEnter: (to, from, next) => {
      if((store.state.usr_credentials?.department === 'Data Encoder') && store.state.prv_data  && store.state.prv_config && (store.state.prv_data.hmo === 1 || store.state.prv_data.lgu === 1)){
        next()
      }else{
        next({name : 'Login'})
      }
    }
  },

  {
    path: '/queue-list',
    name: 'QueueList',
    component: QueueList,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Admission' && store.state.prv_data && (store.state.prv_data.hmo === 1 || store.state.prv_data.lgu === 1)){
        next()
      }else{
        next('/')
      }
    }
  },

  {
    path: '/teleconsult-queue-list',
    name: 'TeleConsultQueueList',
    component: TeleConsultQueueList,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Admission' && store.state.prv_data && (store.state.prv_data.hmo === 1 || store.state.prv_data.lgu === 1)){
        next()
      }else{
        next('/')
      }
    }
  },

  {
    path: '/registration',
    name: 'WebRegistration',
    component: WebRegistration,
    beforeEnter: (to, from, next) => {
      if((store.state.usr_credentials?.department === 'Admission' || store.state.usr_credentials?.department === 'Data Encoder') && store.state.prv_data && (store.state.prv_data.hmo === 1 || store.state.prv_data.lgu === 1)){
        next()
      }else{
        next('/')
      }
    }
  },

  {
    path: '/edit-info',
    name: 'EditInformation',
    component: EditInfo,
    beforeEnter: (to, from, next) => {
      if((store.state.usr_credentials?.department === 'Admission' || store.state.usr_credentials?.department === 'Data Encoder')  && store.state.prv_data && (store.state.prv_data.hmo === 1 || store.state.prv_data.lgu === 1)){
        next()
      }else{
        next('/')
      }
    }
  },

  {
    path: '/eligibility',
    name: 'Eligibility',
    component: Eligibility,
    beforeEnter: (to, from, next) => {
      let auth = sessionStorage.getItem('oIohiK_pvcE')
      if(auth && store.state.usr_credentials?.department === 'Admission' || store.state.usr_credentials?.department === 'Data Encoder' && store.state.prv_data){
        next()
      }else{
        next('/')
      }
    }
  },

  // {
  //   path: '/admission/:page',
  //   name: 'Consultation',
  //   component: Consultation,
  //   beforeEnter: (to, from, next) => {
  //     let auth = sessionStorage.getItem('pvceifcaqpcig')
  //     if(auth && store.state.member_data &&  store.state.usr_credentials?.department === 'Admission' || store.state.usr_credentials?.department === 'Data Encoder' && store.state.prv_data){
  //       next()
  //     }else{
  //       next('/eligibility')
  //     }
  //   }
  // },

  //Admission / CONSULTATION PAGE
  {
    path: '/admission/:page',
    name: 'ConsultationTypeA',
    component: Consultation,
    beforeEnter: (to, from, next) => {
      let auth = sessionStorage.getItem('pvceifcaqpcig')
      if(auth && store.state.member_data &&  store.state.usr_credentials?.department === 'Admission' || store.state.usr_credentials?.department === 'Data Encoder' && store.state.prv_data){
        next()
      }else{
        next('/eligibility')
      }
    }
  },

  //Admission / CONSULTATION PAGE
  {
    path: '/admission',
    name: 'ConsultationTypeB',
    component: Consultation,
    beforeEnter: (to, from, next) => {
      let auth = sessionStorage.getItem('pvceifcaqpcig')
      if(auth && store.state.member_data &&  store.state.usr_credentials?.department === 'Admission' || store.state.usr_credentials?.department === 'Data Encoder' && store.state.prv_data){
        next()
      }else{
        next('/eligibility')
      }
    }
  },

  {
    path: '/consultation-result',
    name: 'ConsultationResult',
    component: ConsultationResult,
    beforeEnter: (to, from, next) => {
      let cons_res_auth = sessionStorage.getItem('LZ19XD15S0Y1YU') 
      if(cons_res_auth && store.state.member_data  && store.state.usr_credentials?.department === 'Admission' && store.state.prv_data){
        next()
      }else{
        next('/')
      }
    }
    
  },
  
  {
    path: '/print-consultation',
    name: 'PrintConsultation',
    component: PrintConsultation,
    beforeEnter: (to, from, next) => {
      let print_consult_auth = sessionStorage.getItem('JM9SO0Y1YV')
      if(print_consult_auth && store.state.member_data &&  store.state.usr_credentials?.department === 'Admission' && store.state.prv_data){
        next()
      }else{
        next('/')
      }
    }
  },

  {
    path: '/outpatient',
    name: 'Outpatient',
    component: Outpatient,
    beforeEnter: (to, from, next) => {
      let auth = sessionStorage.getItem('gcicaqeifpcv')
      if(auth && store.state.member_data &&  store.state.usr_credentials?.department === 'Admission' || store.state.usr_credentials?.department === 'Data Encoder' && store.state.prv_data){
        next()
      }else{
        next('/eligibility')
      }
    }
  },

  {
    path: '/outpatient-result',
    name: 'OutpatientResult',
    component: OutpatientResult,
    beforeEnter: (to, from, next) => {
      let op_res_auth = sessionStorage.getItem('LZ19XD15S0Y1YU') 
      if(op_res_auth && store.state.member_data &&  store.state.usr_credentials?.department === 'Admission' && store.state.prv_data){
        next()
      }else{
        next('/')
      }
    }
  },

  {
    path: '/print-outpatient',
    name: 'PrintOutpatient',
    component: PrintOutpatient,
    beforeEnter: (to, from, next) => {
      let print_op_auth = sessionStorage.getItem('JM9SO0Y1YV')
      if(print_op_auth && store.state.member_data &&  store.state.usr_credentials?.department === 'Admission' && store.state.prv_data){
        next()
      }else{
        next('/')
      }
    }
  },

  {
    path: '/inpatient',
    name: 'Inpatient',
    component: Inpatient,
    beforeEnter: (to, from, next) => {
      let auth = sessionStorage.getItem('acpfeivcpgci')
      if(auth && store.state.member_data &&  store.state.usr_credentials?.department === 'Admission' || store.state.usr_credentials?.department === 'Data Encoder' && store.state.prv_data){
        next()
      }else{
        next('/eligibility')
      }
    }
  },

  {
    path: '/covid-list',
    name: 'CovidList',
    component: CovidList,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Laboratory' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    }
  },

  {
    path: '/covid-test-case',
    name: 'CovidTestCase',
    component: CovidPositive,
    beforeEnter: (to, from, next) => {
      let auth = sessionStorage.getItem('LSH4GF')
      if(auth && store.state.usr_credentials && store.state.prv_data){
        next()
      }else{
        next('/covid-list')        
      }
    }
  },

  {
    path: '/eloa-list',
    name: 'eLoaList',
    component:eLoaList,
    beforeEnter: (to, from, next) => {
      let eloa_list_data = sessionStorage.getItem('LSD0IDX')
      if(eloa_list_data && store.state.usr_credentials?.department === 'Admission' && store.state.prv_data){
        next()
      }else{
        next('/')
      }
    }
  },

  {
    path: '/print-eLOA',
    name: 'PrintELOA',
    component: PrintELOA,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Admission' && store.state.prv_data){
        next()
      }else{
        next('/')
      }
    }
  },
  
  {
    path: '/medical-transaction-report',
    name: 'MedicalTransactionReport',
    component: MedicalTransactionReport,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Credit and Collection' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    }
  },

  //PHARMACIST
  {
    path: '/pharmacist/:page',
    name: 'Pharmacist',
    component: Pharmacist,
    beforeEnter: (to, from, next) => {
      if (store.state.prv_data && store.state.usr_credentials?.department === 'Pharmacist') {
        next()
      } else {
        next({name : 'Login'})
      }
    }
  },

  {
    path: '/pvt-pharmacist',
    name: 'PVTPharmacist',
    component: PVTPharmacist,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'PVTPharmacist' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    } 
  },

  {
    path: '/medicine-lab',
    name: 'MedicineLab',
    component: MedicineLab,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'PVTPharmacist' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    } 
  },

  {
    path: '/pvt-inventory',
    name: 'PVTMedsInventory',
    component: PVTMedsInventory,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'PVTPharmacist' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    } 
  },

  //TELECONSULT
  {
    path: '/teleconsult-clinic-hours',
    name: 'TeleconsultClinicHours',
    component: TeleconsultClinicHours,
    beforeEnter: (to, from, next) => {
      if (store.state.usr_credentials.department === 'Doctor' || store.state.usr_credentials.department === 'Midwife') {
        next()
      } else {
        next(false)
      }
    }
  },

  {
    path: '/teleconsult-patients-list',
    name: 'TeleconsultPatientList',
    component: TeleconsultPatientList,
    beforeEnter: (to, from, next) => {
      if (store.state.usr_credentials.department === 'Doctor' || store.state.usr_credentials.department === 'Midwife') {
        next()
      } else {
        next(false)
      }
    }
  },

  //MORTALITY
  {
    path: '/mortality',
    name: 'Mortality',
    component: Mortality,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Admission' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    }
  },

  //NATALITY
  {
    path: '/natality',
    name: 'Natality',
    component: Natality,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Admission' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    }
  },

  //ENVIRONMENTAL HEALTH
  {
    path: '/ehss',
    name: 'ENVIRONMENTAL HEALTH',
    component: EnvironmentlHealth,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Admission' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    }
  },

  //CHILD CARE AND SERVICES
  {
    path: '/child-care-and-services',
    name: 'CHILD CARE AND SERVICES',
    component: ChildCareAndServices,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Admission' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    }
  },

  {
    path: '/page-not-found',
    name: 'PageNotFound',
    component: PageNotFound, 
  },

  {
    path: '/diagnostic-laboratory',
    name: 'DiagnosticLaboratory',
    component: DiagnosticLaboratory,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Medical Laboratory Technologists' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    } 
  },

  {
    path: '/diagnostic-lab',
    name: 'DiagnosticLab',
    component: DiagnosticLab,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Medical Laboratory Technologists' || store.state.usr_credentials?.department === 'Data Encoder' || store.state.usr_credentials?.department === 'Admission' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    }
  },

  {
    path: '/ekonsulta-submission',
    name: 'EkonsultaSubmission',
    component: EkonsultaSubmission,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Data Encoder' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    }
  },

  {
    path: '/offline-queue-list',
    name: 'OfflineQueueList',
    component: OfflineQueueList,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Data Encoder' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    }
  },

 //Private Queue List
  {
    path: '/prv-queue-list',
    name: 'PrvQueueList',
    component: PrvQueueList,
    beforeEnter: (to, from, next) => {
      if(store.state.usr_credentials?.department === 'Medical Laboratory Technologists' && store.state.prv_data){
        next()
      }else{
        next({name : 'Login'})
      }
    }
  },

  {
    path: '/test-component',
    name: 'TestComponent',
    component: TestComponent, 
  },

  {
    path: '/delete-account',
    name: 'UserDeletion',
    component: UserDeletion, 
  },

  {
    path: '/account-deleted',
    name: 'SuccessDeletion',
    component: SuccessDeletion, 
  },

  {
    path: '/request-denied',
    name: 'RequestDenied',
    component: RequestDenied, 
  },

  {
    path: '/privacy-policy',
    name: 'PrivacyAndPolicy',
    component: PrivacyAndPolicy, 
  },

  {
    path: '/ecare-app',
    name: 'EcareApp',
    component: EcareApp, 
  },

  {
    path: '/test-data',
    name: 'TestData',
    component: TestData, 
  },

  {
    path: '/welcome-page/:provider/:department',
    name: 'WelcomePage',
    component: WelcomePage, 
    beforeEnter: (to,from,next) => {
      if(store.state.prv_data){
        next()
      }else{
        next(false)
      }
    }
  },

  {path:'*', redirect: '/page-not-found'}
]

const router = new VueRouter({
  mode: 'hash',
  // base: process.env.BASE_URL,
  routes
})

export default router
